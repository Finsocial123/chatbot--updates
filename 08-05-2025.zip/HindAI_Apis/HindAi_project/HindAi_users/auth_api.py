from fastapi import APIRouter, HTTPException, Depends, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from typing import Optional
from django.contrib.auth import authenticate, get_user_model
from django.core.exceptions import ValidationError
from jose import JWTError, jwt
from passlib.context import CryptContext
from datetime import datetime, timedelta
from .models import HindAIUser
from .serializers import UserSerializer
from asgiref.sync import sync_to_async
from django.db import transaction
import os

router = APIRouter()

# Pydantic models
class UserCreate(BaseModel):
    email: str
    username: str
    password: str
    first_name: str
    last_name: str

class UserResponse(BaseModel):
    id: int
    email: str
    username: str
    first_name: str
    last_name: str
    token: Optional[str] = None
    is_staff: Optional[bool] = None
    is_superuser: Optional[bool] = None
    is_authenticated: Optional[bool] = None

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class TokenData(BaseModel):
    email: Optional[str] = None

# JWT Configuration
SECRET_KEY = os.getenv('JWT_SECRET_KEY', "your-secret-key-here")  # Should be set in environment
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv('JWT_EXPIRE_MINUTES', "30"))

# Security setup
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/token")

# Helper functions
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

# Auth endpoints
@router.post("/register", response_model=UserResponse)
async def register(user_data: UserCreate):
    UserModel = get_user_model()
    
    # Convert sync operations to async
    @sync_to_async
    def create_user():
        with transaction.atomic():
            # Check if user exists
            if UserModel.objects.filter(email=user_data.email).exists():
                raise HTTPException(
                    status_code=400,
                    detail="Email already registered"
                )
            
            # Create new user
            try:
                user = UserModel.objects.create(
                    email=user_data.email,
                    username=user_data.username,
                    first_name=user_data.first_name,
                    last_name=user_data.last_name
                )
                user.set_password(user_data.password)
                user.save()
                return user
            except Exception as e:
                raise HTTPException(
                    status_code=400,
                    detail=str(e)
                )
    
    try:
        user = await create_user()
        token = create_access_token({"sub": user.email})
        return {
            "id": user.id,
            "email": user.email,
            "username": user.username,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "token": token
        }
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

@router.post("/login", response_model=UserResponse)
async def login(user_data: OAuth2PasswordRequestForm = Depends()):
    UserModel = get_user_model()
    
    @sync_to_async
    def verify_user():
        try:
            # Try to get user by email first
            try:
                user = UserModel.objects.get(email=user_data.username)
            except UserModel.DoesNotExist:
                # If email not found, try username
                try:
                    user = UserModel.objects.get(username=user_data.username)
                except UserModel.DoesNotExist:
                    return None
                
            if user.check_password(user_data.password):
                return user
            return None
        except Exception:
            return None

    user = await verify_user()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username/email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = create_access_token({"sub": user.email})
    return {
        "id": user.id,
        "email": user.email,
        "username": user.username,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "is_staff": user.is_staff,
        "is_superuser": user.is_superuser,
        "is_authenticated": True,
        "token": token
    }

async def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise HTTPException(status_code=401, detail="Invalid authentication token")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid authentication token")
    
    user = HindAIUser.objects.filter(email=email).first()
    if user is None:
        raise HTTPException(status_code=401, detail="User not found")
    return user