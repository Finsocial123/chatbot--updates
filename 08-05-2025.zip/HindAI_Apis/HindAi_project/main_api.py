import logging
import sys
import os
from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from HindAi_users.auth_api import router as auth_router
from htmlgen.api import router as html_router
from chatApis.chatapi import chat_router

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Get the current directory for template loading
current_dir = os.path.dirname(os.path.abspath(__file__))
templates_dir = os.path.join(current_dir, "templates")
templates = Jinja2Templates(directory=templates_dir)

# Create the FastAPI app instance (without docs)
app = FastAPI(
    title="HindAI API", 
    version="2.0.0",
    docs_url=None  # Disable default docs
)


# Include the HTML generation router
app.include_router(
    chat_router,
    prefix="/Chat-apis",
    tags=["Chat APIs"],
    responses={404: {"description": "Not found"}},
)
# Include the HTML generation router
app.include_router(
    html_router,
    prefix="/html",
    tags=["HTML Generation"],
    responses={404: {"description": "Not found"}},
)

# Include the auth router immediately after app creation
app.include_router(
    auth_router,
    prefix="/auth",
    tags=["Authentication"],
    responses={404: {"description": "Not found"}},
)

@app.get("/")
async def root():
    return {"message": "HindAI API is running"}


# Custom Swagger UI endpoint
@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui(request: Request):
    return templates.TemplateResponse(
        "custom_swagger_ui.html",
        {
            "request": request,
            "openapi_url": app.openapi_url
        }
    )


# Add CORS middleware to FastAPI app
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5174",
        "http://localhost:5173",
        "http://localhost:3000",
        "http://localhost:9000",
        "http://saveai.tech",
        "https://aichatbot.bettlechampion.com",
        "https://7236-148-113-5-63.ngrok-free.app",
        "https://hindai.finsocial.tech",
        "https://ved.hindai.tech",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=[
        "Content-Type",
        "Authorization",
        "Accept",
        "Origin",
        "X-Requested-With",
        "X-CSRFTOKEN"
    ],
)
