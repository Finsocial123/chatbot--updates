import json
import os
import pickle
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def load_conversations(json_path):
    """Load conversation pairs from the JSON file."""
    conversations = []
    with open(json_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            if not line or line.startswith('//'):  # Skip empty lines or comments
                continue
            try:
                data = json.loads(line)
                if 'messages' in data:
                    conversations.append(data)
            except json.JSONDecodeError:
                print(f"Warning: Could not parse line: {line[:50]}...")
    
    return conversations

def extract_text_pairs(conversations):
    """Extract user-assistant pairs from conversations."""
    text_pairs = []
    for conv in conversations:
        messages = conv.get('messages', [])
        if len(messages) >= 2 and messages[0]['role'] == 'user' and messages[1]['role'] == 'assistant':
            text_pairs.append({
                'user': messages[0]['content'],
                'assistant': messages[1]['content']
            })
    
    return text_pairs

def create_tfidf_db(text_pairs):
    """Create a TF-IDF based database from text pairs."""
    # Extract questions (user texts)
    questions = [pair['user'] for pair in text_pairs]
    
    # Create TF-IDF vectorizer
    print("Creating TF-IDF vectorizer...")
    vectorizer = TfidfVectorizer(
        min_df=1, 
        stop_words='english',
        lowercase=True,
        max_features=5000
    )
    
    # Generate TF-IDF vectors
    print("Generating TF-IDF vectors...")
    tfidf_matrix = vectorizer.fit_transform(questions)
    
    return {
        'vectorizer': vectorizer,
        'tfidf_matrix': tfidf_matrix,
        'text_pairs': text_pairs
    }

def save_tfidf_db(tfidf_db, output_dir='./tfidf_db'):
    """Save the TF-IDF database to disk."""
    os.makedirs(output_dir, exist_ok=True)
    
    # Save the vectorizer
    with open(os.path.join(output_dir, 'vectorizer.pkl'), 'wb') as f:
        pickle.dump(tfidf_db['vectorizer'], f)
    
    # Save the TF-IDF matrix
    with open(os.path.join(output_dir, 'tfidf_matrix.pkl'), 'wb') as f:
        pickle.dump(tfidf_db['tfidf_matrix'], f)
    
    # Save the text pairs
    with open(os.path.join(output_dir, 'text_pairs.pkl'), 'wb') as f:
        pickle.dump(tfidf_db['text_pairs'], f)
    
    print(f"TF-IDF database saved to {output_dir}")
    print(f"Total documents: {len(tfidf_db['text_pairs'])}")

def query_tfidf_db(query, tfidf_db, k=5):
    """Query the TF-IDF database to find similar conversations."""
    # Transform the query using the saved vectorizer
    query_vector = tfidf_db['vectorizer'].transform([query])
    
    # Calculate cosine similarity between query and all documents
    cosine_similarities = cosine_similarity(query_vector, tfidf_db['tfidf_matrix']).flatten()
    
    # Get top k similar documents
    similar_indices = cosine_similarities.argsort()[-k:][::-1]
    
    results = []
    for idx in similar_indices:
        results.append({
            'similarity': cosine_similarities[idx],
            'user': tfidf_db['text_pairs'][idx]['user'],
            'assistant': tfidf_db['text_pairs'][idx]['assistant']
        })
    
    return results

def main():
    # Path to the JSON file
    json_path = 'd:/finsocial/continueChatFixing/gemma/newHindAI_component/indentity.json'
    
    # Load conversations
    print(f"Loading conversations from {json_path}")
    conversations = load_conversations(json_path)
    print(f"Loaded {len(conversations)} conversations")
    
    # Extract text pairs
    text_pairs = extract_text_pairs(conversations)
    print(f"Extracted {len(text_pairs)} text pairs")
    
    # Create TF-IDF database
    tfidf_db = create_tfidf_db(text_pairs)
    
    # Save TF-IDF database
    output_dir = 'd:/finsocial/continueChatFixing/gemma/newHindAI_component/tfidf_db'
    save_tfidf_db(tfidf_db, output_dir)
    
    # Example query
    print("\nExample query:")
    example_query = "What model are you?"
    results = query_tfidf_db(example_query, tfidf_db, k=3)
    
    for i, result in enumerate(results):
        print(f"\nResult {i+1} (similarity: {result['similarity']:.4f}):")
        print(f"User: {result['user']}")
        print(f"Assistant: {result['assistant']}")

if __name__ == "__main__":
    main()