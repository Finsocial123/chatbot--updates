import redis
import json
import os
from typing import Any, Dict, List, Union, Optional


class KeyDBClient:
    def __init__(self, host='localhost', port=6379, db=0, password=None):
        """Initialize a connection to KeyDB."""
        self.client = redis.Redis(
            host=host,
            port=port,
            db=db,
            password=password,
            decode_responses=True  # Automatically decode responses to strings
        )
    def test_connection(self) -> bool:
        """Test if connection to KeyDB is working."""
        try:
            return self.client.ping()
        except redis.exceptions.ConnectionError:
            return False
    
    # String operations
    def set_string(self, key: str, value: str, ttl: int = None) -> bool:
        """Set a string value in KeyDB with optional time-to-live in seconds."""
        return self.client.set(key, value, ex=ttl)
    
    def get_string(self, key: str) -> str:
        """Get a string value from KeyDB."""
        return self.client.get(key)
    
    # List operations
    def add_to_list(self, key: str, values: List[Any]) -> int:
        """Add values to a list in KeyDB."""
        return self.client.rpush(key, *values)
    
    def reset_list(self, key: str, values: List[Any] = None) -> bool:
        """Delete existing list and optionally create a new one."""
        pipe = self.client.pipeline()
        pipe.delete(key)
        if values:
            pipe.rpush(key, *values)
        results = pipe.execute()
        return all(r for r in results)
        
    def get_list(self, key: str) -> List[str]:
        """Get all values from a list in KeyDB."""
        return self.client.lrange(key, 0, -1)
    
    # Hash operations
    def set_hash(self, key: str, mapping: Dict[str, Any]) -> int:
        """Set a hash in KeyDB."""
        return self.client.hset(key, mapping=mapping)
    
    def get_hash(self, key: str) -> Dict[str, str]:
        """Get a hash from KeyDB."""
        return self.client.hgetall(key)
    
    # JSON operations (storing JSON as strings)
    def set_json(self, key: str, data: Dict[str, Any], ttl: int = None) -> bool:
        """Serialize and store JSON data in KeyDB."""
        json_data = json.dumps(data)
        return self.set_string(key, json_data, ttl)
    
    def get_json(self, key: str) -> Dict[str, Any]:
        """Retrieve and deserialize JSON data from KeyDB."""
        json_data = self.get_string(key)
        if json_data:
            return json.loads(json_data)
        return None
    
    def delete_key(self, key: str) -> int:
        """Delete a key from KeyDB."""
        return self.client.delete(key)
    
    def flush_all(self) -> bool:
        """Clear all data in the current database."""
        return self.client.flushdb()
    
    def get_keys(self, pattern: str = "*") -> List[str]:
        """Get all keys matching a pattern."""
        return self.client.keys(pattern)
    
    # JSON file operations
    def export_to_json(self, filepath: str, pattern: str = "*") -> bool:
        """
        Export data from KeyDB to a JSON file.
        
        Args:
            filepath: Path to the JSON file
            pattern: Pattern to match keys to export
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)
            
            # Get all keys matching the pattern
            keys = self.get_keys(pattern)
            
            # Initialize data dictionary
            data = {}
            
            # Process each key
            for key in keys:
                key_type = self.client.type(key)
                
                if key_type == "string":
                    # Try to load as JSON first
                    try:
                        value = self.get_json(key)
                        if value is None:  # Not valid JSON
                            value = self.get_string(key)
                    except json.JSONDecodeError:
                        value = self.get_string(key)
                    data[key] = {"type": "string", "value": value}
                    
                elif key_type == "list":
                    data[key] = {"type": "list", "value": self.get_list(key)}
                    
                elif key_type == "hash":
                    data[key] = {"type": "hash", "value": self.get_hash(key)}
                    
                elif key_type == "set":
                    data[key] = {"type": "set", "value": list(self.client.smembers(key))}
                    
                elif key_type == "zset":
                    data[key] = {
                        "type": "zset", 
                        "value": [
                            {"member": member, "score": score} 
                            for member, score in self.client.zrangebyscore(key, "-inf", "+inf", withscores=True)
                        ]
                    }
                
            # Write to file
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                
            print(f"Data exported to {filepath}")
            return True
            
        except Exception as e:
            print(f"Error exporting data: {e}")
            return False
            
    def import_from_json(self, filepath: str, overwrite: bool = False) -> bool:
        """
        Import data from a JSON file into KeyDB.
        
        Args:
            filepath: Path to the JSON file
            overwrite: If True, existing keys will be overwritten
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Check if file exists
            if not os.path.exists(filepath):
                print(f"File not found: {filepath}")
                return False
                
            # Read file
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            # Process data
            for key, item in data.items():
                key_type = item.get("type")
                value = item.get("value")
                
                # Check if key exists and overwrite is False
                if not overwrite and self.client.exists(key):
                    print(f"Skipping existing key: {key}")
                    continue
                    
                if key_type == "string":
                    # If value is a dict, convert to JSON string
                    if isinstance(value, dict) or isinstance(value, list):
                        self.set_json(key, value)
                    else:
                        self.set_string(key, str(value))
                        
                elif key_type == "list":
                    self.reset_list(key, value)
                    
                elif key_type == "hash":
                    self.delete_key(key)
                    if value:
                        self.set_hash(key, value)
                        
                elif key_type == "set":
                    self.delete_key(key)
                    if value:
                        self.client.sadd(key, *value)
                        
                elif key_type == "zset":
                    self.delete_key(key)
                    if value:
                        for item in value:
                            self.client.zadd(key, {item["member"]: item["score"]})
                            
            print(f"Data imported from {filepath}")
            return True
            
        except Exception as e:
            print(f"Error importing data: {e}")
            return False
