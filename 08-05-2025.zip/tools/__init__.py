"""
Tools package for HindAI containing all external tools and functions
that can be called by the AI assistant.
"""

from .registry import get_all_tools
from .time_tool import get_current_time
from .chatbot_info import get_chatbot_info
from .image_tool import handle_image_generation

__all__ = [
    'get_all_tools',
    'get_current_time',
    'get_chatbot_info',
    'handle_image_generation'
]
