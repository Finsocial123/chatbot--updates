"""
Registry for all tools available to the AI
"""
from .time_tool import time_tool_definition
from .chatbot_info import chatbot_info_tool_definition
from .image_tool import image_generation_tool_definition

# All tool definitions in one place
all_tools = [
    time_tool_definition,
    chatbot_info_tool_definition
]

def get_all_tools():
    """Return all available tools"""
    return all_tools
