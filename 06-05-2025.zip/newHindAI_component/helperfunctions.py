
import os
# Helper function to sanitize filenames
def sanitize_filename(filename):
    """Sanitize a string to be used as a filename"""
    # Replace problematic characters
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    return filename

def create_user_database_dir(username):
    """Create directory structure for user database: Users/{username}/"""
    user_dir = os.path.join("Users", username)
    os.makedirs(user_dir, exist_ok=True)
    return user_dir

# Add a function to dynamically set the search preference
def set_search_enabled(enable: bool = False) -> bool:
    """
    Set the search preference dynamically
    
    Args:
        enable (bool): Whether to enable web search (default: False)
        
    Returns:
        bool: The current search preference status
    """
    global search_enabled
    search_enabled = enable
    return search_enabled

# Function to get user's search preference
def get_search_preference():
    """Get user's web search feature preference"""
    while True:
        choice = input("\nDo you want to enable web search features? (yes/no): ").lower().strip()
        if choice in ['yes', 'y']:
            return set_search_enabled(True)
        elif choice in ['no', 'n']:
            return set_search_enabled(False)
        print("Please enter 'yes' or 'no'")

