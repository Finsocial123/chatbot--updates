import os
import json
import sqlite3
import sys
import logging
import uuid
import langid
from typing import Tuple
from agno.agent import Agent
from agno.models.openai.like import OpenAILike
from agno.storage.sqlite import SqliteStorage
from agno.memory.v2 import Memory
import datetime
from prompt_template import prompt_temp  # Import the prompt template
# Import translator functionality
from translator import LanguageTranslator, show_language_menu
from tools.hackernewsarticles.hackernew import get_top_hackernews_stories
from tools.SearchEngine.GotResults import main as search_engine_main
from agno.tools.thinking import ThinkingTools
from dotenv import load_dotenv
from newHindAI_component.helperfunctions import sanitize_filename, create_user_database_dir

# built in tools 
from agno.tools.jina import JinaReaderTools
from agno.tools.newspaper4k import Newspaper4kTools
from agno.tools.pubmed import PubmedTools
from agno.tools.crawl4ai import Crawl4aiTools
from agno.tools.wikipedia import WikipediaTools
from agno.tools.yfinance import YFinanceTools
from agno.tools.python import PythonTools
from agno.tools.youtube import YouTubeTools
from agno.knowledge.json import JSONKnowledgeBase

# Suppress warnings
import warnings
warnings.filterwarnings("ignore")

__all__ = [
    "os",
    "json",
    "sqlite3",
    "sys",
    "logging",
    "uuid",
    "langid",
    "Tuple",
    "Agent",
    "OpenAILike",
    "SqliteStorage",
    "Memory",
    "datetime",
    "prompt_temp",
    "LanguageTranslator",
    "show_language_menu",
    "get_top_hackernews_stories",
    "search_engine_main",
    "ThinkingTools",
    "load_dotenv",
    "sanitize_filename",
    "create_user_database_dir",
    "JinaReaderTools",
    "Newspaper4kTools",
    "PubmedTools",
    "Crawl4aiTools",
    "WikipediaTools",
    "YFinanceTools",
    "PythonTools",
    "YouTubeTools",
    "JSONKnowledgeBase",
]