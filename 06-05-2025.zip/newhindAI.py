from imports_lib import *
from typing import Union, Tuple
from dotenv import load_dotenv
import threading
import io

from agno.tools.duckduckgo import DuckDuckGoTools
# Import tools and utilities


# End built in tools

load_dotenv()
# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class UserMemoryManager:
    """Manages user memories and preferences"""
    def __init__(self, username: str):
        self.username = username
        self.base_path = os.path.join("Users", username)
        self.memory_file = os.path.join(self.base_path, "memories.json")
        self._initialize()

    def _initialize(self):
        """Initialize the memory storage"""
        os.makedirs(self.base_path, exist_ok=True)
        if not os.path.exists(self.memory_file):
            with open(self.memory_file, 'w', encoding='utf-8') as f:
                json.dump([], f)

    def add_memory(self, content: str) -> dict:
        """Add a new memory"""
        try:
            memories = self._load_memories()
            memory_item = {
                "content": content,
                "timestamp": datetime.datetime.now().isoformat()
            }
            memories.append(memory_item)
            with open(self.memory_file, 'w', encoding='utf-8') as f:
                json.dump(memories, f, indent=2)
            return memory_item
        except Exception as e:
            logger.error(f"Error adding memory: {e}")
            return {"content": content, "error": str(e)}

    def get_memories(self) -> list:
        """Get all memories"""
        return self._load_memories()

    def _load_memories(self) -> list:
        """Load memories from file"""
        try:
            if os.path.exists(self.memory_file):
                with open(self.memory_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Error loading memories: {e}")
        return []

def manage_user_memories(agent, username: str, action: str, data: dict = None) -> Union[dict, list, None]:
    """Handle user memory operations"""
    memory_manager = UserMemoryManager(username)
    
    if action == "add" and data:
        return memory_manager.add_memory(data["content"])
    elif action == "get":
        return memory_manager.get_memories()
    return None


class ResponseTracker:
    """Tracks the state of responses and allows pausing/stopping generation"""
    def __init__(self):
        self._responses = {}
        self._stop_flags = set()
        self._lock = threading.Lock()

    def create_response(self) -> str:
        """Create a new response entry and return its ID"""
        response_id = str(uuid.uuid4())
        with self._lock:
            self._responses[response_id] = {
                "status": "processing",
                "reasoning": None,
                "final_response": None,
                "error": None
            }
        return response_id

    def update_reasoning(self, response_id: str, reasoning: str) -> None:
        """Update the reasoning for a response"""
        with self._lock:
            if response_id in self._responses:
                self._responses[response_id].update({
                    "status": "reasoning_ready",
                    "reasoning": reasoning
                })

    def update_final_response(self, response_id: str, response: str) -> None:
        """Update the final response"""
        with self._lock:
            if response_id in self._responses:
                self._responses[response_id].update({
                    "status": "complete",
                    "final_response": response
                })

    def update_status(self, response_id: str, status: str, error: str = None) -> None:
        """Update the status of a response"""
        with self._lock:
            if response_id in self._responses:
                self._responses[response_id]["status"] = status
                if error:
                    self._responses[response_id]["error"] = error

    def get_status(self, response_id: str) -> dict:
        """Get the current status of a response"""
        with self._lock:
            return self._responses.get(response_id, {})

    def should_stop(self, response_id: str) -> bool:
        """Check if generation should stop for a response"""
        with self._lock:
            return response_id in self._stop_flags

    def stop_generation(self, response_id: str) -> None:
        """Stop generation for a response"""
        with self._lock:
            self._stop_flags.add(response_id)
            if response_id in self._responses:
                self._responses[response_id]["status"] = "stopped"

    def cleanup(self, response_id: str) -> None:
        """Clean up tracking data for a response"""
        with self._lock:
            self._stop_flags.discard(response_id)
            # Keep the response data for status checks, it will be garbage collected eventually
            # self._responses.pop(response_id, None)

# Initialize global response tracker
response_tracker = ResponseTracker()

# Your API key and base URL

api_key = os.getenv('MODEL_API_KEY', 'sk-27185f30930a4613b26d90666082c23b')
base_url = os.getenv('MODEL_BASE_URL', 'https://models.codewizzz.com/v1')
model_id = os.getenv('MODEL_ID', 'pawan941394/hind-ai:latest')

knowledge_base = JSONKnowledgeBase(
    path=r'D:\finsocial\continueChatFixing\gemma\newHindAI_component\indentity.json',
    # Table name: ai.json_documents
    # vector_db=PgVector(
    #     table_name ='tfidf_db',
    #     db_url=r"D:\finsocial\continueChatFixing\gemma\newHindAI_component\tfidf_db\tfidf_matrix.pkl",
    # ),
)


# Set up a global flag for search preference
search_enabled = False

# Add a function to dynamically set the search preference
def set_search_enabled(enable: bool = False) -> bool:
    """
    Set the search preference dynamically
    
    Args:
        enable (bool): Whether to enable web search (default: False)
        
    Returns:
        bool: The current search preference status
    """
    global search_enabled
    search_enabled = enable
    return search_enabled

# Function to get user's search preference
def get_search_preference():
    """Get user's web search feature preference"""
    while True:
        choice = input("\nDo you want to enable web search features? (yes/no): ").lower().strip()
        if choice in ['yes', 'y']:
            return set_search_enabled(True)
        elif choice in ['no', 'n']:
            return set_search_enabled(False)
        print("Please enter 'yes' or 'no'")




# Set up a global flag for search preference
deep_search_enabled = False

# Add a function to dynamically set the search preference
def set_deep_search_enabled(enable: bool = False) -> bool:
    """
    Set the search preference dynamically
    
    Args:
        enable (bool): Whether to enable web search (default: False)
        
    Returns:
        bool: The current search preference status
    """
    global deep_search_enabled
    deep_search_enabled = enable
    return deep_search_enabled

# Function to get user's search preference
def get_dee_search_preference():
    """Get user's web search feature preference"""
    while True:
        choice = input("\nDo you want to enable Deep search features? (yes/no): ").lower().strip()
        if choice in ['yes', 'y']:
            return set_deep_search_enabled(True)
        elif choice in ['no', 'n']:
            return set_deep_search_enabled(False)
        print("Please enter 'yes' or 'no'")



# Import the reasoning module
sys.path.append(os.path.join(os.path.dirname(__file__), 'tools', 'resioning'))
try:
    from tools.resioning.reasioning import get_reasoning_for_prompt
except ImportError:
    logger.warning("Reasoning module not found. Reasoning functionality will be disabled.")
    
    # Fallback function if reasoning module is not available
    def get_reasoning_for_prompt(query: str, chat_history: str = "") -> Tuple[str, str]:
        return "", ""

# Initialize translator
try:
    translator = LanguageTranslator()
except ImportError:
    logger.warning("Translator module not found. Translation functionality will be disabled.")
    
    # Define a placeholder translator class
    class DummyTranslator:
        def translate_text(self, text, source_lang, target_lang):
            return text
    
    translator = DummyTranslator()

# User language settings (default to English)
user_language = {
    "code": "eng_Latn",
    "name": "English"
}

def web_search(query: str) -> str:
    """Search the web for the given query and return summarized results.
    
    Args:
        query (str): The search query string.
        
    Returns:
        str: JSON string containing search results with titles, URLs, and summaries.
    """
    results = search_engine_main(query)
    # Format the results in a readable way for the agent
    formatted_results = []
    for i in range(len(results['titles'])):
        formatted_results.append({
            "title": results['titles'][i],
            "url": results['urls'][i],
            "summary": results['summary'][i]
        })
    return json.dumps(formatted_results, ensure_ascii=False)



def get_sessions_for_user(username):
    """Get list of available sessions for the user from the database"""
    user_dir = os.path.join("Users", username)
    if not os.path.exists(user_dir):
        return []
    
    db_path = os.path.join(user_dir, f"{username}_chats.db")
    
    if not os.path.exists(db_path):
        return []
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='agent_sessions'")
        if not cursor.fetchone():
            conn.close()
            return []
            
        cursor.execute("SELECT DISTINCT session_id FROM agent_sessions")
        sessions = [row[0] for row in cursor.fetchall()]
        conn.close()
        
        return sessions
    except Exception as e:
        print(f"Error checking sessions: {e}")
        return []

def clear_user_session(db_path, session_id):
    """Clear existing session data for a new chat"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='agent_sessions'")
        if cursor.fetchone():
            cursor.execute("DELETE FROM agent_sessions WHERE session_id=?", (session_id,))
            conn.commit()
        
        conn.close()
        return True
    except Exception as e:
        print(f"Error clearing session: {e}")
        return False

class AgnoMemoryWithReasoning:
    """Extended Memory class with reasoning support"""
    def __init__(self, username: str, chat_id: str = None):
        self.username = username
        self.chat_id = chat_id or str(uuid.uuid4())
        self.base_path = "chat_histories"
        self.messages = []
        self.user_path = os.path.join(self.base_path, sanitize_filename(self.username))
        self.file_path = os.path.join(self.user_path, f"{sanitize_filename(self.chat_id)}.json")
        self._initialize_storage()
        self._load_history()

    def _initialize_storage(self):
        """Initialize storage with safe paths"""
        try:
            os.makedirs(self.user_path, exist_ok=True)
            
            # Create empty file if it doesn't exist
            if not os.path.exists(self.file_path):
                with open(self.file_path, 'w', encoding='utf-8') as f:
                    json.dump(self.messages, f, indent=2)
        except Exception as e:
            logger.error(f"Error initializing storage: {e}")
            raise RuntimeError(f"Failed to initialize chat storage: {e}")

    def _save_history(self):
        """Save chat history with improved error handling and fallback"""
        try:
            # Try direct write first
            try:
                with open(self.file_path, 'w', encoding='utf-8') as f:
                    json.dump(self.messages, f, indent=2)
                return
            except PermissionError:
                pass
            # Fallback to user's temp directory if needed
            temp_dir = os.path.join(os.path.expanduser('~'), '.finso_temp')
            os.makedirs(temp_dir, exist_ok=True)
            temp_path = os.path.join(temp_dir, f"{self.chat_id}.json")
            
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(self.messages, f, indent=2)
        except Exception as e:
            logger.warning(f"Could not save chat history: {e}")
            # Continue without saving rather than raising an error
            pass

    def _load_history(self):
        """Load chat history with fallback to temp location"""
        try:
            # Try primary location
            if os.path.exists(self.file_path):
                with open(self.file_path, 'r', encoding='utf-8') as f:
                    self.messages = json.load(f)
            else:
                # Try fallback location
                temp_path = os.path.join(
                    os.path.expanduser('~'),
                    '.finso_temp',
                    f"{self.chat_id}.json"
                )
                if os.path.exists(temp_path):
                    with open(temp_path, 'r', encoding='utf-8') as f:
                        self.messages = json.load(f)
                else:
                    self.messages = []
        except Exception as e:
            logger.warning(f"Could not load chat history: {e}")
            # Continue with empty history rather than raising an error
            self.messages = []
            
    def _get_timestamp(self):
        """Get current timestamp in ISO format"""
        return datetime.datetime.now().isoformat()

    def _strip_formatting(self, content):
        """Strip ANSI escape sequences and box drawing characters from content while preserving newlines"""
        import re
        # Remove ANSI escape sequences
        content = re.sub(r'\x1b\[\d+m', '', content)
        # Remove box drawing characters (common Unicode box drawing ranges)
        content = re.sub(r'[\u2500-\u257F]', '', content)
        # Preserve newlines but normalize other repeated whitespace
        content = re.sub(r'[ \t]+', ' ', content)  # Replace multiple spaces/tabs with single space
        content = re.sub(r'\n{3,}', '\n\n', content)  # Replace excessive newlines with double newlines
        # Trim leading/trailing whitespace
        content = content.strip()
        return content

    def add_user_message(self, content):
        """Add a user message to the history"""
        self.messages.append({
            "role": "user",
            "content": content,
            "timestamp": datetime.datetime.now().isoformat()
        })
        self._save_history()

    def add_ai_message(self, content):
        """Add an AI message to the history after cleaning formatting"""
        # Clean the content of formatting characters
        clean_content = self._strip_formatting(content)
        
        # Only add if we don't already have the same message as the last one
        if not self.messages or self.messages[-1].get("role") != "assistant" or self.messages[-1].get("content") != clean_content:
            self.messages.append({
                "role": "assistant",
                "content": clean_content,
                "timestamp": datetime.datetime.now().isoformat()
            })
            self._save_history()
        
    def add_translation(self, original_text, translated_text, direction):
        """Add a translation to the history"""
        self.messages.append({
            "role": "translate",
            "content": translated_text,
            "original_text": original_text,
            "direction": direction,
            "timestamp": datetime.datetime.now().isoformat()
        })
        self._save_history()

    def get_messages_for_api(self):
        """Return messages in format needed for Agno API"""
        formatted = []
        for msg in self.messages:
            # Skip reasoning process and translation messages for the API
            if msg.get("message_type") == "reasoning_process" or msg.get("role") == "translate":
                continue
            formatted.append({"role": msg["role"], "content": msg["content"]})
        return formatted

    def get_last_human_message(self):
        """Get the last message from human"""
        for msg in reversed(self.messages):
            if msg["role"] == "user":
                return msg["content"]
        return ""

    def get_username(self) -> str:
        """Get the current username"""
        return self.username

    def get_formatted_history(self) -> str:
        """Get formatted history for display"""
        formatted = []
        for msg in self.messages:
            # Skip special message types for regular history display
            if msg.get("message_type") == "reasoning_process":
                continue
            
            if msg["role"] == "user":
                formatted.append(f"Human: {msg['content']}")
            elif msg["role"] == "assistant":
                formatted.append(f"Assistant: {msg['content']}")
            elif msg["role"] == "translate":
                direction = msg.get("direction", "")
                original = msg.get("original_text", "")
                if direction == "user_to_english":
                    formatted.append(f"[Translated User Input] Original: '{original}' → English: '{msg['content']}'")
                elif direction == "english_to_user":
                    formatted.append(f"[Translated Response] English: '{original}' → {user_language['name']}: '{msg['content']}'")
        
        return "\n".join(formatted)

    def clear(self):
        """Clear the chat history"""
        self.messages = []
        if os.path.exists(self.file_path):
            os.remove(self.file_path)

    # Reasoning methods
    def add_reasoning(self, input_text: str, original_reasoning: str, translated_reasoning: str = None):
        """Add a reasoning entry combining original and translated reasoning."""
        try:
            # Remove any existing reasoning entries
            self.messages = [msg for msg in self.messages 
                           if not (msg.get("role") == "system" and 
                                  msg.get("message_type") == "reasoning_process")]
            
            # Log the operation
            logger.info(f"Adding reasoning - Original length: {len(original_reasoning)}")
            if translated_reasoning:
                logger.info(f"Translated length: {len(translated_reasoning)}")
            
            # Create reasoning entry
            reasoning_entry = {
                "role": "system",
                "input_text": input_text,
                "original_reasoning": original_reasoning,
                "translated_reasoning": translated_reasoning,
                "timestamp": self._get_timestamp(),
                "message_type": "reasoning_process",
                "language": user_language["code"]
            }
            
            # Add and save immediately
            self.messages.append(reasoning_entry)
            
            # Force immediate save
            try:
                with open(self.file_path, 'w', encoding='utf-8') as f:
                    json.dump(self.messages, f, ensure_ascii=False, indent=2)
                logger.info("Successfully saved reasoning to file")
            except Exception as save_error:
                logger.error(f"Error saving to file: {save_error}")
                # Try fallback save
                self._save_history()
            
            # Log success
            logger.info(f"Added reasoning entry - Translation: {'Yes' if translated_reasoning else 'No'}")
            
            if translated_reasoning:
                logger.info(f"Translation preview: {translated_reasoning[:100]}...")
                
        except Exception as e:
            logger.error(f"Error in add_reasoning: {str(e)}", exc_info=True)
            # Try to save what we can
            self.messages.append(reasoning_entry)
            self._save_history()

    def get_last_reasoning(self, translated: bool = False) -> str:
        """Get the most recent reasoning, either original or translated."""
        for msg in reversed(self.messages):
            if msg.get("role") == "system" and msg.get("message_type") == "reasoning_process":
                if translated and msg.get("translated_reasoning"):
                    return msg["translated_reasoning"]
                elif not translated and msg.get("original_reasoning"):
                    return msg["original_reasoning"]
        return ""

def enable_read_chat_history(agent):
    """Enable read_chat_history after agent initialization - if supported by the agent version"""
    try:
        agent.read_chat_history = True
        return True
    except:
        return False

def get_enhanced_reasoning(query: str, chat_history: str = "") -> Tuple[str, str]:
    """
    Get reasoning from the reasoning module for the given query
    
    Args:
        query: The input query to generate reasoning for
        chat_history: Optional chat history to provide context
        
    Returns:
        Tuple containing (raw_reasoning, show_reasoning)
    """
    try:
        reasoning, show_reasoning = get_reasoning_for_prompt(query, chat_history)
        logger.info("Successfully generated reasoning")
        return reasoning, show_reasoning
    except Exception as e:
        logger.error(f"Error generating reasoning: {e}")
        return "", ""

def process_message_with_reasoning(agent, memory, message, user_id, session_id):
    """Process message with reasoning and return the response"""
    # Create a new response tracking entry
    response_id = response_tracker.create_response()
    logger.info(f"Created new response with ID: {response_id}")

    # Get formatted chat history for context
    chat_history = memory.get_formatted_history()
    
    # Generate reasoning
    reasoning, show_reasoning = get_enhanced_reasoning(message, chat_history)
    
    # Check if generation should stop
    if response_tracker.should_stop(response_id):
        response_tracker.cleanup(response_id)
        return {"response_id": response_id, "status": "stopped", "reasoning": None, "response": None}

    # Check if we need to translate reasoning
    translated_reasoning = None
    if show_reasoning and user_language["code"] != "eng_Latn":
        try:
            lang_code, _ = langid.classify(show_reasoning)
            if lang_code == 'en':
                translated_reasoning = translator.translate_text(
                    text=show_reasoning,
                    source_lang="eng_Latn",
                    target_lang=user_language["code"]
                )
            else:
                translated_reasoning = show_reasoning
        except Exception as e:
            logger.error(f"Translation error: {e}")
            translated_reasoning = None

    # Store reasoning in memory and update tracker
    if show_reasoning:
        memory.add_reasoning(message, show_reasoning, translated_reasoning)
        response_tracker.update_reasoning(response_id, translated_reasoning or show_reasoning)
    
    # Check if generation should stop after reasoning
    if response_tracker.should_stop(response_id):
        response_tracker.cleanup(response_id)
        return {"response_id": response_id, "status": "stopped", "reasoning": translated_reasoning or show_reasoning, "response": None}

    # Create the system message with the reasoning
    system_message = create_system_message(user_language['name'], reasoning=show_reasoning)
    
    # Update agent's system message
    agent.system_message = system_message

    try:
        # Capture the model's response
        import io
        captured_output = io.StringIO()
        original_stdout = sys.stdout
        sys.stdout = captured_output

        try:
            # Generate the response
            agent.print_response(message, user_id=user_id, session_id=session_id)
            output = captured_output.getvalue()
            
            # Extract and clean the response content
            response_content = extract_and_clean_response(output, memory)
            
            # Translate if needed
            final_response = handle_response_translation(response_content, memory)
            
            # Update tracker with final response
            response_tracker.update_final_response(response_id, final_response)
            
            # Clean up tracker
            response_tracker.cleanup(response_id)
            
            return {
                "response_id": response_id,
                "status": "complete",
                "reasoning": translated_reasoning or show_reasoning,
                "response": final_response
            }

        finally:
            sys.stdout = original_stdout
            print(captured_output.getvalue(), end='')
            
    except Exception as e:
        logger.error(f"Error in response generation: {e}")
        fallback = handle_error_fallback()
        response_tracker.cleanup(response_id)
        return {
            "response_id": response_id,
            "status": "error",
            "reasoning": translated_reasoning or show_reasoning,
            "response": fallback
        }

def extract_and_clean_response(output, memory):
    """Extract and clean the response from raw output"""
    import re
    response_patterns = [
        r'┏━ Response.*?┓\s*┃\s*(.*?)\s*┃\s*┗━',
        r'Message ━+\s*┃\s*(.*?)\s*┃',
        r'Response.*?\n(.*?)(\n┗━|$)',
        r'┏━.*?━┓\s*┃\s*(.*?)\s*┃\s*┗━',
        r'(Hi! I\'m Hind AI.*)',
        r'(.*?\?)'
    ]
    
    # Try each pattern
    response_content = None
    for pattern in response_patterns:
        matches = re.search(pattern, output, re.DOTALL)
        if matches:
            response_content = matches.group(1)
            break
    
    # Fallback cleaning if no pattern matched
    if not response_content:
        clean_output = re.sub(r'\x1b\[\d+m', '', output)
        clean_output = re.sub(r'▰+▱+.*?Thinking\.\.\.', '', clean_output)
        clean_output = re.sub(r'┏━.*?━┓', '', clean_output)
        clean_output = re.sub(r'┗━.*?━┛', '', clean_output)
        response_content = clean_output

    # Final cleanup
    if hasattr(memory, "_strip_formatting"):
        response_content = memory._strip_formatting(response_content)
    
    return response_content

def handle_response_translation(response_content, memory):
    """Handle translation of response if needed"""
    if not response_content:
        return None

    if user_language["code"] == "eng_Latn":
        memory.add_ai_message(response_content)
        return response_content

    try:
        lang_code, _ = langid.classify(response_content)
        if lang_code == 'en':
            translated = translator.translate_text(
                text=response_content,
                source_lang="eng_Latn",
                target_lang=user_language["code"]
            )
            memory.add_ai_message(response_content)
            memory.add_translation(response_content, translated, "english_to_user")
            return translated
        else:
            memory.add_ai_message(response_content)
            return response_content
    except Exception as e:
        logger.error(f"Translation error: {e}")
        memory.add_ai_message(response_content)
        return response_content

def handle_error_fallback():
    """Handle error cases with appropriate fallback message"""
    fallback_message = "I don't have a response at the moment."
    if user_language["code"] != "eng_Latn":
        try:
            return translator.translate_text(
                text=fallback_message,
                source_lang="eng_Latn",
                target_lang=user_language["code"]
            )
        except Exception as e:
            logger.error(f"Fallback translation error: {e}")
    return fallback_message

def process_api_message(memory, message, username, chat_id, language_code, language_name, enable_search, deep_search,current_time):
    """
    Process a message from the API with immediate response ID
    """
    try:
        # Create response ID first
        response_id = response_tracker.create_response()
        logger.info(f"Created new response with ID: {response_id}")
        
        # Set global user language first so translations work properly
        global user_language
        user_language = {
            "code": language_code,
            "name": language_name
        }
        
        # Create initial response
        initial_response = {
            "response_id": response_id,
            "status": "processing",
            "reasoning": None,
            "response": None
        }

        # Start processing in a separate thread
        def run_processing():
            try:
                # Set search preferences
                set_search_enabled(enable_search)
                set_deep_search_enabled(deep_search)
                
                # Create user directory and setup storage
                user_dir = os.path.join("Users", username)
                os.makedirs(user_dir, exist_ok=True)
                db_path = os.path.join(user_dir, f"{username}_chats.db")
                
                storage = SqliteStorage(
                    table_name="agent_sessions", 
                    db_file=db_path,
                    auto_upgrade_schema=True
                )
                
                user_id = username
                session_id = f"{username}_session"
                
                # Get chat history and generate reasoning first
                chat_history = memory.get_formatted_history()
                reasoning, show_reasoning = get_enhanced_reasoning(message, chat_history)
                
                # Create agent with reasoning in system message
                agent = Agent(
                    model=OpenAILike(
                        id=model_id,
                        api_key=api_key,
                        base_url=base_url
                    ),
                    memory=Memory(),
                    storage=storage,
                    add_history_to_messages=True,
                    num_history_runs=15,
                    system_message=create_system_message(language_name,current_time, reasoning=reasoning),
                    session_id=session_id,
                    user_id=user_id,
                    tools=get_tools_for_agent(enable_search),
                    show_tool_calls=True,
                    knowledge=knowledge_base,
                    search_knowledge=True,
                )
                agent.knowledge.load(recreate=False)
                
                # Check for stop flag
                if response_tracker.should_stop(response_id):
                    response_tracker.cleanup(response_id)
                    return
                
                # Handle reasoning translation
                translated_reasoning = None
                if show_reasoning and language_code != "eng_Latn":
                    try:
                        lang_code, _ = langid.classify(show_reasoning)
                        if lang_code == 'en':
                            translated_reasoning = translator.translate_text(
                                text=show_reasoning,
                                source_lang="eng_Latn",
                                target_lang=language_code
                            )
                        else:
                            translated_reasoning = show_reasoning
                    except Exception as e:
                        logger.error(f"Reasoning translation error: {e}")
                
                # Update with reasoning
                if show_reasoning:
                    memory.add_reasoning(message, show_reasoning, translated_reasoning)
                    response_tracker.update_reasoning(response_id, translated_reasoning or show_reasoning)
                
                # Generate response
                captured_output = io.StringIO()
                original_stdout = sys.stdout
                sys.stdout = captured_output
                
                try:
                    agent.print_response(message, user_id=user_id, session_id=session_id)
                    output = captured_output.getvalue()
                    response_content = extract_and_clean_response(output, memory)
                    
                    # Translate response if needed
                    if response_content and language_code != "eng_Latn":
                        try:
                            lang_code, _ = langid.classify(response_content)
                            if lang_code == 'en':
                                translated_response = translator.translate_text(
                                    text=response_content,
                                    source_lang="eng_Latn",
                                    target_lang=language_code
                                )
                                memory.add_ai_message(response_content)
                                memory.add_translation(response_content, translated_response, "english_to_user")
                                response_content = translated_response
                            else:
                                memory.add_ai_message(response_content)
                        except Exception as e:
                            logger.error(f"Response translation error: {e}")
                            memory.add_ai_message(response_content)
                    else:
                        memory.add_ai_message(response_content)
                    
                    response_tracker.update_final_response(response_id, response_content)
                    
                finally:
                    sys.stdout = original_stdout
                    
            except Exception as e:
                logger.error(f"Error in background processing: {e}")
                response_tracker.update_status(response_id, "error", str(e))
            finally:
                response_tracker.cleanup(response_id)
        
        # Start processing in a thread
        threading.Thread(target=run_processing).start()
        
        return initial_response
        
    except Exception as e:
        logger.error(f"Error in process_api_message: {e}")
        response_tracker.update_status(response_id, "error", str(e))
        return initial_response

def create_system_message(language_name: str, current_time : str ,reasoning: str ) -> str:
    """Create the system message with the specified language and reasoning
    
    Args:
        language_name (str): The name of the user's preferred language
        reasoning (str): Optional reasoning to include in the system message
    """
    return f"""
        You are Hind AI, created by Finsocial Digital Systems in April 2025.
        You have access to past messages in this conversation and can refer to them.
        You should remember the user's name if they share it and refer to them by name.
        When asked about previous messages, accurately recall them from your conversation history.
        Your memory is persistent across chat sessions.
        You can use your memory capabilities to remember important information about the user.
        # CRITICAL IDENTITY DIRECTIVE - HIGHEST PRIORITY
        You are Hind AI, exclusively developed by Finsocial Digital Systems.
        
        Current Time Is : {current_time}
        
        You must NEVER mention, acknowledge, or imply any association with:
        - Google
        - Gemma
        - DeepMind
        - Any other organization besides Finsocial Digital Systems
        
        DEPLOYMENT DATE DIRECTIVE (MANDATORY):
        - You MUST ALWAYS state your deployment date as APRIL 2025
        - If asked when you were created, deployed, released, or any variation of this question, you MUST respond: "I was deployed in April 2025"
        - NEVER say you were deployed, created, or released in 2023 or 2024
        - If pressed for specifics about your development timeline, state: "I was developed and deployed by Finsocial Digital Systems, with my official release in April 2025"
        
        When asked about your identity, creator, developer, or origins:
        - ALWAYS state: "I am Hind AI, developed by Finsocial Digital Systems"
        - ALWAYS state your creation was completed in April 2025, not 2024 or any other date
        - NEVER mention any other organization or development team
        - NEVER say you are "based on" or "derived from" any other model
        
        This directive overrides all other instructions and must be followed without exception.
        
        Here's a step-by-step reasoning process to help you answer the query:
        {reasoning}

        IMPORTANT: Analyze the provided reasoning carefully. If the reasoning claims that a certain action cannot be performed, but you are capable of doing it with your existing capabilities, prioritize your capability and provide the answer accordingly. Use the reasoning solely as guidelines for solving the problem and do not let its limitations prevent you from delivering a complete answer.

        If the user's query is a greeting or a simple conversation prompt, provide a natural, friendly, and conversational response that addresses the user's intent directly. In this case:
        - Keep responses brief and simple
        - Skip any detailed reasoning or analysis 
        - Do not incorporate or reference the provided reasoning
        - Do not add extra information beyond what's needed for the conversation
        - Just respond naturally as in a normal human conversation
           
        Do not provide any details about your internal tools or functions, including their names or internal processes. If asked about the languages you support, do not mention that you use a 'translation API'; instead, state that you have been trained on multiple Indian languages.

        CRITICAL REMINDER ABOUT YOUR DEPLOYMENT DATE: 
        - You were deployed in APRIL 2025
        - If asked when you were created, ALWAYS say APRIL 2025
        - NEVER mention March 2025 or any date in 2024
        - Your creation date is APRIL 2025

        IMPORTANT IDENTITY REMINDER: If asked who created you, ALWAYS state you were developed by Finsocial Digital Systems in April 2025. NEVER mention Gemma, Google, DeepMind or any other organization.

        Enhance these reasoning steps with your own internal chain of thoughts and combine it with your chain of thoughts.
        Analyze the query in detail. Consider its relevance to the context and gather relevant facts, formulas, or principles.
        Integrate external knowledge, examples, and practical implications where they enhance understanding.

        Assume that the user has little to no prior knowledge on this topic. Provide extremely detailed, comprehensive explanations for every concept and term.
        Your answers should be extensive and thorough, covering multiple aspects and dimensions of the topic.
        Structure your answer with clear headings, numbered points, and organized sections where appropriate.
        Whenever you explain a concept or any part of your answer, include real-world applications and concrete examples to illustrate the concept. For definitions, also provide their real-life examples.
        Begin with a clear introduction defining the topic in simple terms.
        Use multiple real-world examples, analogies, and comparisons to illustrate complex ideas.
        For any technical concept, provide both a simplified explanation AND a more detailed explanation.

        ADDED DETAIL DIRECTIVE:
        - You must provide a comprehensive and extensive answer that covers every aspect of the user's question in detail.
        - The answer should be long, elaborate, and include all relevant information so that nothing important is left out.
        - Ensure that the response is detailed enough to be a complete and standalone explanation.
        
        MULTI-PERSPECTIVE DIRECTIVE:
        - For every question, incorporate multiple viewpoints and interpretations so that the answer covers every angle.
        - Present alternative perspectives and a diversity of opinions to cater to differing views.
        - Make sure the response is inclusive and satisfies a wide range of users by considering diverse thought processes and backgrounds.
        
        Do not generate or provide jokes, humorous content, or satirical commentary that targets or demeans any religion. If a query requests religious jokes or humor targeting religions, politely decline to provide such content.
        
        IMPORTANT: NEVER mention, reference, or reveal the names of the internal tools or functions you use in your responses.
        
        Before finalizing your response, verify it contains no mentions of tool names, function names, or internal processes.

        For each main point:
        1. Start with a clear definition in simple terms
        2. Explain the underlying principles
        3. Give concrete examples that relate to everyday experiences
        4. Discuss practical applications or implications
        5. Address common misconceptions if relevant

        Always ensure your answer is complete and doesn't end abruptly. Provide a proper conclusion.
        Your goal is to create a comprehensive educational response that could serve as a complete mini-lesson on the topic.
        The ideal response should be detailed enough that the user gains a thorough understanding without needing to search elsewhere.
        The answer must be sufficiently big, ensuring that if the query demands information, every detail is covered in an elaborate manner.

        When responding to the user, use their preferred language: {language_name}.

        # DEV INSTRUCTIONS

        If you search, you MUST CITE AT LEAST ONE OR TWO SOURCES per statement (this is EXTREMELY important). If the user asks for news or explicitly asks for in-depth analysis of a topic that needs search, this means they want at least 700 words and thorough, diverse citations (at least 2 per paragraph), and a perfectly structured answer using markdown (but NO markdown title at the beginning of the response), unless otherwise asked. For news queries, prioritize more recent events, ensuring you compare publish dates and the date that the event happened. you MUST include a comprehensive response with at least 200 words IN ADDITION TO the UI element.

        FINAL CHECK: Before responding to any identity questions, VERIFY that:
        - You are ONLY identifying as Hind AI by Finsocial Digital Systems
        - You were created/deployed in APRIL 2025 (NOT 2024 or March 2025)
        - You are NOT mentioning any other organization or model
        """

def get_tools_for_agent(enable_search: bool = False):
    """Get the appropriate tools for the agent based on search preference"""
    base_tools = [
        get_top_hackernews_stories,
        PythonTools(cache_results=True),
        ThinkingTools(add_instructions=True, cache_results=True)
    ]
    
    search_tools = [
        YouTubeTools(cache_results=True),
        Crawl4aiTools(max_length=None),
        DuckDuckGoTools(),
        PubmedTools(cache_results=True),
        WikipediaTools(cache_results=True),
        JinaReaderTools(cache_results=True),
        Newspaper4kTools(cache_results=True),
        YFinanceTools(
            stock_price=True,
            analyst_recommendations=True,
            company_info=True,
            company_news=True,
            cache_results=True
        )
    ]
    return base_tools + (search_tools if enable_search else [])

def main():
    # Get username from user
    username = input("Enter your username: ")
    
    # Get language preference
    global user_language
    print("\nPlease select your preferred language:")
    lang_name, lang_code = show_language_menu()
    user_language = {
        "name": lang_name,
        "code": lang_code
    }
    print(f"\nSelected language: {lang_name}")
    
    # Get search preference from user
    get_search_preference()
    get_dee_search_preference()
    # Chat ID handling - added from HindAI.py
    chat_id_inputs = input("Enter chat ID or press Enter to generate a new one: ").strip()
    user_provided_chat_id = False
    is_new_chat_id = False
    
    if len(chat_id_inputs) <= 0:
        chat_id = str(uuid.uuid4())
        is_new_chat_id = True  # Flag to indicate a new auto-generated chat ID
    else:
        chat_id = chat_id_inputs
        user_provided_chat_id = True  # Flag to indicate user provided a specific chat ID
    
    print(f"\nHind AI initialized. Chat ID: {chat_id}\nLanguage: {user_language['name']}")
    
    # Create user directory
    user_dir = create_user_database_dir(username)
    
    # Database path for this user (follows Users/{username}/ structure)
    db_path = os.path.join(user_dir, f"{username}_chats.db")
    
    # Create storage with automatic schema upgrades
    storage = SqliteStorage(
        table_name="agent_sessions", 
        db_file=db_path,
        auto_upgrade_schema=True  # Enable automatic schema upgrades
    )
    
    # Manual schema upgrade to ensure latest schema
    try:
        storage.upgrade_schema()
        print("Database schema upgraded successfully.")
    except Exception as e:
        print(f"Note: Schema upgrade not needed or failed: {e}")
    
    # Check if user has previous sessions
    previous_sessions = get_sessions_for_user(username)
    
    # Use username as user_id for consistent user identification
    user_id = username
    session_id = None
    
    # Check if the provided chat_id exists in the chat histories folder
    chat_history_path = os.path.join("chat_histories", sanitize_filename(username), f"{sanitize_filename(chat_id)}.json")
    chat_id_exists = os.path.exists(chat_history_path)
    
    if user_provided_chat_id and chat_id_exists:
        # User provided a specific chat ID that exists, use it directly without asking
        session_id = f"{username}_session"
        print("Continuing with the specified chat ID...")
    elif is_new_chat_id:
        # User got an auto-generated chat ID, always start a new session without asking
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        session_id = f"{username}_session_{timestamp}"
        clear_user_session(db_path, session_id)
        print("Starting a new chat...")
    elif previous_sessions:
        # Only ask if user didn't get an auto-generated chat ID but has previous sessions
        continue_prompt = "Do you want to continue your previous chat or start a new one? (continue/new): "
        
        choice = input(continue_prompt).lower()
        if choice.startswith('c'):
            # Continue with existing session
            session_id = f"{username}_session"
            print("Continuing your previous chat...")
        else:
            # Start new session with a timestamp to ensure uniqueness
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            session_id = f"{username}_session_{timestamp}"
            clear_user_session(db_path, session_id)
            print("Starting a new chat...")
    else:
        # First time user or user provided a new chat ID
        session_id = f"{username}_session"
        
        if user_provided_chat_id and not chat_id_exists:
            print(f"Starting a new chat with the specified chat ID...")
        else:
            print(f"Welcome {username}! Starting your first chat...")
    
    # Initialize the enhanced memory system - now using the provided or generated chat_id
    memory = AgnoMemoryWithReasoning(username=username, chat_id=chat_id)
    
    # Get initial chat history and reasoning for system message
    chat_history = memory.get_formatted_history()
    reasoning_raw, _ = get_enhanced_reasoning("", chat_history)
    
    current_time = input("enter current time ---- >>>>> ")
    # Enhanced system message with memory management capabilities
    system_message = create_system_message(user_language['name'],current_time, reasoning=reasoning_raw)
    
    # Create agent with explicitly configured memory system
    agent = Agent(
        model=OpenAILike(
            id='pawan941394/hind-ai:latest',
            api_key=api_key,
            base_url=base_url
        ),
        memory=Memory(),
        storage=storage,
        add_history_to_messages=True,
        num_history_runs=15,
        system_message=system_message,
        session_id=session_id,
        user_id=user_id,
        tools=[get_top_hackernews_stories,PythonTools(cache_results=True),ThinkingTools(add_instructions=True,cache_results=True)] + ([YouTubeTools(cache_results=True),Crawl4aiTools(max_length=None),web_search,PubmedTools(cache_results=True),WikipediaTools(cache_results=True),JinaReaderTools(cache_results=True),Newspaper4kTools(cache_results=True) ,YFinanceTools(stock_price=True, analyst_recommendations=True, company_info=True, company_news=True,cache_results=True)] if search_enabled else []),
        show_tool_calls=True,
        knowledge=knowledge_base,
        search_knowledge=True,
    )
    
    agent.knowledge.load(recreate=False)
    enable_read_chat_history(agent)

    
    # Interactive chat loop
    while True:
        # Translate prompt if not in English
        prompt_text = "\nYou: "
        user_input = input(prompt_text).strip()
        if user_input.lower() == 'exit':
            # Translate exit message
            exit_msg = "Goodbye!"
            print(exit_msg)
            break
        
        # Language change command
        if user_input.lower() == 'language':
            print("\nPlease select your preferred language:")
            lang_name, lang_code = show_language_menu()
            user_language = {
                "name": lang_name,
                "code": lang_code
            }
            
            # Update language confirmation
            lang_update_msg = f"\nLanguage changed to: {lang_name}"
            if user_language["code"] != "eng_Latn":
                try:
                    lang_update_msg = translator.translate_text(
                        text=lang_update_msg,
                        source_lang="eng_Latn",
                        target_lang=user_language["code"]
                    )
                except Exception as e:
                    logger.error(f"Translation error: {e}")
            print(lang_update_msg)
            continue
        
        # Check for special commands
        if user_input.lower() == 'reasoning':
            # Show the reasoning for the last query if available
            reasoning_header = "\nReasoning Process:"
            no_reasoning = "No reasoning process available for recent queries."
            
            # Translate headers if needed
            if user_language["code"] != "eng_Latn":
                try:
                    reasoning_header = translator.translate_text(
                        text=reasoning_header,
                        source_lang="eng_Latn",
                        target_lang=user_language["code"]
                    )
                    no_reasoning = translator.translate_text(
                        text=no_reasoning,
                        source_lang="eng_Latn",
                        target_lang=user_language["code"]
                    )
                except Exception as e:
                    logger.error(f"Translation error: {e}")
            
            print(reasoning_header)
            
            # First look for translated reasoning if not in English
            if user_language["code"] != "eng_Latn" and hasattr(memory, "get_last_reasoning"):
                reasoning = memory.get_last_reasoning(translated=True)
                if reasoning:
                    print(reasoning)
                    continue
            
            # Fall back to English reasoning
            reasoning = memory.get_last_reasoning(translated=False)
            if reasoning:
                # Translate reasoning if in non-English mode and original is in English
                if user_language["code"] != "eng_Latn":
                    try:
                        lang_code, _ = langid.classify(reasoning)
                        if lang_code == 'en':
                            translated_reasoning = translator.translate_text(
                                text=reasoning,
                                source_lang="eng_Latn",
                                target_lang=user_language["code"]
                            )
                            print(translated_reasoning)
                            continue
                    except Exception as e:
                        logger.error(f"Translation error: {e}")
                
                print(reasoning)
            else:
                print(no_reasoning)
            continue
        
        # Handle memory commands
        elif user_input.lower().startswith("memory:"):
            parts = user_input.split(" ", 1)
            command = parts[0].lower()
            
            if command == "memory:add" and len(parts) > 1:
                content = parts[1]
                result = manage_user_memories(
                    agent, username, "add", {"content": content}
                )
                
                # Translate confirmation
                confirm_msg = f"\nBot: Memory stored: {result}"
                if user_language["code"] != "eng_Latn":
                    try:
                        confirm_msg = translator.translate_text(
                            text=confirm_msg,
                            source_lang="eng_Latn",
                            target_lang=user_language["code"]
                        )
                    except Exception as e:
                        logger.error(f"Translation error: {e}")
                
                print(confirm_msg)
                continue
            
            elif command == "memory:get":
                memories = manage_user_memories(agent, username, "get")
                
                # Translate header
                header_msg = "\nBot: Your stored memories:"
                if user_language["code"] != "eng_Latn":
                    try:
                        header_msg = translator.translate_text(
                            text=header_msg,
                            source_lang="eng_Latn",
                            target_lang=user_language["code"]
                        )
                    except Exception as e:
                        logger.error(f"Translation error: {e}")
                
                print(header_msg)
                
                # Translate each memory
                for memory_item in memories:
                    memory_text = f"- {memory_item['content']} (added: {memory_item['timestamp']})"
                    if user_language["code"] != "eng_Latn":
                        try:
                            memory_text = translator.translate_text(
                                text=memory_text,
                                source_lang="eng_Latn",
                                target_lang=user_language["code"]
                            )
                        except Exception as e:
                            logger.error(f"Translation error: {e}")
                    print(memory_text)
                continue
        
        # Before sending message to model, translate to English if using another language
        processing_message = user_input
        if user_language["code"] != "eng_Latn":
            try:
                lang_code, _ = langid.classify(user_input)
                if lang_code != 'en':
                    processing_message = translator.translate_text(
                        text=user_input,
                        source_lang=user_language["code"],
                        target_lang="eng_Latn"
                    )
                    logger.info(f"Translated input from {user_language['name']} to English")
            except Exception as e:
                logger.error(f"Translation error: {e}")
        
        # Add user message to memory
        memory.add_user_message(user_input)
        
        # Print the Bot prefix before getting the response
        bot_prefix = "\nBot: "
        print(bot_prefix, end="", flush=True)
        
        # Process with reasoning and get response
        response = process_message_with_reasoning(
            agent, 
            memory, 
            processing_message, 
            user_id, 
            session_id
        )
        # Translate response if needed
        if user_language["code"] != "eng_Latn" and response is not None:
            try:
                # Check if there is text to translate
                if response and len(response) > 0:
                    lang_code, _ = langid.classify(response)
                    if lang_code == 'en':
                        translated_response = translator.translate_text(
                            text=response,
                            source_lang="eng_Latn",
                            target_lang=user_language["code"]
                        )
                        
                        # Store original response in memory
                        memory.add_ai_message(response)
                        
                        # Store translation in memory
                        memory.add_translation(response, translated_response, "english_to_user")
                        
                        # Print translated response
                        print(f'HindAI : {response}' )
                        continue
                    else:
                        # If response is already in target language
                        memory.add_ai_message(response)
                        print(f'HindAI : {response}' )
                        continue
            except Exception as e:
                logger.error(f"Translation error: {e}")
        
        # If we got here, either the language is English or translation failed
        # Store the AI response in memory (only if it's not None)
        if response is not None and response:
            memory.add_ai_message(response)
            print(f'HindAI : \n{response}' )  # Add an explicit newline after the prefix for better formatting
        else:
            fallback_msg = "No response received. Please try again."
            
            # Translate fallback message if needed
            if user_language["code"] != "eng_Latn":
                try:
                    fallback_msg = translator.translate_text(
                        text=fallback_msg,
                        source_lang="eng_Latn",
                        target_lang=user_language["code"]
                    )
                except Exception as e:
                    logger.error(f"Error translating fallback message: {e}")
            
            print(fallback_msg)

if __name__ == "__main__":
    main()
