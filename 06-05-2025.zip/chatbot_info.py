"""
Tool for providing information about the chatbot
"""

def get_chatbot_info(query: str = None):
    """Get information about Hind AI chatbot"""
    info = {
        "name": "Hind AI",
        "version": "1.0",
        "developer": "Finsocial Digital System",
        "description": "Hind AI is an advanced AI assistant developed by Finsocial Digital System. It is designed to provide detailed, helpful responses with reasoning capabilities.",
        "capabilities": [
            "Answering questions with detailed explanations",
            "Multi-language support through translation",
            "Step-by-step reasoning for complex topics",
            "Web search capabilities (when enabled)",
            "Current time and date information",
            "Chat history management"
        ],
        "language_support": "Multiple languages via translation API",
        "release_date": "2023"
    }
    
    if query:
        query = query.lower().strip()
        if "name" in query:
            return {"name": info["name"]}
        elif "version" in query:
            return {"version": info["version"]}
        elif "developer" in query or "creator" in query or "made" in query:
            return {"developer": info["developer"]}
        elif "capabilities" in query or "features" in query:
            return {"capabilities": info["capabilities"]}
        elif "language" in query:
            return {"language_support": info["language_support"]}
    
    return info
