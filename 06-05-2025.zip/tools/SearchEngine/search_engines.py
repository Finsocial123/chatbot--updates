import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from googlesearch import search

# DuckDuckGo Search (Latest News)
def search_duckduckgo(query, num_results=10):
    url = "https://html.duckduckgo.com/html/"
    params = {"q": f"{query} latest news"}
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, params=params, headers=headers)
    
    if response.status_code == 200:
        results = []
        soup = BeautifulSoup(response.text, "html.parser")
        
        for link in soup.select(".result__url"):
            title = link.text.strip()
            href = "https://" + link.text.strip()
            results.append({"url": href, "title": title})
            if len(results) >= num_results:
                break  
        return results
    return []

# SearxNG Search (Latest News)
def search_searxng(query, num_results=10, searxng_url="https://searx.be/"):
    url = f"{searxng_url}/search"
    params = {"q": f"{query} ", "format": "json", "engines": "google-news", "category_general": "news"}
    response = requests.get(url, params=params)
    
    if response.status_code == 200:
        data = response.json()
        results = [{"url": item["url"], "title": item["title"]} for item in data.get("results", []) if "url" in item]
        return results[:num_results]
    return []

# Google Search
def search_google(query, num_results=3):
    try:
        results = []
        for j in search(f"{query} latest news", num_results=num_results):
            results.append({"url": j, "title": j})  # URL as title since googlesearch doesn't provide titles
        return results
    except Exception as e:
        print(f"Google search error: {e}")
        return []

# Remove Duplicate Domains
def filter_unique_results(results, max_results=15):
    unique_domains = set()
    filtered_results = []
    
    for result in results:
        domain = urlparse(result["url"]).netloc
        if domain not in unique_domains:
            unique_domains.add(domain)
            filtered_results.append(result)
        if len(filtered_results) == max_results:
            break  
    return filtered_results
