from agno.agent import Agent
from agno.models.openai.like import OpenAILike

def generate_prompt(user_input: str) -> str:
    return f"""
You are a friendly, conversational reasoning agent. Your task is to clearly explain the given input, or any other instructions provided by the user. Ensure that there is a proper new line after every paragraph.

### User Input:
{user_input}

### User-Friendly Explanation:
Provide a simple, engaging, paragraph-based explanation. Avoid lists or bullet points. Clearly simplify any complex concepts, include relatable analogies or examples, and ensure that your explanation is organized into proper paragraphs for clear readability.
"""

# Agent setup (Reusable)
agent = Agent(
    description="Dynamic friendly reasoning agent.",
    instructions=[
        "Expand user-provided reasoning or instructions into friendly, easy-to-understand conversational explanations. Simplify complex concepts clearly."
    ],
    model=OpenAILike(
        id="llama3.2:1b",
        api_key='testing',
        base_url="https://9hw3vedibi5cqz-11434.proxy.runpod.net/v1",
    ),
    markdown=True,
    debug_mode=False,
)


def show_reasionings(user_input: str) -> str:
    try:
        # Generate dynamic prompt
        prompt = generate_prompt(user_input)

        # Execute agent
        response = agent.run(prompt)

        # Display user-friendly output
        return response.content

    except Exception as e:
        return f"Error occurred: {e}"
