import os
import json
from agno.agent import Agent
from agno.models.openai.like import OpenAILike
from agno.storage.json import JsonStorage
from agno.playground import Playground, serve_playground_app
from agno.storage.json import JsonStorage
# Ensure the storage directory exists
os.makedirs("tmp/agent_sessions_json", exist_ok=True)
# Your API key and base URL
api_key = "sk-27185f30930a4613b26d90666082c23b"
base_url = "https://models.codewizzz.com/v1"
from agno.agent import Agent
from agno.models.openai import OpenAIChat
from agno.storage.sqlite import SqliteStorage
from rich.pretty import pprint

agent = Agent(
    model=OpenAILike(
            id='pawan941394/hind-ai:latest',
            api_key=api_key,
            base_url=base_url
        ),
    session_id="fixed_id_for_demo",
    storage=SqliteStorage(table_name="agent_sessions", db_file="tmp/data.db"),
    add_history_to_messages=True,
)
agent.print_response("What is your name?")
agent.print_response("What was my last prompt?")