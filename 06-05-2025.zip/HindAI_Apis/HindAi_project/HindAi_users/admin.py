from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import HindAIUser,ActiveInactiveUsers

@admin.register(ActiveInactiveUsers)
class ActiveInactiveUsersAdmin(admin.ModelAdmin):
    list_display = ('user', 'minute', 'start_time', 'end_time')
    list_filter = ('minute',)
    search_fields = ('user__email', 'user__username')



@admin.register(HindAIUser)
class HindAIUserAdmin(UserAdmin):
    list_display = ('email', 'username', 'is_active', 'is_staff', 'date_joined')
    search_fields = ('email', 'username', 'first_name', 'last_name')
    ordering = ('-date_joined',)

    # Add custom fields to fieldsets
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'username', 'password1', 'password2'),
        }),
    )

    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Personal info', {'fields': ('username', 'first_name', 'last_name')}),
        ('Permissions', {
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions'),
        }),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
    )
