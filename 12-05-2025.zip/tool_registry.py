"""
Registry for all tools available to the AI
"""
# Import tool functions
from time_tool import get_current_time
from chatbot_info import get_chatbot_info
from tools.identitytool.identity_tool import get_identity_tool

def get_identity_response(query: str) -> str:
    """Get HindAI's identity response based on the query"""
    identity_tool = get_identity_tool()
    return identity_tool.get_identity_response(query)

# Define the time tool
time_tool_definition = {
    "type": "function",
    "function": {
        "name": "get_current_time",
        "description": "Get the current date and time in various formats",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": []
        }
    }
}

# Define the chatbot info tool
chatbot_info_tool_definition = {
    "type": "function",
    "function": {
        "name": "get_chatbot_info",
        "description": "Get information about the chatbot such as its name, version, capabilities, etc.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "A query about the chatbot information to retrieve"
                }
            },
            "required": ["query"]
        }
    }
}

# Define the identity tool
identity_tool_definition = {
    "type": "function",
    "function": {
        "name": "get_identity_response",
        "description": "Get HindAI's identity and background information. Use this for queries about who created HindAI, what model it is, or any questions about its identity and origins.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The user's question about HindAI's identity"
                }
            },
            "required": ["query"]
        }
    }
}

# All tool definitions in one place
all_tools = [
    time_tool_definition,
    chatbot_info_tool_definition,
    identity_tool_definition
]

def get_all_tools():
    """Return all available tools"""
    return all_tools
