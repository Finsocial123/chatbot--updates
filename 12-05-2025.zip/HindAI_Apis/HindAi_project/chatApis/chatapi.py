from fastapi import APIRouter, HTTPException, status, BackgroundTasks
from pydantic import BaseModel
from typing import Dict, Any, Optional, List
import sys
import os
import logging
import pathlib
import json
# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Get the absolute path to the newhindAI.py file
# First get the current file path
current_file = pathlib.Path(__file__).resolve()
logger.info(f"Current file path: {current_file}")

# Navigate up to the gemma directory directly (4 levels up)
root_dir = current_file.parent.parent.parent.parent.parent  # One more parent to reach gemma
newhindai_path = os.path.join(root_dir, "newhindAI.py")

logger.info(f"Looking for newhindAI.py at: {newhindai_path}")

# Add the gemma directory to the Python path
sys.path.append(str(root_dir))
logger.info(f"Added to Python path: {root_dir}")

# Function to check if a file exists
def file_exists(path):
    return os.path.isfile(path)

# Log file existence
if file_exists(newhindai_path):
    logger.info(f"File exists at: {newhindai_path}")
else:

    for root, dirs, files in os.walk(root_dir):
        if "newhindAI.py" in files:
            found_path = os.path.join(root, "newhindAI.py")
            logger.info(f"Found newhindAI.py at: {found_path}")
            newhindai_path = found_path
            gemma_dir = os.path.dirname(found_path)
            sys.path.append(gemma_dir)
            logger.info(f"Updated Python path with: {gemma_dir}")
            break

try:
    # Try direct import
    import newhindAI
    logger.info("Successfully imported newhindAI as module")
except ImportError as e:
    logger.error(f"Direct import failed: {e}")
    try:
        # If direct import fails, try to import from file path
        import importlib.util
        spec = importlib.util.spec_from_file_location("newhindAI", newhindai_path)
        if spec is None:
            logger.error(f"Could not find file: {newhindai_path}")
            raise ImportError(f"File {newhindai_path} not found")
        
        newhindAI = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(newhindAI)
        logger.info("Successfully imported newhindAI from file")
        
        # Add to sys.modules to make it importable elsewhere
        sys.modules["newhindAI"] = newhindAI
    except Exception as e:
        logger.error(f"Failed to import newhindAI from file: {e}")
        raise ImportError(f"Failed to import newhindAI: {e}")

# Import the required functions from the newhindAI module
try:
    from newhindAI import (
        AgnoMemoryWithReasoning, 
        process_api_message
    )
    logger.info("Successfully imported specific functions from newhindAI")
except ImportError as e:
    logger.error(f"Failed to import specific functions from newhindAI: {e}")
    raise ImportError(f"Failed to import required modules from newhindAI: {e}")

chat_router = APIRouter()


class ChatRequest(BaseModel):
    username: str
    chat_id: Optional[str] = "fresh"
    current_time: Optional[str] = "06-05-2023 12:00:00"
    language_code: str = "eng_Latn"
    language_name: str = "English"
    enable_search: bool = False
    deep_search: bool = False
    message: str

class ChatResponse(BaseModel):
    response_id: str
    status: str  # "processing", "reasoning_ready", "complete", "stopped", or "error"
    reasoning: Optional[str]
    response: Optional[str]
    conversation_id: str

class StopGenerationRequest(BaseModel):
    response_id: str

# Cache for memory instances to maintain state between requests
memory_cache = {}


def get_or_create_memory(username: str, chat_id: str):
    """
    Get existing memory or create a new one for the user
    
    Args:
        username: User identifier
        chat_id: Conversation identifier
        
    Returns:
        AgnoMemoryWithReasoning: Memory instance
    """
    cache_key = f"{username}:{chat_id}"
    
    if cache_key in memory_cache:
        memory = memory_cache[cache_key]
        logger.info(f"Using cached memory for {cache_key}")
    else:
        logger.info(f"Creating new memory for {cache_key}")
        
        # Create user directory structure
        user_dir = os.path.join("Users", username)
        os.makedirs(user_dir, exist_ok=True)
        
        # Create memory instance
        memory = AgnoMemoryWithReasoning(username=username, chat_id=chat_id)
        
        # Cache the memory instance
        memory_cache[cache_key] = memory
    
    return memory

@chat_router.post("/chat/stop", response_model=ChatResponse, summary="Stop response generation")
async def stop_generation(request: StopGenerationRequest) -> Dict[str, Any]:
    """Stop an ongoing response generation"""
    try:
        from newhindAI import response_tracker
        response_tracker.stop_generation(request.response_id)
        status = response_tracker.get_status(request.response_id)
        return {
            "response_id": request.response_id,
            "status": "stopped",
            "reasoning": status.get("reasoning"),
            "response": status.get("final_response"),
            "conversation_id": ""  # Not needed for stop response
        }
    except Exception as e:
        logger.error(f"Failed to stop generation: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to stop generation: {str(e)}"
        )

@chat_router.get("/chat/status/{response_id}", response_model=ChatResponse, summary="Get response status")
async def get_response_status(response_id: str) -> Dict[str, Any]:
    """Get the current status of a response generation"""
    try:
        from newhindAI import response_tracker
        status = response_tracker.get_status(response_id)
        if not status:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Response ID {response_id} not found"
            )
        return {
            "response_id": response_id,
            "status": status.get("status", "unknown"),
            "reasoning": status.get("reasoning"),
            "response": status.get("final_response"),
            "conversation_id": ""  # Not needed for status check
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get response status: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get response status: {str(e)}"
        )

@chat_router.post("/chat/Send-message", response_model=ChatResponse, summary="Send Message To Chatbot (Both Continuous and Initiate)")
async def initiate_chat(chat_request: ChatRequest) -> Dict[str, Any]:
    """
    Initiate a new chat conversation with immediate response ID and proper language handling.
    
    Args:
        chat_request: The request containing user information and message
        
    Returns:
        dict: The initial response with response_id and status
    """
    try:
        # Generate a consistent conversation ID
        if chat_request.chat_id == "fresh":
            conversation_id = f"conv_{chat_request.username}_{hash(chat_request.message) % 10000}"
            logger.info(f"Initiating chat for {chat_request.username} in {chat_request.language_name}")
        else:
            conversation_id = chat_request.chat_id

        current_time = chat_request.current_time
        # Get or create memory instance
        memory = get_or_create_memory(
            username=chat_request.username,
            chat_id=conversation_id
        )
        
        # Add user message to memory
        memory.add_user_message(chat_request.message)
        
        # Process message and get initial response
        initial_response = process_api_message(
            memory=memory,
            message=chat_request.message,
            username=chat_request.username,
            chat_id=conversation_id,
            language_code=chat_request.language_code,
            language_name=chat_request.language_name,
            enable_search=chat_request.enable_search,
            deep_search=chat_request.deep_search,
            current_time=current_time,
        )
        
        # Add conversation_id to the response
        initial_response["conversation_id"] = conversation_id
        return initial_response
        
    except Exception as e:
        logger.error(f"Failed to initiate chat: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to initiate chat: {str(e)}"
        )

class ChatHistoryRequest(BaseModel):
    username: str
    chat_id: str

class ChatHistoryResponse(BaseModel):
    username: str
    chat_id: str
    messages: List[Dict[str, Any]]
    status: str

@chat_router.post("/chat/history", response_model=ChatHistoryResponse, summary="Get Chat History")
async def get_chat_history(request: ChatHistoryRequest) -> Dict[str, Any]:
    try:
        history_file = os.path.join("chat_histories", request.username, f"{request.chat_id}.json")
        
        if not os.path.exists(history_file):
            logger.warning(f"Chat history file not found: {history_file}")
            return {
                "username": request.username,
                "chat_id": request.chat_id,
                "messages": [],
                "status": "success"
            }
            
        with open(history_file, 'r', encoding='utf-8') as f:
            history = json.load(f)
            
        processed_messages = []
        current_message = {}
        
        for msg in history:
            # Start a new conversation entry when user message is found
            if msg.get("role") == "user":
                if current_message:
                    processed_messages.append(current_message)
                current_message = {
                    "user_prompt": msg["content"],
                    "timestamp": msg.get("timestamp", ""),
                    "reasoning": "",
                    "response": ""
                }
            
            # Add reasoning if present
            elif msg.get("role") == "system" and msg.get("message_type") == "reasoning_process":
                if current_message:
                    current_message["reasoning"] = (
                        msg.get("translated_reasoning", "") 
                        if msg.get("translated_reasoning") 
                        else msg.get("original_reasoning", "")
                    )
            
            # Add response and its translation if present
            elif msg.get("role") == "assistant":
                if current_message:
                    current_message["response"] = msg["content"]
            
            elif msg.get("role") == "translate" and msg.get("direction") == "english_to_user":
                if current_message:
                    current_message["response"] = msg["content"]
        
        # Append the last message if exists
        if current_message:
            processed_messages.append(current_message)
            
        return {
            "username": request.username,
            "chat_id": request.chat_id,
            "messages": processed_messages,
            "status": "success"
        }
            
    except Exception as e:
        logger.error(f"Error reading chat history: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve chat history: {str(e)}"
        )
        
        
class UserChatsRequest(BaseModel):
    username: str

class ChatSummary(BaseModel):
    chat_id: str
    first_message: str
    timestamp: str

class UserChatsResponse(BaseModel):
    username: str
    chats: List[ChatSummary]
    status: str

@chat_router.post("/chat/user-chats", response_model=UserChatsResponse, summary="Get User's Chat History")
async def get_user_chats(request: UserChatsRequest) -> Dict[str, Any]:
    """
    Retrieve all chat IDs and the first message of each chat for a specific user.
    
    Args:
        request: UserChatsRequest containing username
        
    Returns:
        dict: List of chat IDs and their first messages
    """
    try:
        user_chats_dir = os.path.join("chat_histories", request.username)
        
        # Check if user directory exists
        if not os.path.exists(user_chats_dir):
            logger.warning(f"User chat history directory not found: {user_chats_dir}")
            return {
                "username": request.username,
                "chats": [],
                "status": "success"
            }
        
        chat_summaries = []
        
        # Get all json files in the user's chat history directory
        chat_files = [f for f in os.listdir(user_chats_dir) if f.endswith('.json')]
        
        for chat_file in chat_files:
            chat_id = chat_file.replace('.json', '')
            chat_file_path = os.path.join(user_chats_dir, chat_file)
            
            try:
                with open(chat_file_path, 'r', encoding='utf-8') as f:
                    chat_history = json.load(f)
                
                # Find the first user message
                first_message = ""
                timestamp = ""
                for msg in chat_history:
                    if msg.get("role") == "user":
                        first_message = msg.get("content", "")
                        timestamp = msg.get("timestamp", "")
                        break
                
                chat_summaries.append({
                    "chat_id": chat_id,
                    "first_message": first_message,
                    "timestamp": timestamp
                })
                
            except Exception as e:
                logger.error(f"Error reading chat file {chat_file}: {str(e)}")
                # Continue with other files if one fails
        
        # Sort by timestamp (newest first)
        chat_summaries.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
        
        return {
            "username": request.username,
            "chats": chat_summaries,
            "status": "success"
        }
            
    except Exception as e:
        logger.error(f"Error retrieving user chats: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve user chats: {str(e)}"
        )