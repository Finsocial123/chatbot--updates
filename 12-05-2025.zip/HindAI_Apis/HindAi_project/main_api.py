import logging
import sys
import os
from fastapi import FastAPI, Request, Depends, HTTPException, Header
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import APIKeyHeader
from typing import Optional
from HindAi_users.auth_api import router as auth_router
from htmlgen.api import router as html_router
from chatApis.chatapi import chat_router
from dotenv import load_dotenv

# Load environment variables from .env file
env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '.env')
load_dotenv(dotenv_path=env_path)
# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Define the API key security scheme
API_KEY = os.getenv("API_KEY")  # Load from .env file
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)



# Get the current directory for template loading
current_dir = os.path.dirname(os.path.abspath(__file__))
templates_dir = os.path.join(current_dir, "templates")
templates = Jinja2Templates(directory=templates_dir)


# Function to verify API key
async def verify_api_key(api_key: Optional[str] = Depends(api_key_header)):
    if api_key is None or api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")
    return api_key


# Create the FastAPI app instance (without docs)
app = FastAPI(
    title="HindAI API", 
    version="2.0.0",
    docs_url=None,  # Disable default docs
    )


# Include the HTML generation router
app.include_router(
    chat_router,
    prefix="/Chat-apis",
    tags=["Chat APIs"],
    responses={404: {"description": "Not found"}},
    dependencies=[Depends(verify_api_key)]  # Apply API key verification to all endpoints

)
# Include the HTML generation router
app.include_router(
    html_router,
    prefix="/html",
    tags=["HTML Generation"],
    responses={404: {"description": "Not found"}},
    dependencies=[Depends(verify_api_key)]  # Apply API key verification to all endpoints

)

# Include the auth router immediately after app creation
app.include_router(
    auth_router,
    prefix="/auth",
    tags=["Authentication"],
    responses={404: {"description": "Not found"}},
    dependencies=[Depends(verify_api_key)]  # Apply API key verification to all endpoints

)

@app.get("/")
async def root():
    return {"message": "HindAI API is running"}


# Custom Swagger UI endpoint
@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui(request: Request):
    return templates.TemplateResponse(
        "custom_swagger_ui.html",
        {
            "request": request,
            "openapi_url": app.openapi_url
        }
    )


# Add CORS middleware to FastAPI app
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5174",
        "http://localhost:5173",
        "http://localhost:3000",
        "http://localhost:9000",
        "https://hindai.finsocial.tech",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=[
        "Content-Type",
        "Authorization",
        "Accept",
        "Origin",
        "X-Requested-With",
        "X-CSRFTOKEN",
        "X-API-Key"  # Add the API key header to allowed headers
    ],
)
