import requests
from factcheckexplorer.factcheckexplorer import FactCheckLib

# Function to fetch fact checks using Google API
def fact_check_google(query, api_key):
    url = 'https://factchecktools.googleapis.com/v1alpha1/claims:search'
    params = {'query': query, 'key': api_key, 'languageCode': 'en-US'}
    
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        return data.get("claims", None)
    except requests.exceptions.RequestException as e:
        print(f"Google API Error: {e}")
        return None

# Function to fetch fact checks using FactCheckLib
def fact_check_lib(query, language="en", num_results=200):
    print(f"Searching fact-checks with FactCheckLib for: {query}")
    try:
        fact_check = FactCheckLib(query=query, language=language, num_results=num_results)
        fact_check.process()
        print("Fact-checking process completed. Check the CSV file for results.")
    except Exception as e:
        print(f"Error using FactCheckLib: {e}")
