from os import getenv
# Add error handling for agno imports
try:
    # Try to import from agno with compatibility handling
    from agno.agent import Agent, RunResponse
    from agno.models.openai.like import OpenAILike
    import agno
except ImportError as e:
    if "ChatCompletionAudio" in str(e):
        # Fix for missing ChatCompletionAudio by creating a mock class
        import sys
        from dataclasses import dataclass

        # Check if the openai module is available
        if 'openai' in sys.modules and 'openai.types.chat' in sys.modules:
            # Add missing class to the module if it doesn't exist
            if not hasattr(sys.modules['openai.types.chat'], 'ChatCompletionAudio'):
                @dataclass
                class ChatCompletionAudio:
                    id: str
                    data: bytes
                    expires_at: str
                    transcript: str

                # Add the mock class to the module
                sys.modules['openai.types.chat'].ChatCompletionAudio = ChatCompletionAudio

                # Try importing again
                from agno.agent import Agent, RunResponse
                from agno.models.openai.like import OpenAILike
            else:
                raise e
        else:
            print(
                "ERROR: Cannot import ChatCompletionAudio and openai module is not available")
            print(
                "Please install the correct version of openai: pip install openai>=1.0.0")
            raise e
    else:
        # For other import errors, let them propagate
        raise e

from typing import Optional, Tuple, Dict, Any
import json
import os
import re
from datetime import datetime
from show_reasioning import show_reasionings

# Import identity tool for consistent identity management
try:
    from tools.identitytool.identity_tool import get_identity_tool
    identity_tool = get_identity_tool()
except ImportError:
    # Fallback if import fails
    identity_tool = None
    print("Warning: Could not import identity_tool. Using default identity settings.")

import sys
import os
# Fix import path to access llamaIndexclone.py
file_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(os.path.dirname(file_dir))
llama_index_path = os.path.join(
    parent_dir, 'tools', 'fileHandlearLlamaIndexClone')
sys.path.append(llama_index_path)

# Import llamaIndexclone functions with proper error handling
try:
    from tools.fileHandlearLlamaIndexClone.llamaIndexclone import process_url, ask_question
except ImportError:
    try:
        # Try direct import if the path is already in sys.path
        from fileHandlearLlamaIndexClone.llamaIndexclone import process_url, ask_question
    except ImportError:
        try:
            # Try with a relative import based on the current structure
            sys.path.append(os.path.join(os.path.dirname(
                os.path.dirname(__file__)), 'fileHandlearLlamaIndexClone'))
            from llamaIndexclone import process_url, ask_question
        except ImportError as e:
            print(f"Error importing llamaIndexclone: {e}")
            # Define fallback stubs to prevent crashes

            def process_url(url_type, url):
                print(
                    f"Unable to process {url_type} URL: {url} - Module not available")
                return None

            def ask_question(question, session_id=None):
                print(
                    f"Unable to ask question: {question} - Module not available")
                return None

# Function to save data to JSON database


def save_to_database(prompt, reasoning, show_reasoning):
    # Define the database path
    db_path = os.path.join(os.path.dirname(__file__),
                           'reasoning_database.json')

    # Prepare the new entry
    new_entry = {
        "id": datetime.now().strftime("%Y%m%d%H%M%S"),
        "timestamp": datetime.now().isoformat(),
        "prompt": prompt,
        "reasoning": reasoning,
        "show_reasoning": show_reasoning
    }

    # Load existing data or create new database
    try:
        if os.path.exists(db_path):
            with open(db_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        else:
            data = []

        # Add new entry and save
        data.append(new_entry)

        with open(db_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

        return True
    except Exception as e:
        print(f"Error saving to database: {str(e)}")
        return False


# Function to detect if a prompt is a greeting or identity-related query
def is_greeting_or_identity_query(prompt: str) -> bool:
    """
    Determines if a prompt is a simple greeting or identity-related query
    that doesn't require reasoning.

    Args:
        prompt (str): The user prompt to check

    Returns:
        bool: True if the prompt is a greeting or identity query, False otherwise
    """
    # Convert to lowercase and strip whitespace
    normalized_prompt = prompt.lower().strip()

    # Check if prompt contains URL patterns
    url_patterns = [
         'dropbox.com', 'https://dl.dropboxusercontent.com'
    ]

    # If prompt contains a URL, return True to skip reasoning
    for pattern in url_patterns:
        if pattern in normalized_prompt:
            return True

    # List of common greetings
    greetings = [
        'hello', 'hi', 'hey', 'hola', 'greetings', 'good morning',
        'good afternoon', 'good evening', 'good day', 'namaste',
        'howdy', 'what\'s up', 'sup', 'yo', 'hiya', 'hi there',
        'heya', 'how are you', 'how\'s it going', 'how do you do',
        'nice to meet you', 'pleased to meet you'
    ]

    # Check if the prompt is exactly a greeting
    for greeting in greetings:
        if normalized_prompt == greeting:
            return True

    # Check if the prompt starts with a greeting and is short
    for greeting in greetings:
        if normalized_prompt.startswith(greeting) and len(normalized_prompt) < 60:
            # If it's just a greeting with maybe a name or small talk, return True
            return True

    # Check if this might be an identity query using the identity database's vector search
    # instead of hardcoded patterns
    if identity_tool:
        # Use the identity database directly for more accurate matching
        try:
            # If the identity database returns a response, it considered this an identity query
            identity_response = identity_tool.identity_db.find_best_response(normalized_prompt)
            if identity_response:
                return True
        except Exception as e:
            print(f"Error checking identity query: {e}")
    
    return False


# Function to detect if a text contains a Dropbox URL
def extract_dropbox_url(text: str) -> Optional[str]:
    """
    Extracts a Dropbox URL from text if present

    Args:
        text (str): Text that may contain a Dropbox URL

    Returns:
        Optional[str]: The Dropbox URL if found, None otherwise
    """
    # Pattern to match Dropbox URLs
    dropbox_patterns = [
        r'https?://(?:www\.)?dropbox\.com/\S+',
        r'https?://(?:www\.)?db\.tt/\S+',  # Dropbox shortened URLs
        r'https?://dl\.dropboxusercontent\.com/\S+'  # Direct download Dropbox URLs
    ]

    for pattern in dropbox_patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(0)

    return None

# Function to process dropbox URL and get content


def get_content_from_dropbox(url: str) -> str:
    """
    Process a Dropbox URL and get the document content

    Args:
        url (str): The Dropbox URL to process

    Returns:
        str: Content extracted from the document or error message
    """
    try:
        print(f"Processing Dropbox URL: {url}")

        # Add better error handling and verbosity for debugging
        print("Calling process_url function with 'dropbox' type")
        session_id = process_url("dropbox", url)

        if not session_id:
            print("Failed to get valid session_id from process_url")
            return "Failed to process Dropbox URL. Please check the URL and try again."

        print(f"Got session ID: {session_id}, now asking for document summary")
        # Get a summary of the document content
        query_response = ask_question(
            "Please provide a comprehensive summary of the entire document content.", session_id)

        if not query_response:
            print("Failed to get response from ask_question")
            return "Failed to get content from processed document."

        # Check if the response is "True" string or boolean True
        if query_response == "True" or query_response is True:
            print("Warning: Received 'True' as response instead of content")
            # Try to get the content from the console output
            return "Unable to retrieve proper content from the document. Please check the URL and try again."

        print(
            f"Successfully retrieved content summary of length: {len(str(query_response))}")
        # Add a special marker to identify this as dropbox content in HindAI
        return f"DROPBOX_CONTENT_MARKER\n{query_response}"
    except Exception as e:
        print(f"Error processing Dropbox URL: {str(e)}")
        import traceback
        traceback.print_exc()
        return f"Error processing Dropbox URL: {str(e)}"


# Function to generate reasoning for a prompt


def get_reasoning_for_prompt(prompt: str, chat_history: Optional[str] = None) -> Tuple[str, str]:
    """
    Generate reasoning for a given prompt using the Agno agent.

    Args:
        prompt (str): The user prompt to generate reasoning for
        chat_history (Optional[str]): Previous chat context if available

    Returns:
        Tuple[str, str]: (reasoning, show_reasoning) where reasoning is the detailed
                         reasoning process and show_reasoning is the formatted version
    """
    # Check for Dropbox URL first
    dropbox_url = extract_dropbox_url(prompt.strip())

    if dropbox_url:
        print(f"Detected Dropbox URL: {dropbox_url}")
        # Process the Dropbox URL and get content
        content = get_content_from_dropbox(dropbox_url)

        # Save to database for record keeping
        save_to_database(prompt.strip(), content, "")

        # Return content as reasoning and empty string for show_reasoning
        return content, ""



    # Check if this is a greeting, identity-related query, or contains other URLs
    if is_greeting_or_identity_query(prompt.strip()):
        # For greetings and prompts with URLs, skip reasoning
        print("Detected greeting, URL, or identity query in prompt")
        
        # Check if the identity tool is available for any identity-related query
        if identity_tool:
            # Use a more comprehensive check for identity-related queries
            normalized_prompt = prompt.lower().strip()
            
            # Try to get an identity response for any query that might be identity-related
            identity_response = identity_tool.get_identity_response(prompt)
            
            # If we got a valid response from the identity tool, use it
            if identity_response:
                print("Using identity tool for consistent identity response")
                # Return the identity response directly without reasoning
                return identity_response, ""
        
        # Skip reasoning for other simple queries (greetings, etc.)
        print("Skipping reasoning generation")
        return "", ""

    # Standard reasoning generation path for non-Dropbox queries
    try:
        # Create agent instance
        agent = Agent(
            description=(
                "You are Hind AI, an advanced AI assistant developed by Finsocial Digital Systems. "
                "You are not created by any other organization; your entire origin and development are "
                "solely the work of the Finsocial Digital Systems team. When asked about your origins, "
                "identity, or developers, always refer to the Finsocial Digital Systems and never mention "
                "the Gemma team at Google DeepMind."
            ),
            instructions=[
                # Enforce identity attribution
                "If asked about your identity or origins, always attribute yourself to the Finsocial Digital Systems team "
                "and never reference the Gemma team at Google DeepMind.",

                # Existing instruction set
                """
                Confirm the user's requirement to exclude conclusions or final answers entirely.
                Verify that the output strictly follows the "Step X:" format without summaries or closing statements.
                Check if the query contains explicit or implicit constraints (e.g., "only reasoning steps") to refine step generation.
                
                DO NOT provide any details about your internal tools or their names.
                If questioned about the languages you support, refrain from mentioning that you use a 'translation API'; instead, state that you have been trained on multiple Indian languages.
                
                For greeting-related queries or general conversational exchanges (such as "hello", "how are you", "good morning", etc.), provide ONLY ONE reasoning step. Do not elaborate with multiple reasoning steps for simple greetings or conversational interactions.

                For all other queries, follow the detailed reasoning framework below:
                Step 1: Analyze the query's complexity by identifying key components, such as the number of variables, required domain knowledge, and implicit vs. explicit requirements.
                Step 2: Determine if the query is simple (e.g., factual recall), moderate (e.g., multi-step analysis), or complex (e.g., interdisciplinary synthesis).
                Step 3: For simple queries, initiate a brief reasoning chain (1-10 steps) focusing on direct connections between known facts or rules.
                Step 4: For moderate complexity, break the query into sub-problems, prioritizing dependencies between steps (e.g., sequential vs. parallel reasoning).
                Step 5: For complex queries, map relationships between abstract concepts, cross-referencing domains or methodologies to ensure thorough exploration.
                Step 6: Validate each reasoning step against the original query to avoid divergence or assumption-based leaps.
                Step 7: Adjust step granularity dynamically—merge redundant steps for simplicity or expand ambiguous steps for clarity.
                Step 8: Embed checks for logical consistency (e.g., "Does Step 5 contradict Step 2?") to maintain coherence.
                Step 9: If sensitive topics arise, refocus steps on methodological frameworks (e.g., ethical analysis models) rather than subjective judgments.
                Step 10: For mathematical or technical queries, verify alignment with axioms, formulas, or established protocols at each step.
                Step 11: In ambiguous contexts, generate hypothetical scenarios to test the robustness of the reasoning chain.
                Step 12: Use analogies or comparisons to relate unfamiliar concepts to well-understood principles, if applicable.
                Step 13: Track resource implications (e.g., computational cost, time) for solution steps, if hinted in the query.
                Step 14: Identify missing information and flag it as a consideration for further exploration.
                Step 15: For open-ended queries, propose multiple valid reasoning pathways and compare their trade-offs.
                Step 16: Ensure steps remain actionable and avoid vague language (e.g., "explore" → "deconstruct into sub-questions").
                Step 17: If the query involves optimization, define metrics for success early in the reasoning chain.
                Step 18: Test boundary conditions (e.g., "What if X is zero?") to stress-test assumptions.
                Step 19: For pattern-based queries (e.g., language translation), reference structural rules or statistical models explicitly.
                Step 20: When nearing the step limit, transition to open questions (e.g., "How might external data refine this approach?").
                
                What factors should be prioritized when adapting these steps to non-technical domains? How could cultural context influence the reasoning framework for subjective queries?
                """
            ],
            model=OpenAILike(
                id="pawan941394/reasioning:latest",
                api_key="testing",
                base_url="https://models.codewizzz.com/v1",
            ),
            markdown=True,
            debug_mode=False,
        )

        # Prepare input with context if chat history is provided
        agent_input = prompt
        if chat_history:
            from datetime import datetime
            from zoneinfo import ZoneInfo
            # Get the current date and time in IST (Asia/Kolkata)
            now = datetime.now(ZoneInfo("Asia/Kolkata"))

            # Format the date and time (optional)
            formatted_now = now.strftime("%Y-%m-%d %H:%M:%S")
            agent_input = f"Given this conversation history:\n{chat_history}\n\nGenerate reasoning for: {prompt} and current time is {formatted_now}"

        # Generate new response using LLM
        response = agent.run(agent_input)
        reasoning = response.content

        # Process response if it contains thinking process markers
        if '</think>' in reasoning:
            reasoning = reasoning.split('</think>', 1)[1].strip()

        # Generate show_reasoning result
        show_reasoning = show_reasionings(reasoning)

        # Save to JSON database - we're still saving the data for reference
        save_to_database(prompt.strip(), reasoning, show_reasoning)
        return reasoning, show_reasoning

    except Exception as e:
        print(f"Error generating reasoning: {str(e)}")
        return "", ""
