from agno.agent import Agent
from agno.models.openai.like import OpenAILike
from typing import Optional, Tuple
import os
from datetime import datetime
import json

# Try to import KeyDB client if available
try:
    from keydb_data_inserter import KeyDBClient
    keydb = KeyDBClient(host='localhost', port=6379)
    has_keydb = True
except ImportError:
    has_keydb = False

def classify_query(query: str) -> str:
    """
    Classify a query as either 'generic' or 'user-specific'
    
    Args:
        query: The input query to classify
        
    Returns:
        String containing either 'generic' or 'user-specific'
    """
    try:
        # Check cache first if KeyDB is available
        if has_keydb:
            query_key = f"classification:{query.strip()}"
            cached_data = keydb.get_json(query_key)
            
            if cached_data and "classification" in cached_data:
                print(f"Found cached classification for query: {query[:50]}...")
                return cached_data["classification"]
        
        # Create the agent for classification
        agent = Agent(
            description="You are a query classification agent",
            instructions=[
                "Determine whether user queries are generic or user-specific.",
                "Generic queries: General knowledge questions, facts, concepts, or information that applies broadly.",
                "User-specific queries: Questions about personal situations, individual preferences, or requests for personalized advice.",
                "IMPORTANT: Respond ONLY with the word 'generic' or 'user-specific' with no additional text or explanation.",
                "Always use lowercase for your response."
            ],
            model=OpenAILike(
                id="llama2",
                api_key='testing',
                base_url="https://significant-carly-finsocialdigitalsystem-9db3a8e3.koyeb.app/v1",
            ),
            markdown=False,
            debug_mode=False,
        )
        
        # Prepare the prompt for classification
        prompt = f"Classify this query as either 'generic' or 'user-specific': {query}"
        
        # Run the agent
        response = agent.run(prompt)
        
        # Extract the classification (ensure it's lowercase and stripped)
        result = response.content.strip().lower()
        
        # Validate and normalize the result
        if "generic" in result:
            classification = "generic"
        elif "user-specific" in result or "user specific" in result:
            classification = "user-specific"
        else:
            # Default to generic if response is unexpected
            print(f"Unexpected classification result: '{result}'. Defaulting to 'generic'")
            classification = "generic"
        
        # Save to cache if KeyDB is available
        if has_keydb:
            data = {
                "timestamp": datetime.now().isoformat(),
                "query": query,
                "classification": classification,
                "raw_response": result
            }
            keydb.set_json(query_key, data)
            print(f"Classification saved to KeyDB with key: {query_key}")
        
        # Also save to local JSON database
        save_to_database(query, classification, result)
        
        return classification
            
    except Exception as e:
        print(f"Error classifying query: {str(e)}")
        # Default to generic on error
        return "generic"

def save_to_database(query, classification, raw_response):
    """Save classification data to JSON database"""
    # Define the database path
    db_path = os.path.join(os.path.dirname(__file__), 'classification_database.json')
    
    # Prepare the new entry
    new_entry = {
        "id": datetime.now().strftime("%Y%m%d%H%M%S"),
        "timestamp": datetime.now().isoformat(),
        "query": query,
        "classification": classification,
        "raw_response": raw_response
    }
    
    # Load existing data or create new database
    if os.path.exists(db_path):
        try:
            with open(db_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
        except json.JSONDecodeError:
            # If file exists but is corrupted
            data = {"entries": []}
    else:
        data = {"entries": []}
    
    # Add new entry to database
    data["entries"].append(new_entry)
    
    # Save updated database
    with open(db_path, 'w', encoding='utf-8') as file:
        json.dump(data, file, indent=4, ensure_ascii=False)
    
    print(f"Classification data saved to database with ID: {new_entry['id']}")

# Example usage
if __name__ == "__main__":
    # Define test queries
    test_queries = [
        "What is algorithmic trading?",
        "Can you tell me what stocks I should buy?",
        "How do I improve my personal finance situation?",
        "What is the capital of France?",
        "I'm looking for investment advice for my retirement"
    ]
    # Test classification on each query
    for query in test_queries:
        result = classify_query(query)
        print(f"Query: '{query}'\nClassification: {result}\n")
