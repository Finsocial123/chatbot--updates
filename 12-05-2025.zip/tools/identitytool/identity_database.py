import json
from typing import Optional, List
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import os

class IdentityDatabase:
    def __init__(self):
        self.dataset_path = os.path.join(os.path.dirname(__file__), 'identity_dataset.jsonl')
        self.vectorizer = TfidfVectorizer(stop_words='english')
        self.identity_data = []
        self.vectors = None
        self.load_and_vectorize_data()

    def load_and_vectorize_data(self):
        """Load the identity dataset and create vectors"""
        try:
            # Load data
            with open(self.dataset_path, 'r', encoding='utf-8') as f:
                for line in f:
                    entry = json.loads(line.strip())
                    self.identity_data.append(entry)

            # Create vectors from user messages
            user_messages = [entry['messages'][0]['content'].lower() for entry in self.identity_data]
            self.vectors = self.vectorizer.fit_transform(user_messages)
            
        except Exception as e:
            print(f"Error loading/vectorizing identity dataset: {e}")
            self.identity_data = []
            self.vectors = None

    def find_best_response(self, query: str, threshold: float = 0.3) -> Optional[str]:
        """Find the best matching response using vector similarity"""
        if not self.vectors is not None or not self.identity_data:
            return None

        try:
            # Vectorize the query
            query_vector = self.vectorizer.transform([query.lower()])
            
            # Calculate similarities
            similarities = cosine_similarity(query_vector, self.vectors)[0]
            
            # Find best match above threshold
            best_idx = np.argmax(similarities)
            if similarities[best_idx] >= threshold:
                return self.identity_data[best_idx]['messages'][1]['content']
            
            return None

        except Exception as e:
            print(f"Error finding response: {e}")
            return None

    def get_all_responses(self) -> List[dict]:
        """Get all identity responses"""
        return self.identity_data

    def add_response(self, user_query: str, bot_response: str) -> bool:
        """Add a new identity response pair"""
        try:
            new_entry = {
                "messages": [
                    {"role": "user", "content": user_query},
                    {"role": "assistant", "content": bot_response}
                ]
            }
            
            # Add to file
            with open(self.dataset_path, 'a', encoding='utf-8') as f:
                f.write(json.dumps(new_entry) + '\n')
            
            # Update in-memory data
            self.identity_data.append(new_entry)
            
            # Re-vectorize
            self.load_and_vectorize_data()
            
            return True
        except Exception as e:
            print(f"Error adding response: {e}")
            return False

# Singleton instance
_identity_db = None

def get_identity_database():
    """Get the singleton instance of IdentityDatabase"""
    global _identity_db
    if _identity_db is None:
        _identity_db = IdentityDatabase()
    return _identity_db