import base64
from io import BytesIO
import sys
import asyncio
import httpx
from PIL import Image
import time
import cloudinary
import cloudinary.uploader
import uuid
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Cloudinary configuration
cloudinary.config( 
    cloud_name = "dgeh2n2pz", 
    api_key = "259884111835688", 
    api_secret = "t7r0IlbiHQ6Kn2EQSsLxMJSUiBg",
    secure=True
)

KOYEB_URL = "https://flux-1-dev-finsocialdigitalsystem-f67d8bea.koyeb.app"

# Create a persistent client manager
class AsyncClientManager:
    _instance = None
    _client = None
    _lock = asyncio.Lock()

    @classmethod
    async def get_client(cls):
        if cls._client is None or cls._client.is_closed:
            cls._client = httpx.AsyncClient(
                timeout=120.0,
                limits=httpx.Limits(max_keepalive_connections=5, max_connections=10),
                headers={'Accept-Encoding': 'gzip, deflate'}
            )
        return cls._client

    @classmethod
    async def close(cls):
        if cls._client and not cls._client.is_closed:
            await cls._client.aclose()
            cls._client = None

async def b64_to_pil(base64_string):
    """Optimized Base64 to PIL Image conversion"""
    if base64_string.startswith("data:image"):
        base64_string = base64_string.split(",", 1)[1]
    
    image_data = base64.b64decode(base64_string)
    return Image.open(BytesIO(image_data))

async def generate_and_upload_image(prompt: str, username: str):
    """Generate and upload image with persistent client"""
    payload = {"prompt": prompt}
    
    try:
        start_time = time.time()
        
        # Get the persistent client
        client = await AsyncClientManager.get_client()
        
        response = await client.post(
            f"{KOYEB_URL}/predict",
            json=payload
        )
        response.raise_for_status()
        response_data = response.json()

        if not response_data or 'images' not in response_data or not response_data['images']:
            logger.error("Invalid response from server")
            return None

        # Generate unique ID
        unique_id = str(uuid.uuid4())[:8]
        public_id = f"{username}_{unique_id}"

        # Convert base64 to image data
        base64_data = response_data['images'][0]
        if base64_data.startswith("data:image"):
            base64_data = base64_data.split(",", 1)[1]
        
        # Upload to Cloudinary with folder specification
        upload_result = cloudinary.uploader.upload(
            f"data:image/jpeg;base64,{base64_data}",
            public_id=public_id,
            folder=f"HindAI/{username}"
        )
        
        end_time = time.time()
        logger.info(f"Image generated and uploaded in {end_time - start_time:.2f} seconds")
        return upload_result["secure_url"]

    except (httpx.RequestError, httpx.HTTPStatusError) as e:
        logger.error(f"Network error: {e}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return None

# Cleanup function to be called when shutting down
async def cleanup():
    await AsyncClientManager.close()

if __name__ == "__main__":
    prompt = "Futurastic logo for the company 'Finsocial digital systems'"
    username = "testuser"
    
    async def test():
        result = await generate_and_upload_image(prompt, username)
        if result:
            print(f"Generated image URL: {result}")
        await cleanup()
    
    asyncio.run(test())