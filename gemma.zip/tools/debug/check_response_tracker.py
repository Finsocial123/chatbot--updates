#!/usr/bin/env python
# Tool to examine the response_tracker data structure

import sys
import os
import json
import argparse
import time

# Add the parent directory to the path so we can import from our modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import the response tracker
try:
    from HindAI_Apis.chat_api import response_tracker
except ImportError:
    print("Error: Could not import response_tracker. Run this script from the correct directory.")
    sys.exit(1)

def list_responses(verbose=False, output_file=None):
    """List all responses in the tracker"""
    print(f"Response tracker contains {len(response_tracker)} entries.")
    
    if not response_tracker:
        print("No responses in tracker.")
        return
    
    # Prepare output
    output_data = []
    
    for response_id, data in response_tracker.items():
        status = data.get("status", "unknown")
        chat_id = data.get("chat_id", "unknown")
        start_time = data.get("start_time", 0)
        elapsed = time.time() - start_time if start_time else "unknown"
        
        response_data = {
            "response_id": response_id,
            "chat_id": chat_id,
            "status": status,
            "elapsed_time": elapsed if isinstance(elapsed, str) else f"{elapsed:.1f}s",
        }
        
        # Print summary
        print(f"ID: {response_id} | Chat: {chat_id} | Status: {status} | Time: {response_data['elapsed_time']}")
        
        # Add more details if verbose
        if verbose:
            has_reasoning = bool(data.get("reasoning"))
            has_response = bool(data.get("response"))
            has_error = bool(data.get("error"))
            
            print(f"  Has reasoning: {has_reasoning}")
            print(f"  Has response: {has_response}")
            print(f"  Has error: {has_error}")
            
            if has_response:
                response = data.get("response", "")
                print(f"  Response length: {len(response)} chars")
                if len(response) > 100:
                    print(f"  Response preview: {response[:100]}...")
                else:
                    print(f"  Response: {response}")
            
            response_data.update({
                "has_reasoning": has_reasoning,
                "has_response": has_response,
                "has_error": has_error,
                "response_length": len(data.get("response", "")) if has_response else 0
            })
            
            if has_error:
                error_msg = data.get("error", "")
                print(f"  Error: {error_msg}")
                response_data["error"] = error_msg
        
        output_data.append(response_data)
        print()
    
    # Write to file if specified
    if output_file:
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(output_data, f, indent=2)
            print(f"Response data written to {output_file}")
        except Exception as e:
            print(f"Error writing to file: {e}")

def get_response(response_id):
    """Get details of a specific response"""
    if response_id not in response_tracker:
        print(f"Response ID {response_id} not found in tracker.")
        return
    
    data = response_tracker[response_id]
    
    print(f"Response ID: {response_id}")
    print(f"Chat ID: {data.get('chat_id', 'unknown')}")
    print(f"Status: {data.get('status', 'unknown')}")
    
    start_time = data.get("start_time", 0)
    if start_time:
        elapsed = time.time() - start_time
        print(f"Elapsed time: {elapsed:.1f} seconds")
    
    if "reasoning" in data:
        reasoning = data["reasoning"]
        print(f"\nReasoning ({len(reasoning)} chars):")
        print(reasoning)
    
    if "response" in data:
        response = data["response"]
        print(f"\nResponse ({len(response)} chars):")
        print(response)
    
    if "error" in data:
        error = data["error"]
        print(f"\nError: {error}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Examine the response tracker.")
    parser.add_argument("--list", "-l", action="store_true", help="List all responses")
    parser.add_argument("--verbose", "-v", action="store_true", help="Show verbose output")
    parser.add_argument("--get", "-g", help="Get details for a specific response ID")
    parser.add_argument("--output", "-o", help="Output file for response data (JSON)")
    
    args = parser.parse_args()
    
    if args.list:
        list_responses(args.verbose, args.output)
    elif args.get:
        get_response(args.get)
    else:
        parser.print_help()
