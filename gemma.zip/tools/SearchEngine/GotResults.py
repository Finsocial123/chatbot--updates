import re
from concurrent.futures import ThreadPoolExecutor

# Import modules from our new files
from search_engines import search_duckduckgo, search_searxng, search_google, filter_unique_results
from fact_checking import fact_check_google, fact_check_lib
from content_processing import generate_summaries

# Parallel Execution of Searches
def search_combined(query, api_key):
    print(f"\n Searching for: {query}\n")
    
    with ThreadPoolExecutor(max_workers=4) as executor:
        future_duck = executor.submit(search_duckduckgo, query, 10)
        future_searx = executor.submit(search_searxng, query, 10)
        future_google = executor.submit(search_google, query, 10)
        # future_fact_check = executor.submit(fact_check_google, query, api_key)

        duck_results = future_duck.result() or []
        searx_results = future_searx.result() or []
        google_results = future_google.result() or []
        # fact_check_results = future_fact_check.result() or []
    
    combined_results = duck_results + searx_results + google_results
    unique_results = filter_unique_results(combined_results)
    return unique_results ,''
    # return unique_results, fact_check_results

# Main function
def main(query=None):
    # Google Fact Check API key
    api_key = "AIzaSyDg7YkIOeEeGnwUtxBdSbHqRcOrQMKYu3s" 
    
    # Allow passing the query as a parameter for tool usage
    if query is None:
        query = input("Enter your query: ")
        
    top_results, fact_check_results = search_combined(query, api_key)

    print(f"\n Checking fact-checks using Google API for: {query}")
    # if not fact_check_results:
    #     print(" No Fact-Checked Results Found from Google API. Trying FactCheckLib...")
    #     fact_check_lib(query)

    print("\n Generating AI Summaries for Each Source:")
    summaries = generate_summaries(query, top_results)
    final_output = {}
    summary_of_Content = []
    urls = []
    titles = []
    for i, summary in enumerate(summaries):
        summary_of_Content.append(summary['summary'])
        urls.append(summary['url'])
        titles.append(summary['title'])
    final_output['titles'] = titles
    final_output['urls'] = urls
    final_output['summary'] = summary_of_Content
    return final_output

if __name__ == "__main__":
    print(main())
