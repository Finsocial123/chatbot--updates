import requests
from bs4 import BeautifulSoup
from langchain_ollama import OllamaLLM

# Initialize LLM
llm = OllamaLLM(model="llama3.2:1b", base_url="https://9x1ss87w0k4vfg-11434.proxy.runpod.net")

# Fetch Webpage Content
def fetch_content(url):
    try:
        headers = {"User-Agent": "Mozilla/5.0"}
        response = requests.get(url, headers=headers, timeout=5)
        
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, "html.parser")
            return soup.get_text(separator="\n", strip=True) or "No readable text found."
    except requests.RequestException as e:
        return f"Failed to retrieve content: {str(e)}"

# Generate Summary using LLM
def generate_summaries(query, results):
    summaries = []
    for result in results:
        url, title = result["url"], result["title"]
        content = fetch_content(url)
        
        if content and content != "No readable text found.":
            prompt = f"""Provide a comprehensive and detailed summary of the following content.
Include all important information, key facts, main arguments, and significant details:

{content}"""
            summary = llm.invoke(prompt)
            summaries.append({"title": title, "url": url, "summary": summary})
        else:
            summaries.append({"title": title, "url": url, "summary": "Content could not be summarized."})
    return summaries
