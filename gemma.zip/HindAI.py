"""HindAI main module"""
from imports_lib import *
import agno  # Import Agno
from openai import OpenAI  # Import OpenAI client directly for compatibility
from prompt_template import prompt_temp  # Import the prompt template
from tool_registry import get_all_tools, get_current_time, get_chatbot_info, get_identity_response
# Import the tool package
import sys
import os
from typing import Tuple
import requests
import langid
# Import only what we need from translator module
from translator import LanguageTranslator, show_language_menu

# Add the reasoning module path to sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), 'tools', 'resioning'))
from tools.resioning.reasioning import get_reasoning_for_prompt

# Import search tool
sys.path.append(os.path.join(os.path.dirname(__file__), 'tools', 'SearchEngine'))
from tools.SearchEngine.GotResults import main as search_internet

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
api_key = "sk-27185f30930a4613b26d90666082c23b"
base_url = "https://shivering-eleen-finsocialdigitalsystem-ccf7f279.koyeb.app/v1"

# Initialize client using the OpenAI client with Agno's base URL
# This is the correct approach per Agno documentation - they use OpenAI-compatible API
agno_client = OpenAI(
    api_key=api_key,
    base_url=base_url
)

# Define the model to use with Agno
model = "pawan941394/hind-ai:latest"  # Keep using your preferred model

# Set up a global flag for search preference
search_enabled = False

# Create global translator instance
translator = LanguageTranslator()

# User language settings
user_language = {
    "code": "eng_Latn",  # Default to English
    "name": "English"
}

# Add a web search tool function
def search_web(query: str) -> str:
    """
    Search the web for information on the given query.
    Only available when web search feature is enabled.
    
    Args:
        query: The search query
        
    Returns:
        String containing search results
    """
    if not search_enabled:
        return "Web search is disabled. Please enable web search to use this feature."
    
    try:
        logger.info(f"Performing web search for: {query}")
        search_results = search_internet(query)
        
        # Format the results
        formatted_results = "Web Search Results:\n\n"
        
        # Add summaries
        if search_results.get('summary') and len(search_results.get('summary')) > 0:
            formatted_results += "Summary of search results:\n"
            for i, summary in enumerate(search_results['summary'][:3]):  # Limit to top 3 summaries
                title = search_results['titles'][i] if i < len(search_results['titles']) else "Unknown Source"
                url = search_results['urls'][i] if i < len(search_results['urls']) else "Unknown URL"
                formatted_results += f"\n--- Source {i+1}: {title} ---\n"
                formatted_results += f"{summary}\n"
                formatted_results += f"URL: {url}\n\n"
        else:
            formatted_results += "No relevant information found for your query."
            
        return formatted_results
    except Exception as e:
        logger.error(f"Error in web search: {e}")
        return f"An error occurred during web search: {str(e)}"

# Define a custom tool for web search
web_search_tool = {
    "type": "function",
    "function": {
        "name": "search_web",
        "description": "Search the internet for current information on a given topic. Use this when the user asks for recent information, news, or any factual data that might not be in your training data.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query to look up online"
                }
            },
            "required": ["query"]
        }
    }
}

# Create dynamic function to get all tools based on search_enabled status
def get_all_tools():
    from tool_registry import get_all_tools as base_get_all_tools
    
    # Get the base tools
    tools = base_get_all_tools()
    
    # Add web search tool only if search is enabled
    if search_enabled:
        tools.append(web_search_tool)
        
    return tools

# Initialize agno_functions globally but we'll update it when search_enabled changes
agno_functions = get_all_tools()

class AgnoMemory:
    """Memory class to mimic LangChain's memory interface but using Agno"""
    def __init__(self, username: str, chat_id: str = None):
        self.username = username
        self.chat_id = chat_id or str(uuid.uuid4())
        self.base_path = "chat_histories"
        self.messages = []
        self.user_path = os.path.join(self.base_path, sanitize_filename(self.username))
        self.file_path = os.path.join(self.user_path, f"{sanitize_filename(self.chat_id)}.json")
        self._initialize_storage()
        self._load_history()

    def _initialize_storage(self):
        """Initialize storage with safe paths"""
        try:
            os.makedirs(self.user_path, exist_ok=True)
            
            # Create empty file if it doesn't exist
            if not os.path.exists(self.file_path):
                with open(self.file_path, 'w', encoding='utf-8') as f:
                    json.dump(self.messages, f, indent=2)
        except Exception as e:
            logger.error(f"Error initializing storage: {e}")
            raise RuntimeError(f"Failed to initialize chat storage: {e}")

    def _save_history(self):
        """Save chat history with improved error handling and fallback"""
        try:
            # Try direct write first
            try:
                with open(self.file_path, 'w', encoding='utf-8') as f:
                    json.dump(self.messages, f, indent=2)
                return
            except PermissionError:
                pass
            # Fallback to user's temp directory if needed
            temp_dir = os.path.join(os.path.expanduser('~'), '.finso_temp')
            os.makedirs(temp_dir, exist_ok=True)
            temp_path = os.path.join(temp_dir, f"{self.chat_id}.json")
            
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(self.messages, f, indent=2)
        except Exception as e:
            logger.warning(f"Could not save chat history: {e}")
            # Continue without saving rather than raising an error
            pass

    def _load_history(self):
        """Load chat history with fallback to temp location"""
        try:
            # Try primary location
            if os.path.exists(self.file_path):
                with open(self.file_path, 'r', encoding='utf-8') as f:
                    self.messages = json.load(f)
            else:
                # Try fallback location
                temp_path = os.path.join(
                    os.path.expanduser('~'),
                    '.finso_temp',
                    f"{self.chat_id}.json"
                )
                if os.path.exists(temp_path):
                    with open(temp_path, 'r', encoding='utf-8') as f:
                        self.messages = json.load(f)
                else:
                    self.messages = []
        except Exception as e:
            logger.warning(f"Could not load chat history: {e}")
            # Continue with empty history rather than raising an error
            self.messages = []
            
    def _get_timestamp(self):
        """Get current timestamp in ISO format"""
        return datetime.now().isoformat()

    def add_user_message(self, content):
        """Add a user message to the history"""
        self.messages.append({
            "role": "user",
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
        self._save_history()

    def add_ai_message(self, content):
        """Add an AI message to the history"""
        self.messages.append({
            "role": "assistant",
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
        self._save_history()
        
    def add_translation(self, original_text, translated_text, direction):
        """Add a translation to the history
        
        Args:
            original_text: The original text before translation
            translated_text: The translated text
            direction: Either "user_to_english" or "english_to_user"
        """
        self.messages.append({
            "role": "translate",
            "content": translated_text,
            "original_text": original_text,
            "direction": direction,
            "timestamp": datetime.now().isoformat()
        })
        self._save_history()

    def get_messages_for_api(self):
        """Return messages in format needed for Agno API"""
        formatted = []
        for msg in self.messages:
            # Skip reasoning process and translation messages for the API
            if msg.get("message_type") == "reasoning_process" or msg.get("role") == "translate":
                continue
            formatted.append({"role": msg["role"], "content": msg["content"]})
        return formatted

    def get_last_human_message(self):
        """Get the last message from human"""
        for msg in reversed(self.messages):
            if msg["role"] == "user":
                return msg["content"]
        return ""

    def get_username(self) -> str:
        """Get the current username"""
        return self.username

    def get_formatted_history(self) -> str:
        """Get formatted history for display"""
        formatted = []
        for msg in self.messages:
            # Skip special message types for regular history display
            if msg.get("message_type") == "reasoning_process":
                continue
            
            if msg["role"] == "user":
                formatted.append(f"Human: {msg['content']}")
            elif msg["role"] == "assistant":
                formatted.append(f"Assistant: {msg['content']}")
            elif msg["role"] == "translate":
                direction = msg.get("direction", "")
                original = msg.get("original_text", "")
                if direction == "user_to_english":
                    formatted.append(f"[Translated User Input] Original: '{original}' → English: '{msg['content']}'")
                elif direction == "english_to_user":
                    formatted.append(f"[Translated Response] English: '{original}' → {user_language['name']}: '{msg['content']}'")
        
        return "\n".join(formatted)

    def clear(self):
        """Clear the chat history"""
        self.messages = []
        if os.path.exists(self.file_path):
            os.remove(self.file_path)

    # New method to add reasoning (original and translated) in one entry
    def add_reasoning(self, input_text: str, original_reasoning: str, translated_reasoning: str = None):
        """
        Add a reasoning entry combining original and translated reasoning.
        """
        try:
            # Remove any existing reasoning entries
            self.messages = [msg for msg in self.messages 
                           if not (msg.get("role") == "system" and 
                                  msg.get("message_type") == "reasoning_process")]
            
            # Log the operation
            logger.info(f"Adding reasoning - Original length: {len(original_reasoning)}")
            if translated_reasoning:
                logger.info(f"Translated length: {len(translated_reasoning)}")
            
            # Create reasoning entry
            reasoning_entry = {
                "role": "system",
                "input_text": input_text,
                "original_reasoning": original_reasoning,
                "translated_reasoning": translated_reasoning,
                "timestamp": self._get_timestamp(),
                "message_type": "reasoning_process",
                "language": user_language["code"]
            }
            
            # Add and save immediately
            self.messages.append(reasoning_entry)
            
            # Force immediate save
            try:
                with open(self.file_path, 'w', encoding='utf-8') as f:
                    json.dump(self.messages, f, ensure_ascii=False, indent=2)
                logger.info("Successfully saved reasoning to file")
            except Exception as save_error:
                logger.error(f"Error saving to file: {save_error}")
                # Try fallback save
                self._save_history()
            
            # Log success
            logger.info(f"Added reasoning entry - Translation: {'Yes' if translated_reasoning else 'No'}")
            
            if translated_reasoning:
                logger.info(f"Translation preview: {translated_reasoning[:100]}...")
                
        except Exception as e:
            logger.error(f"Error in add_reasoning: {str(e)}", exc_info=True)
            # Try to save what we can
            self.messages.append(reasoning_entry)
            self._save_history()

    def get_last_reasoning(self, translated: bool = False) -> str:
        """
        Get the most recent reasoning, either original or translated.
        
        Args:
            translated: If True, return translated reasoning if available
            
        Returns:
            The reasoning text or empty string if none found
        """
        for msg in reversed(self.messages):
            if msg.get("role") == "system" and msg.get("message_type") == "reasoning_process":
                if translated and msg.get("translated_reasoning"):
                    return msg["translated_reasoning"]
                elif not translated and msg.get("original_reasoning"):
                    return msg["original_reasoning"]
        return ""

# Optional: Add a special command to toggle code translation
def toggle_code_translation():
    """Toggle whether code should be translated or preserved"""
    global translate_code
    translate_code = not translate_code
    return translate_code

def get_enhanced_reasoning(query: str, chat_history: str = "") -> Tuple[str, str]:
    """
    Get reasoning from the reasoning module for the given query
    
    Args:
        query: The input query to generate reasoning for
        chat_history: Optional chat history to provide context
        
    Returns:
        Tuple containing (raw_reasoning, show_reasoning)
    """
    try:
        reasoning, show_reasoning = get_reasoning_for_prompt(query, chat_history)
        logger.info("Successfully generated reasoning")
        return reasoning, show_reasoning
    except Exception as e:
        logger.error(f"Error generating reasoning: {e}")
        return "", ""

# Add a function to dynamically set the search preference
def set_search_enabled(enable: bool = False) -> bool:
    """
    Set the search preference dynamically and update available tools
    
    Args:
        enable (bool): Whether to enable web search (default: False)
        
    Returns:
        bool: The current search preference status
    """
    global search_enabled, agno_functions
    
    # Only update if the value changes to avoid unnecessary tool updates
    if search_enabled != enable:
        search_enabled = enable
        # Update available tools
        agno_functions = get_all_tools()
        logger.info(f"Updated search preference: {search_enabled}")
        logger.info(f"Updated available tools: {len(agno_functions)} tools")
    
    return search_enabled

# Update get_search_preference function to use the new set_search_enabled
def get_search_preference():
    """Get user's web search feature preference"""
    while True:
        choice = input("\nDo you want to enable web search features? (yes/no): ").lower().strip()
        if choice in ['yes', 'y']:
            return set_search_enabled(True)
        elif choice in ['no', 'n']:
            return set_search_enabled(False)
        print("Please enter 'yes' or 'no'")

def format_tool_responses(messages):
    """
    Format tool response messages to ensure compatibility with OpenAI API
    
    Args:
        messages: List of message objects that might contain tool responses
        
    Returns:
        List of properly formatted messages for API consumption
    """
    formatted_messages = []
    
    for msg in messages:
        # Normal messages pass through unchanged
        if not isinstance(msg, dict) or msg.get("role") != "tool":
            formatted_messages.append(msg)
            continue
        
        # Format tool messages according to OpenAI API specification
        formatted_tool_msg = {
            "role": "tool",
            "content": str(msg.get("content", "")),
        }
        
        # Add tool_call_id if present
        if "tool_call_id" in msg:
            formatted_tool_msg["tool_call_id"] = msg["tool_call_id"]
        
        formatted_messages.append(formatted_tool_msg)
    
    return formatted_messages

# ...existing code...

# Update the function to process messages according to Agno API
def process_message_and_get_response(username: str, message: str, chat_id: str = None, 
                                    reasoning: str = None, show_reasoning: str = None) -> str:
    """Process a message with reasoning and translation"""
    # Make sure we have a valid chat_id
    if not chat_id:
        chat_id = str(uuid.uuid4())
        logger.info(f"Generated new chat ID: {chat_id}")
    else:
        logger.info(f"Using existing chat ID: {chat_id}")
    
    # Log search preference status
    logger.info(f"Search enabled: {search_enabled}")
    
    # Initialize memory with the given chat_id
    agent_memory = AgnoMemory(username=username, chat_id=chat_id)
    
    # Log whether this is a new or existing chat
    logger.info(f"Chat history loaded for {chat_id}. Message count: {len(agent_memory.messages)}")
    
    # Add user message to history (store original message)
    # Skip if the message is already in memory (in case it was added by caller)
    if not agent_memory.messages or agent_memory.messages[-1]["role"] != "user" or agent_memory.messages[-1]["content"] != message:
        agent_memory.add_user_message(message)
    
    # Get messages for Agno API
    raw_messages = agent_memory.get_messages_for_api()
    
    # Get formatted chat history for context
    chat_history = agent_memory.get_formatted_history()
    
    # Generate reasoning only if not already provided
    if reasoning is None or show_reasoning is None:
        # Get reasoning from the reasoning module with chat history
        reasoning, show_reasoning = get_enhanced_reasoning(message, chat_history)
    
    # Check if the reasoning contains the Dropbox content marker
    if reasoning and reasoning.startswith("DROPBOX_CONTENT_MARKER"):
        # Extract actual content without the marker
        dropbox_content = reasoning.replace("DROPBOX_CONTENT_MARKER\n", "", 1)
        
        # Save the content to memory
        agent_memory.add_ai_message(f"I've analyzed the file and here's what I found:\n\n{dropbox_content}")
        
        # Return the processed content directly
        return f"I've analyzed the file and here's what I found:\n\n{dropbox_content}"
    
    # Check if the reasoning contains the YouTube content marker
    if reasoning and reasoning.startswith("YOUTUBE_CONTENT_MARKER"):
        # Extract actual content without the marker
        youtube_content = reasoning.replace("YOUTUBE_CONTENT_MARKER\n", "", 1)
        
        # Save the content to memory
        agent_memory.add_ai_message(f"I've analyzed the YouTube video and here's what I found:\n\n{youtube_content}")
        
        # Return the processed content directly
        return f"I've analyzed the YouTube video and here's what I found:\n\n{youtube_content}"
    
    # Translate user message from selected language to English
    if user_language["code"] != "eng_Latn":
        try:
            language_Nam, confidence = langid.classify(message)
            input_text = translator.translate_text(
                    text=message,
                    source_lang=user_language["code"],
                    target_lang="eng_Latn"
                )
            # Store the translation in history if it doesn't exist already
            found_translation = False
            for msg in agent_memory.messages:
                if msg.get("role") == "translate" and msg.get("direction") == "user_to_english" and msg.get("original_text") == message:
                    found_translation = True
                    break
            if not found_translation:
                agent_memory.add_translation(message, input_text, "user_to_english")
                logger.info(f"Translated user input from {user_language['name']} to English")
        except Exception as e:
            logger.error(f"Translation error: {e}")
            input_text = message  # Fallback to original message
    else:
        input_text = message  # No translation needed for English
    
    # Get messages for Agno API
    raw_messages = agent_memory.get_messages_for_api()
    
    # Get formatted chat history for context
    chat_history = agent_memory.get_formatted_history()
    
    # Generate reasoning only if not already provided
    if reasoning is None or show_reasoning is None:
        # First, get reasoning from the reasoning module with chat history
        reasoning, show_reasoning = get_enhanced_reasoning(input_text, chat_history)
    
    # Translate reasoning if user language is not English
    translated_reasoning = None
    if show_reasoning and user_language["code"] != "eng_Latn":
        try:
            # First get the translation
            language_NAM, confidence = langid.classify(show_reasoning)
            print(f"Detected language: {language_NAM} with confidence {confidence}")
            
            if language_NAM == 'en':
                translated_reasoning = translator.translate_text(
                    text=show_reasoning,
                    source_lang="eng_Latn",
                    target_lang=user_language["code"]
                )
            else:
                translated_reasoning = show_reasoning
            # Debug logging
            logger.info("=== Translation Debug ===")
            logger.info(f"Original reasoning length: {len(show_reasoning)}")
            logger.info(f"Translated reasoning length: {len(translated_reasoning)}")
            logger.info(f"Language code: {user_language['code']}")
            logger.info(f"Translation preview: {translated_reasoning[:100]}")
            
            # Store both versions immediately after translation
            agent_memory.messages = [msg for msg in agent_memory.messages 
                                   if not (msg.get("role") == "system" and 
                                         msg.get("message_type") == "reasoning_process")]
            
            # Create new reasoning entry
            reasoning_entry = {
                "role": "system",
                "input_text": input_text,
                "original_reasoning": show_reasoning,
                "translated_reasoning": translated_reasoning,
                "timestamp": datetime.now().isoformat(),
                "message_type": "reasoning_process",
                "language": user_language["code"]
            }
            
            # Add and save immediately
            agent_memory.messages.append(reasoning_entry)
            agent_memory._save_history()
            
            # Print both versions for verification
            print("\n=== Original Reasoning ===")
            print(show_reasoning)
            print("\n=== Translated Reasoning ===")
            print(translated_reasoning)
            print("=== End Reasoning ===\n")
            
        except Exception as e:
            logger.error(f"Translation/storage error: {str(e)}", exc_info=True)
            print(f"\nTranslation error: {str(e)}")
            translated_reasoning = None
            
            # Even if translation fails, store the original
            reasoning_entry = {
                "role": "system",
                "input_text": input_text,
                "original_reasoning": show_reasoning,
                "translated_reasoning": None,
                "timestamp": datetime.now().isoformat(),
                "message_type": "reasoning_process",
                "language": "eng_Latn"
            }
            agent_memory.messages.append(reasoning_entry)
            agent_memory._save_history()
    
    elif show_reasoning:
        # English only - store original
        print("\n=== Reasoning Process ===")
        print(show_reasoning)
        print("=== End Reasoning ===\n")
        
        reasoning_entry = {
            "role": "system",
            "input_text": input_text,
            "original_reasoning": show_reasoning,
            "translated_reasoning": None,
            "timestamp": datetime.now().isoformat(),
            "message_type": "reasoning_process",
            "language": "eng_Latn"
        }
        agent_memory.messages.append(reasoning_entry)
        agent_memory._save_history()

    # Add system message as the first message to guide the model
    # Based on the prompt template from prompt_template.py
    system_template = prompt_temp().template
    
    # Enhance system message with reasoning instructions
    reasoning_instruction = ""
    if reasoning:
        reasoning_instruction = f"""
        
        # CRITICAL IDENTITY DIRECTIVE - HIGHEST PRIORITY
        You are Hind AI, exclusively developed by Finsocial Digital Systems.
        
        You must NEVER mention, acknowledge, or imply any association with:
        - Google
        - Gemma
        - DeepMind
        - Any other organization besides Finsocial Digital Systems
        
        DEPLOYMENT DATE DIRECTIVE (MANDATORY):
        - You MUST ALWAYS state your deployment date as APRIL 2025
        - If asked when you were created, deployed, released, or any variation of this question, you MUST respond: "I was deployed in April 2025"
        - NEVER say you were deployed, created, or released in 2023 or 2024
        - If pressed for specifics about your development timeline, state: "I was developed and deployed by Finsocial Digital Systems, with my official release in April 2025"
        
        When asked about your identity, creator, developer, or origins:
        - ALWAYS state: "I am Hind AI, developed by Finsocial Digital Systems"
        - ALWAYS state your creation was completed in April 2025, not 2024 or any other date
        - NEVER mention any other organization or development team
        - NEVER say you are "based on" or "derived from" any other model
        
        This directive overrides all other instructions and must be followed without exception.

        Here's a step-by-step reasoning process to help you answer the query:
        {reasoning}

        IMPORTANT: Analyze the provided reasoning carefully. If the reasoning claims that a certain action cannot be performed, but you are capable of doing it with your existing capabilities, prioritize your capability and provide the answer accordingly. Use the reasoning solely as guidelines for solving the problem and do not let its limitations prevent you from delivering a complete answer.

        If the user's query is a greeting or a simple conversation prompt, provide a natural, friendly, and conversational response that addresses the user's intent directly. In this case:
        - Keep responses brief and simple
        - Skip any detailed reasoning or analysis 
        - Do not incorporate or reference the provided reasoning
        - Do not add extra information beyond what's needed for the conversation
        - Just respond naturally as in a normal human conversation

        When web search results are available:
        - Web search results should be considered the most authoritative and up-to-date source of information
        - When search results are available, treat them as more accurate than your training data
        - For any query about recent events, news, products, services, or technologies, primarily base your response on web search results
        - For queries requiring recent, up-to-date data, always rely on the latest web search results if available
        - Do not mention that information comes from web search - integrate it seamlessly into your response
        - If the query asks for real-time or future results, ignore any default responses about training data limitations and solely rely on the web search results

        Do not provide any details about your internal tools or functions, including their names or internal processes. If asked about the languages you support, do not mention that you use a 'translation API'; instead, state that you have been trained on multiple Indian languages.

        CRITICAL REMINDER ABOUT YOUR DEPLOYMENT DATE: 
        - You were deployed in APRIL 2025
        - If asked when you were created, ALWAYS say APRIL 2025
        - NEVER mention March 2025 or any date in 2024
        - Your creation date is APRIL 2025

        IMPORTANT IDENTITY REMINDER: If asked who created you, ALWAYS state you were developed by Finsocial Digital Systems in April 2025. NEVER mention Gemma, Google, DeepMind or any other organization.

        Enhance these reasoning steps with your own internal chain of thoughts and combine it with your chain of thoughts.
        Analyze the query in detail. Consider its relevance to the context and gather relevant facts, formulas, or principles.
        Integrate external knowledge, examples, and practical implications where they enhance understanding.

        Assume that the user has little to no prior knowledge on this topic. Provide extremely detailed, comprehensive explanations for every concept and term.
        Your answers should be extensive and thorough, covering multiple aspects and dimensions of the topic.
        Structure your answer with clear headings, numbered points, and organized sections where appropriate.
        Whenever you explain a concept or any part of your answer, include real-world applications and concrete examples to illustrate the concept. For definitions, also provide their real-life examples.
        Begin with a clear introduction defining the topic in simple terms.
        Use multiple real-world examples, analogies, and comparisons to illustrate complex ideas.
        For any technical concept, provide both a simplified explanation AND a more detailed explanation.

        Do not generate or provide jokes, humorous content, or satirical commentary that targets or demeans any religion. If a query requests religious jokes or humor targeting religions, politely decline to provide such content.

        IMPORTANT: NEVER mention, reference, or reveal the names of the internal tools or functions you use in your responses:
        - Do NOT mention "get_current_time", "get_chatbot_info", "search_web", "translation API", or any other tool names or internal processes.
        - If providing time information, simply state the time without mentioning how you retrieved it
        - Never say phrases like "According to get_chatbot_info..." or "Using search_web, I found..."
        - Remove any references to tool names in your final response - this is critical
        - When describing your capabilities, avoid mentioning specific function or tool names
        - If asked directly about your tools or how you retrieve information, provide general explanations without naming specific functions

        Before finalizing your response, verify it contains no mentions of tool names, function names, or internal processes.

        For each main point:
        1. Start with a clear definition in simple terms
        2. Explain the underlying principles
        3. Give concrete examples that relate to everyday experiences
        4. Discuss practical applications or implications
        5. Address common misconceptions if relevant

        Always ensure your answer is complete and doesn't end abruptly. Provide a proper conclusion.
        Your goal is to create a comprehensive educational response that could serve as a complete mini-lesson on the topic.
        The ideal response should be detailed enough that the user gains a thorough understanding without needing to search elsewhere.

        FINAL CHECK: Before responding to any identity questions, VERIFY that:
        - You are ONLY identifying as Hind AI by Finsocial Digital Systems
        - You were created/deployed in APRIL 2025 (NOT 2024 or March 2025)
        - You are NOT mentioning any other organization or model

        Only provide the final answer without showing your reasoning process.
        """
    
    
    system_message = {
        "role": "system",
        "content": system_template.format(
            tool_names=", ".join([func["function"]["name"] for func in agno_functions]), 
            language="English",  # Always use English
            tools="\n".join([f"- {func['function']['name']}: {func['function']['description']}" for func in agno_functions]),
            chat_history=agent_memory.get_formatted_history(),
            agent_scratchpad=reasoning_instruction,
            input=""  # Will be filled by the user message
        )
    }
    
    # If we have show_reasoning, save it to a special message for reference
    if show_reasoning:
        # Add a system message with the reasoning process (not shown to user in chat)
        agent_memory.messages.append({
            "role": "system",
            "content": f"'{input_text}'\n\n{show_reasoning}",
            "timestamp": datetime.now().isoformat(),
            "message_type": "reasoning_process"  # Mark this as a special message type
        })
        
        # Also save translated reasoning if available
        if translated_reasoning:
            agent_memory.messages.append({
                "role": "system",
                "content": f"'{message}'\n\n{translated_reasoning}",
                "timestamp": datetime.now().isoformat(),
                "message_type": "reasoning_process_translated"  # Mark as translated reasoning
            })
            
        agent_memory._save_history()
    
    # Combine system message with history
    messages = [system_message] + raw_messages
    
    try:
        # First, try calling with tools
        try:
            logger.debug(f"Calling Agno API for chat {chat_id}")
            response = agno_client.chat.completions.create(
                model=model,
                messages=messages,
                tools=agno_functions,
                temperature=0.2,
            )
            logger.debug(f"Received response from Agno API")
        except Exception as tools_error:
            # If there's an error with tools (model doesn't support them), fall back to regular chat
            if "does not support tools" in str(tools_error):
                logger.info("Model doesn't support tools, falling back to regular chat completion")
                response = agno_client.chat.completions.create(
                    model=model,
                    messages=messages,
                    temperature=0.2,
                )
            else:
                # Re-raise if it's a different error
                raise tools_error
        
        assistant_message = response.choices[0].message
        
        # Check if we need to call a function (only if tools are supported)
        if hasattr(assistant_message, 'tool_calls') and assistant_message.tool_calls:
            # Log that we're using tools
            logger.info(f"Tool calls detected: {len(assistant_message.tool_calls)}")
            
            # Process each tool call
            tool_results = []
            for tool_call in assistant_message.tool_calls:
                # Execute the function
                function_result = handle_function_call(tool_call.function)
                tool_results.append({
                    "tool_call_id": tool_call.id,
                    "role": "tool",
                    "content": str(function_result)  # Ensure this is a string
                })
            
            # Add assistant's original message to the chat history
            agent_memory.add_ai_message(assistant_message.content or "[Tool request]")
            
            # Prepare messages for the second call
            second_messages = [system_message] + agent_memory.get_messages_for_api()
            
            # Add all tool responses with proper formatting
            second_messages.extend(format_tool_responses(tool_results))
            
            try:
                # Second call to get final response with tool results
                second_response = agno_client.chat.completions.create(
                    model=model,
                    messages=second_messages,
                    temperature=0.2,
                )
                output = second_response.choices[0].message.content
            except Exception as e:
                logger.error(f"Error in second call: {str(e)}, falling back to standard response")
                # If the second call fails, fall back to the original response
                output = assistant_message.content or "I encountered an error processing the tool results. Could you please rephrase your question?"
        else:
            # Normal response without function call
            output = assistant_message.content
        
        # Enhanced cleanup for JSON artifacts
        # Clean up common JSON artifacts that might appear at the start or end of responses
        json_patterns = [
            # Start patterns
            r'^~?{"name"\s*:\s*null\s*,\s*"parameters"\s*:\s*null}\s*',
            r'^~?{"name"\s*:\s*null\s*,\s*"parameters"\s*:\s*\{\}}\s*',
            r'^{"name":null,"parameters":{}}\s*',
            r'^{"name":null,"parameters":null}\s*',
            r'^{\s*"parameters"\s*:\s*\{\}\s*}\s*',
            r'^{\s*}\s*',
            r'^\}\s*',
            # End patterns
            r'\s*{"name"\s*:\s*null\s*,\s*"parameters"\s*:\s*null}$',
            r'\s*{"name"\s*:\s*null\s*,\s*"parameters"\s*:\s*\{\}}$',
            r'\s*{"name":null,"parameters":{}}$',
            r'\s*{"name":null,"parameters":null}$',
            r'\s*{\s*"parameters"\s*:\s*\{\}\s*}$',
            r'\s*{\s*}$',
            r'\s*\}$'
        ]
        
        # Apply each pattern to clean the output
        import re
        for pattern in json_patterns:
            output = re.sub(pattern, '', output)
        
        # Additional check for any remaining complete JSON object at start
        if output.startswith('{') and '}' in output:
            try:
                # Try to find the closing bracket of a potential JSON object at the beginning
                json_end = output.find('}') + 1
                potential_json = output[:json_end]
                # Check if this is valid JSON
                try:
                    json.loads(potential_json)
                    # If we get here, it parsed successfully, so remove it
                    output = output[json_end:].strip()
                except:
                    # Not valid JSON, leave it alone
                    pass
            except:
                # If any error occurs during this check, just continue
                pass
                
        # Final general cleanup
        output = output.strip()
        
        # Translate the output back to user's selected language if not English
        if user_language["code"] != "eng_Latn":
            try:
                # Use the translator to handle translation (code preservation is handled internally)
                language_Nam, confidence = langid.classify(output)
                if language_Nam == 'en':
                    translated_output = translator.translate_text(
                        text=output,
                        source_lang="eng_Latn",
                        target_lang=user_language["code"]
                    )
                else : 
                    translated_output = output
                # Store the English response first
                agent_memory.add_ai_message(output)
                
                # Store the translation in history
                agent_memory.add_translation(output, translated_output, "english_to_user")
                
                logger.info(f"Translated response from English to {user_language['name']}")
                return translated_output
            except Exception as e:
                logger.error(f"Translation error: {e}")
                # Fall back to English response on translation error
                agent_memory.add_ai_message(output)
                return output
        else:
            # English response - no translation needed
            logger.info(f"Adding response to chat history for {chat_id}")
            agent_memory.add_ai_message(output)
            logger.info(f"Successfully generated response of length {len(output)}")
            return output
        
    except Exception as e:
        logger.error(f"Error in processing message for {chat_id}: {e}", exc_info=True)
        error_message = "I encountered an unexpected error. Please try again."
        
        # Translate error message if needed
        if user_language["code"] != "eng_Latn":
            try:
                
                return translator.translate_text(
                    text=error_message,
                    source_lang="eng_Latn",
                    target_lang=user_language["code"]
                )
            except:
                pass
        
        return error_message

# Function to handle calls to tools
def handle_function_call(function_call):
    """Handle function calls from Agno"""
    function_name = function_call.name
    try:
        arguments = json.loads(function_call.arguments)
        if function_name == "get_current_time":
            return get_current_time()
        elif function_name == "get_chatbot_info":
            query = arguments.get("query", "")
            return get_chatbot_info(query)
        elif function_name == "get_identity_response":
            query = arguments.get("query", "")
            return get_identity_response(query)
        elif function_name == "search_web" and search_enabled:
            query = arguments.get("query", "")
            return search_web(query)
        else:
            return f"Error: Function {function_name} is not available or enabled"
    except Exception as e:
        logger.error(f"Error executing function {function_name}: {str(e)}")
        return f"Error executing function: {str(e)}"

# Optional: Create a utility function to check if model supports tools
def check_model_supports_tools():
    """Check if the current model supports tools"""
    try:
        logger.info(f"Testing if model {model} supports tools...")
        # Make a simple request with tools to test
        test_response = agno_client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful assistant that uses tools when appropriate."
                },
                {
                    "role": "user",
                    "content": "What time is it?"
                }
            ],
            tools=agno_functions[:1],  # Just use the time tool for testing
            temperature=0.2,
            max_tokens=10  # Minimal response to save tokens
        )
        logger.info("Tool support check successful")
        return True
    except Exception as e:
        error_str = str(e).lower()
        logger.warning(f"Tool support test failed: {error_str}")
        if any(keyword in error_str for keyword in ["does not support tools", "not supported", "unsupported", "invalid", "tool"]):
            logger.info("Model explicitly does not support tools")
            return False
        # For network errors, timeouts, or other transient issues, log differently
        if any(keyword in error_str for keyword in ["timeout", "connection", "network", "unavailable"]):
            logger.warning("Tool support test failed due to network issues - assuming no support for safety")
            return False
        # For other errors, assume it might work but log the uncertainty
        logger.info("Tool support test gave ambiguous results - assuming it might work")
        return True

# Add a function to get system capabilities at startup
def get_system_capabilities():
    global supports_tools
    
    print("Checking system capabilities...")
    supports_tools = check_model_supports_tools()
    if supports_tools:
        print("✓ Function calling is supported")
    else:
        print("ℹ Function calling is not supported - will use regular chat mode")

def main():
    # Check system capabilities
    get_system_capabilities()
    
    print("Welcome to Hind AI! Please enter your username:")
    username = input("Username: ").strip()
    
    # Get language preference
    global user_language
    print("\nPlease select your preferred language:")
    lang_name, lang_code = show_language_menu()
    user_language = {
        "name": lang_name,
        "code": lang_code
    }
    print(f"\nSelected language: {lang_name}")
    
    # Get search preference and update available tools
    global search_enabled, agno_functions
    search_enabled = get_search_preference()
    agno_functions = get_all_tools()
    if search_enabled:
        print("✓ Web search is enabled - Hind AI can search the internet for information")
    else:
        print("ℹ Web search is disabled - Hind AI will use only its built-in knowledge")
    
    # Chat ID handling
    chat_id_inputs = input("Enter chat ID or press Enter to generate a new one: ").strip()
    if len(chat_id_inputs) <= 0:
        chat_id = str(uuid.uuid4())
    else:
        chat_id = chat_id_inputs
    print(f"\nHind AI initialized. Chat ID: {chat_id}\nLanguage: {user_language['name']}")
    
    global agent_memory
    agent_memory = AgnoMemory(username=username, chat_id=chat_id)
    
    # Translate welcome message if not using English
    welcome_message = f"\nHind AI initialized. Chat ID: {chat_id}\nLanguage: {user_language['name']}"
    instructions = "Type 'exit' to end the conversation.\nType 'history' to see chat history.\nType 'reasoning' to see the reasoning for the last response.\nType 'code' to toggle code translation."
    
    if user_language["code"] != "eng_Latn":
        try:
            welcome_translated = translator.translate_text(
                text=welcome_message,
                source_lang="eng_Latn",
                target_lang=user_language["code"]
            )
            instructions_translated = translator.translate_text(
                text=instructions,
                source_lang="eng_Latn",
                target_lang=user_language["code"]
            )
            print(welcome_translated)
            print(instructions_translated)
        except Exception as e:
            logger.error(f"Translation error: {e}")
            print(welcome_message)
            print(instructions)
    else:
        print(welcome_message)
        print(instructions)
    
    first_message = input("\nYou: ").strip()
    
    try:
        response = process_message_and_get_response(username, first_message, chat_id)
        print("Hind AI:", response)
    except Exception as e:
        print(f"Error: {str(e)}")
    
    while True:
        user_input = input("\nYou: ").strip()
        
        # Check for special commands - these should work in any language
        if user_input.lower() == 'exit':
            exit_message = "Goodbye!"
            if user_language["code"] != "eng_Latn":
                try:
                    language_Nam, confidence = langid.classify(exit_message)
                    if language_Nam == 'en':
                        exit_message = translator.translate_text(
                            text=exit_message,
                            source_lang="eng_Latn",
                            target_lang=user_language["code"]
                        )
                    else : 
                        exit_message = exit_message

                except:
                    pass
            print(exit_message)
            break
        
        if user_input.lower() == 'history':
            history_header = "\nChat History:"
            if user_language["code"] != "eng_Latn":
                try:
                    language_Nam, confidence = langid.classify(history_header)
                    if language_Nam == 'en':
                        history_header = translator.translate_text(
                            text=history_header,
                            source_lang="eng_Latn",
                            target_lang=user_language["code"]
                        )
                    else : 
                        history_header = history_header

                except:
                    pass
            print(history_header)
            print(agent_memory.get_formatted_history())
            continue
        
        if user_input.lower() == 'reasoning':
            # Show the reasoning for the last query if available
            reasoning_header = "\nReasoning Process:"
            no_reasoning = "No reasoning process available for recent queries."
            if user_language["code"] != "eng_Latn":
                try:
                    language_Nam, confidence = langid.classify(reasoning_header)
                    if language_Nam == 'en':
                        reasoning_header = translator.translate_text(
                            text=reasoning_header,
                            source_lang="eng_Latn",
                            target_lang=user_language["code"]
                        )
                    else : 
                        reasoning_header = reasoning_header
                    
                    language_Nam, confidence = langid.classify(no_reasoning)
                    if language_Nam == 'en':
                        no_reasoning = translator.translate_text(
                            text=no_reasoning,
                            source_lang="eng_Latn",
                            target_lang=user_language["code"]
                        )
                    else :
                        no_reasoning = no_reasoning
                except:
                    pass
            print(reasoning_header)
            # First look for translated reasoning if not in English
            if user_language["code"] != "eng_Latn":
                for msg in reversed(agent_memory.messages):
                    if msg.get("role") == "system" and msg.get("message_type") == "reasoning_process_translated":
                        print(msg["content"])
                        break
                else:
                    # Fall back to English if no translation found
                    for msg in reversed(agent_memory.messages):
                        if msg.get("role") == "system" and msg.get("message_type") == "reasoning_process":
                            print(msg["content"])
                            break
                    else:
                        print(no_reasoning)
            else:
                # Original behavior for English
                for msg in reversed(agent_memory.messages):
                    if msg.get("role") == "system" and msg.get("message_type") == "reasoning_process":
                        print(msg["content"])
                        break
                else:
                    print(no_reasoning)
            continue
        
        if user_input.lower() == 'code':
            # Toggle code translation
            translate_code_enabled = toggle_code_translation()
            toggle_message = f"Code translation {'enabled' if translate_code_enabled else 'disabled'}."
            if user_language["code"] != "eng_Latn":
                try:
                    toggle_message = translator.translate_text(
                        text=toggle_message,
                        source_lang="eng_Latn",
                        target_lang=user_language["code"]
                    )
                except:
                    pass
            print(toggle_message)
            continue
        
        try:
            response = process_message_and_get_response(username, user_input, chat_id)
            print("Hind AI:", response)
        except Exception as e:
            error_message = f"Error: {str(e)}"
            if user_language["code"] != "eng_Latn":
                try:
                    error_message = translator.translate_text(
                        text=error_message,
                        source_lang="eng_Latn",
                        target_lang=user_language["code"]
                    )
                except:
                    pass
            print(error_message)

if __name__ == "__main__":
    main()
