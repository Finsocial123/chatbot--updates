import re
import random
import uuid
from datetime import datetime
import string
def create_safe_chat_id(message: str) -> str:
    """Create a safe chat ID from message"""
    # Remove special characters and paths
    safe_message = re.sub(r'[^\w\s-]', '', message)
    safe_message = re.sub(r'\s+', '_', safe_message.strip())
    timestamp = datetime.now().strftime('%H%M%S')
    return f"{safe_message[:30]}_{timestamp}"

def sanitize_filename(filename: str) -> str:
    """Sanitize a string to be used as a filename"""
    # Remove invalid characters and replace spaces
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '')
    filename = filename.replace(' ', '_')
    return filename.strip('.')

def create_chat_id(message: str) -> str:
    """Create a safe chat ID from the first message"""
    # Sanitize and limit message length
    safe_message = sanitize_filename(message)[:20]
    # Add timestamp and random suffix
    timestamp = datetime.now().strftime('%H%M%S')
    unique_id = ''.join(random.choices(string.digits, k=4))
    return f"chat_{timestamp}_{unique_id}"