import json
import os
from datetime import datetime

class ChatHistoryManager:
    def __init__(self, base_dir="chat_histories"):
        self.base_dir = base_dir
        os.makedirs(base_dir, exist_ok=True)
    
    def get_chat_filename(self, username, chat_name):
        chat_dir = os.path.join(self.base_dir, username)
        os.makedirs(chat_dir, exist_ok=True)
        return os.path.join(chat_dir, f"{chat_name}_history.json")
    
    def save_chat_history(self, username, chat_name, messages, conversation_history):
        filename = self.get_chat_filename(username, chat_name)
        data = {
            "last_updated": datetime.now().isoformat(),
            "username": username,
            "chat_name": chat_name,
            "messages": messages,
            "conversation_history": conversation_history
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    
    def load_chat_history(self, username, chat_name):
        filename = self.get_chat_filename(username, chat_name)
        if not os.path.exists(filename):
            return [], []
            
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get("messages", []), data.get("conversation_history", [])
        except Exception as e:
            print(f"Error loading chat history: {e}")
            return [], []
    
    def get_user_chats(self, username):
        user_dir = os.path.join(self.base_dir, username)
        if not os.path.exists(user_dir):
            return []
        
        chat_files = [f.replace("_history.json", "") for f in os.listdir(user_dir) 
                     if f.endswith("_history.json")]
        return chat_files
