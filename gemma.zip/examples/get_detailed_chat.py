#!/usr/bin/env python
# Client to fetch detailed chat history with reasoning and responses

import requests
import json
import sys
import argparse
from colorama import init, Fore, Style

# Initialize colorama for colored output
init()

def get_detailed_history(username, chat_id, base_url="http://localhost:8000"):
    """
    Fetch detailed chat history with prompts, reasoning, and responses
    
    Args:
        username: User's name
        chat_id: Chat ID to fetch
        base_url: API base URL
        
    Returns:
        Dict with detailed chat history or None if error
    """
    endpoint = f"{base_url}/chat/detailed-history"
    data = {
        "username": username,
        "chat_id": chat_id
    }
    
    try:
        print(f"Fetching detailed history for chat {chat_id}...")
        response = requests.post(endpoint, json=data)
        
        if response.status_code != 200:
            print(f"Error: HTTP {response.status_code}")
            print(response.text)
            return None
            
        return response.json()
    except Exception as e:
        print(f"Request failed: {str(e)}")
        return None

def display_history(history, show_reasoning=True, color=True):
    """
    Display the history in a readable format
    
    Args:
        history: History data from API
        show_reasoning: Whether to show reasoning
        color: Whether to use colored output
    """
    if not history:
        return
    
    chat_id = history.get("chat_id")
    messages = history.get("messages", [])
    
    # Setup colors
    if color:
        C_PROMPT = Fore.CYAN
        C_REASONING = Fore.YELLOW
        C_RESPONSE = Fore.GREEN
        C_HEADER = Fore.MAGENTA + Style.BRIGHT
        C_RESET = Style.RESET_ALL
    else:
        C_PROMPT = C_REASONING = C_RESPONSE = C_HEADER = C_RESET = ""
    
    # Print header
    print(f"\n{C_HEADER}Detailed Chat History for {chat_id}{C_RESET}\n")
    print("=" * 80)
    
    # Print each conversation turn
    for i, msg in enumerate(messages):
        print(f"\n{C_HEADER}Turn {i+1} - {msg.get('timestamp')}{C_RESET}\n")
        
        # Print user prompt
        print(f"{C_HEADER}User Prompt:{C_RESET}")
        print(f"{C_PROMPT}{msg.get('prompt')}{C_RESET}")
        
        # Print reasoning if available and requested
        reasoning = msg.get('reasoning')
        if reasoning and show_reasoning:
            print(f"\n{C_HEADER}Reasoning Process:{C_RESET}")
            print(f"{C_REASONING}{reasoning}{C_RESET}")
        
        # Print response
        response = msg.get('response')
        if response:
            print(f"\n{C_HEADER}Final Response:{C_RESET}")
            print(f"{C_RESPONSE}{response}{C_RESET}")
        
        print("\n" + "=" * 80)
    
    # Summary
    print(f"\n{C_HEADER}Chat Summary:{C_RESET}")
    print(f"Chat ID: {chat_id}")
    print(f"Total turns: {len(messages)}")

def save_to_json(history, filename):
    """Save history to a JSON file"""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(history, f, indent=2)
        print(f"History saved to {filename}")
        return True
    except Exception as e:
        print(f"Error saving to file: {str(e)}")
        return False

def save_to_markdown(history, filename):
    """Save history to a Markdown file for better readability"""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            chat_id = history.get("chat_id")
            f.write(f"# Detailed Chat History - {chat_id}\n\n")
            
            for i, msg in enumerate(history.get("messages", [])):
                f.write(f"## Turn {i+1} - {msg.get('timestamp')}\n\n")
                
                f.write("### User Prompt\n\n")
                f.write(f"```\n{msg.get('prompt')}\n```\n\n")
                
                reasoning = msg.get('reasoning')
                if reasoning:
                    f.write("### Reasoning Process\n\n")
                    f.write(f"```\n{reasoning}\n```\n\n")
                
                response = msg.get('response')
                if response:
                    f.write("### Final Response\n\n")
                    f.write(f"```\n{response}\n```\n\n")
                
                f.write("---\n\n")
            
        print(f"History saved as Markdown to {filename}")
        return True
    except Exception as e:
        print(f"Error saving to Markdown file: {str(e)}")
        return False

def main():
    parser = argparse.ArgumentParser(description="Fetch detailed chat history from Hind AI API")
    parser.add_argument("username", help="Username")
    parser.add_argument("chat_id", help="Chat ID")
    parser.add_argument("--url", "-u", default="http://localhost:8000", help="API base URL")
    parser.add_argument("--output", "-o", help="Output file (JSON format)")
    parser.add_argument("--markdown", "-m", help="Output file (Markdown format)")
    parser.add_argument("--no-color", action="store_true", help="Disable colored output")
    parser.add_argument("--no-reasoning", action="store_true", help="Hide reasoning in display")
    
    args = parser.parse_args()
    
    # Get the history from the API
    history = get_detailed_history(args.username, args.chat_id, args.url)
    
    if not history:
        return 1
    
    # Display the history
    display_history(history, not args.no_reasoning, not args.no_color)
    
    # Save to JSON if requested
    if args.output:
        save_to_json(history, args.output)
    
    # Save to Markdown if requested
    if args.markdown:
        save_to_markdown(history, args.markdown)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
