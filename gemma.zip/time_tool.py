"""
Tool for providing current time information
"""
import datetime

def get_current_time():
    """Get current date and time information"""
    now = datetime.datetime.now()
    return {
        "local_time": now.strftime("%I:%M:%S %p"),
        "local_date": now.strftime("%B %d, %Y"),
        "day_of_week": now.strftime("%A"),
        "iso_format": now.isoformat(),
        "unix_timestamp": int(now.timestamp()),
        "timezone": str(datetime.datetime.now().astimezone().tzinfo)
    }
