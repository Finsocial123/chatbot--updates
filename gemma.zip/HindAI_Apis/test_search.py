#!/usr/bin/env python3
"""
Test script to verify search functionality in HindAI API

Usage:
    python test_search.py
"""

import os
import sys
import json
import logging
import requests
import time
from pprint import pprint

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import from HindAI if available
try:
    from HindAI import set_search_enabled, search_web
except ImportError:
    logger.error("Failed to import search functions from HindAI")
    set_search_enabled = lambda x: print(f"Would set search to: {x}")
    search_web = lambda x: f"Search unavailable: {x}"

def test_search_locally():
    """Test search functionality directly in Python"""
    print("\n===== Testing Search Locally =====")
    # Set search enabled
    set_search_enabled(True)
    
    # Try a sample search
    query = "recent india's cricket match"
    print(f"Searching for: '{query}'")
    result = search_web(query)
    print("\nSearch Result:")
    print(result[:500] + "..." if len(result) > 500 else result)
    
    # Disable search and verify
    set_search_enabled(False)
    result = search_web(query)
    print("\nWith search disabled:")
    print(result)

def test_search_via_api(api_url="http://localhost:8000"):
    """Test search functionality via API endpoints"""
    print("\n===== Testing Search Via API =====")
    
    # Test data with search enabled
    data = {
        "username": "test_user",
        "language_code": "eng_Latn",
        "language_name": "English",
        "enable_search": True,
        "message": "recent india's cricket match"
    }
    
    # Send request
    try:
        # First initiate a chat
        print("Initiating chat with search enabled...")
        response = requests.post(f"{api_url}/chat/initiate", json=data)
        response.raise_for_status()
        result = response.json()
        
        print("Response (reasoning):")
        print(result.get("reasoning", "")[:300] + "..." if result.get("reasoning", "") else "No reasoning provided")
        
        # Get response ID
        response_id = result.get("response_id")
        if not response_id:
            print("Error: No response_id returned")
            return
            
        print(f"Got response_id: {response_id}")
        
        # Poll for final response
        max_attempts = 30
        for attempt in range(max_attempts):
            print(f"Checking response status (attempt {attempt+1})...")
            status_response = requests.post(f"{api_url}/chat/response-status", 
                                           json={"response_id": response_id})
            status_response.raise_for_status()
            status_data = status_response.json()
            
            if status_data.get("status") == "completed":
                print("\nFinal Response:")
                print(status_data.get("response", "")[:500] + "..." if len(status_data.get("response", "")) > 500 else status_data.get("response", ""))
                break
                
            time.sleep(2)
        else:
            print("Timed out waiting for response")
        
    except requests.RequestException as e:
        print(f"API request failed: {e}")

if __name__ == "__main__":
    try:
        test_search_locally()
    except Exception as e:
        print(f"Local test failed: {e}")
        
    try:
        test_search_via_api()
    except Exception as e:
        print(f"API test failed: {e}")
