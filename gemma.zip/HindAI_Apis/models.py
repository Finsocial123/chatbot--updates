from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from enum import Enum

class ChatMessage(BaseModel):
    message_id: str
    chat_id: str
    username: str
    content: str
    type: str  # 'human' or 'ai'
    timestamp: datetime

class ChatSession(BaseModel):
    chat_id: str
    username: str
    language: str
    created_at: datetime
    last_message: Optional[str] = None
    messages: List[ChatMessage] = []

class ChatSummary(BaseModel):
    chat_id: str
    username: str
    first_message: str
    created_at: datetime

class LanguageCode(str, Enum):
    ENGLISH = "eng_Latn"
    HINDI = "hin_Deva"
    BENGALI = "ben_Beng"
    GUJARATI = "guj_Gujr"
    KANNADA = "kan_Knda"
    MALAYALAM = "mal_Mlym"
    MARATHI = "mar_Deva"
    NEPALI = "npi_Deva"
    ORIYA = "ory_Orya"
    PUNJABI = "pan_Guru"
    SANSKRIT = "san_Deva"
    TAMIL = "tam_Taml"
    TELUGU = "tel_Telu"
    URDU = "urd_Arab"
    ASSAMESE = "asm_Beng"
    KASHMIRI = "kas_Arab"
    MANIPURI = "mni_Mtei"
    SINDHI = "snd_Arab"

class ChatRequest(BaseModel):
    username: str
    message: str
    chat_id: Optional[str] = None
    language: str = "ENGLISH"

class ChatResponse(BaseModel):
    chat_id: str
    response: str
    timestamp: str

class ChatHistorySummary(BaseModel):
    chat_id: str
    first_message: str
    timestamp: str

class UserChatsResponse(BaseModel):
    username: str
    chats: List[ChatHistorySummary]

class LanguageResponse(BaseModel):
    code: str
    name: str
    native_name: Optional[str] = None

class ContinueChatRequest(BaseModel):
    username: str
    chat_id: str
    message: str
    language: str = "ENGLISH"  # Add language field with default value

class ChatHistoryMessage(BaseModel):
    role: str  # 'human' or 'assistant'
    content: str
    timestamp: Optional[str] = None

class ChatHistoryResponse(BaseModel):
    chat_id: str
    username: str
    messages: List[ChatHistoryMessage]
