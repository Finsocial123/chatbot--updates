"""
Response tracking utilities for HindAI
"""
import os
import json
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class ResponseTracker:
    """Utility class for tracking and retrieving responses"""
    
    @staticmethod
    def get_base_directory():
        """Get the base directory for response histories"""
        return os.path.join("response_histories")
    
    @staticmethod
    def get_user_directory(username):
        """Get the directory for a specific user's responses"""
        return os.path.join(ResponseTracker.get_base_directory(), username)
    
    @staticmethod
    def get_date_directory(username, date_str=None):
        """Get the directory for a specific date's responses"""
        if date_str is None:
            date_str = datetime.now().strftime("%Y-%m-%d")
        return os.path.join(ResponseTracker.get_user_directory(username), date_str)
    
    @staticmethod
    def get_response_by_id(response_id, username=None):
        """
        Find a response by ID
        
        If username is not provided, searches all user directories
        """
        try:
            base_dir = ResponseTracker.get_base_directory()
            
            # If username is provided, only search in that user's directory
            if username:
                user_dirs = [os.path.join(base_dir, username)]
            else:
                # Otherwise search in all user directories
                user_dirs = [os.path.join(base_dir, d) for d in os.listdir(base_dir) 
                           if os.path.isdir(os.path.join(base_dir, d))]
            
            # Search for the response ID in each user directory
            for user_dir in user_dirs:
                # Look in each date directory
                for date_dir in os.listdir(user_dir):
                    date_path = os.path.join(user_dir, date_dir)
                    
                    if not os.path.isdir(date_path):
                        continue
                    
                    # Check for the specific response file
                    response_file = os.path.join(date_path, f"{response_id}.json")
                    
                    if os.path.exists(response_file):
                        with open(response_file, 'r', encoding='utf-8') as f:
                            return json.load(f)
            
            return None
        
        except Exception as e:
            logger.error(f"Error retrieving response {response_id}: {e}")
            return None
    
    @staticmethod
    def get_responses_for_date_range(username, start_date=None, end_date=None):
        """
        Get all responses for a user within a date range
        
        Args:
            username: The username to retrieve responses for
            start_date: Start date string (YYYY-MM-DD) or None for 7 days ago
            end_date: End date string (YYYY-MM-DD) or None for today
        """
        try:
            if end_date is None:
                end_date = datetime.now().strftime("%Y-%m-%d")
                
            if start_date is None:
                # Default to 7 days before end_date
                end_dt = datetime.strptime(end_date, "%Y-%m-%d")
                start_dt = end_dt - timedelta(days=7)
                start_date = start_dt.strftime("%Y-%m-%d")
                
            # Parse dates to datetime objects for comparison
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            
            responses = []
            user_dir = ResponseTracker.get_user_directory(username)
            
            if not os.path.exists(user_dir):
                return responses
                
            # Look for all date directories between start_date and end_date
            date_dirs = []
            current_dt = start_dt
            
            while current_dt <= end_dt:
                date_str = current_dt.strftime("%Y-%m-%d")
                date_dir = os.path.join(user_dir, date_str)
                
                if os.path.exists(date_dir):
                    date_dirs.append(date_dir)
                    
                # Also check for the daily log file
                daily_log = os.path.join(user_dir, f"responses_{date_str}.jsonl")
                
                if os.path.exists(daily_log):
                    with open(daily_log, 'r', encoding='utf-8') as f:
                        for line in f:
                            try:
                                response = json.loads(line.strip())
                                responses.append(response)
                            except json.JSONDecodeError:
                                pass
                
                current_dt = current_dt + timedelta(days=1)
                
            return responses
            
        except Exception as e:
            logger.error(f"Error retrieving responses for {username}: {e}")
            return []
