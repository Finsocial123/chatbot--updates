from .models import LanguageCode, LanguageResponse, ChatRequest, ChatResponse, UserChatsResponse, ChatHistorySummary

# Make sure we're importing our set_search_enabled function
try:
    from HindAI import set_search_enabled, AgnoMemory, process_message_and_get_response, get_enhanced_reasoning, translator, LanguageTranslator
except ImportError:
    # Provide fallbacks if imports fail
    def set_search_enabled(enable=False):
        print("Warning: set_search_enabled function not available")
        return False

__all__ = [
    'LanguageCode',
    'LanguageResponse',
    'ChatRequest',
    'ChatResponse',
    'UserChatsResponse',
    'ChatHistorySummary',
    'set_search_enabled',
    'AgnoMemory',
    'process_message_and_get_response',
    'get_enhanced_reasoning',
    'translator',
    'LanguageTranslator'
]
