import sys
import os
import json
import logging
import uuid
import time
import asyncio
from typing import Dict, List, Optional, Union, Any
from fastapi import APIRouter, HTTPException, Depends, Query, BackgroundTasks
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from asgiref.sync import sync_to_async
import threading
import hashlib
import asyncio
import time
from datetime import datetime, timedelta  # Add timedelta import for date calculations
import langid
# Add parent directory to Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from HindAi_users.models import ActiveInactiveUsers
# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import HindAI components directly - modify the try-except to ensure AgnoMemory is imported
try:
    # First try importing AgnoMemory specifically
    from HindAI import AgnoMemory
    
    # Then import the rest of the components
    from HindAI import (
        process_message_and_get_response, 
        get_enhanced_reasoning,
        translator,
        LanguageTranslator,
        set_search_enabled,  # Import the function to set search preference
        format_tool_responses  # Import the tool formatting function
    )
    logger.info("Successfully imported HindAI components")
except ImportError as e:
    logger.error(f"Error importing HindAI components: {e}")
    # Define a fallback AgnoMemory class if import fails
    class AgnoMemory:
        """Fallback AgnoMemory class when import fails"""
        def __init__(self, username: str, chat_id: str = None):
            self.username = username
            self.chat_id = chat_id or str(uuid.uuid4())
            self.messages = []
            
        def _get_timestamp(self):
            return datetime.now().isoformat()
            
        def add_user_message(self, content):
            self.messages.append({
                "role": "user",
                "content": content,
                "timestamp": self._get_timestamp()
            })
            
        def add_ai_message(self, content):
            self.messages.append({
                "role": "assistant",
                "content": content,
                "timestamp": self._get_timestamp()
            })
            
        def add_translation(self, original_text, translated_text, direction):
            self.messages.append({
                "role": "translate",
                "content": translated_text,
                "original_text": original_text,
                "direction": direction,
                "timestamp": self._get_timestamp()
            })
            
        def get_formatted_history(self):
            return ""
            
        def get_messages_for_api(self):
            return []
            
        def add_reasoning(self, input_text, original_reasoning, translated_reasoning=None):
            pass
    
    # Define fallbacks for other functions if imports fail
    def set_search_enabled(enable=False):
        logger.warning("Using mock set_search_enabled function")
        return enable
        
    def process_message_and_get_response(*args, **kwargs):
        return "Sorry, the AI service is currently unavailable."
        
    def get_enhanced_reasoning(*args, **kwargs):
        return "", ""
        
    def format_tool_responses(messages):
        return messages
        
    # Use existing translator or create a placeholder
    if 'translator' not in locals():
        translator = None
        LanguageTranslator = None

# Create router
router = APIRouter()

# In-memory response tracker for ongoing responses
# Structure: {response_id: {"status": "processing|completed", "reasoning": str, "response": str}}
response_tracker = {}

# Define request models
class InitiateChatRequest(BaseModel):
    username: str
    language_code: str = "eng_Latn"
    language_name: str = "English"
    enable_search: bool = False
    message: str

class ContinueChatRequest(BaseModel):
    username: str
    chat_id: str
    language_code: str = "eng_Latn"
    language_name: str = "English"
    enable_search: bool = False
    message: str

class ResponseStatusRequest(BaseModel):
    response_id: str

class AllChatsRequest(BaseModel):
    username: str

class DetailedHistoryRequest(BaseModel):
    username: str
    chat_id: str

# Define response models
class Message(BaseModel):
    role: str
    content: str
    timestamp: str

class ChatSummary(BaseModel):
    chat_id: str
    first_message: str
    timestamp: str

class DetailedMessage(BaseModel):
    prompt: str
    reasoning: str = ""
    response: str = ""
    timestamp: str

class DetailedChatHistory(BaseModel):
    chat_id: str
    messages: List[DetailedMessage]

class ChatDetails(BaseModel):
    chat_id: str
    messages: List[Message]

class AllChatsResponse(BaseModel):
    chats: List[ChatSummary]

class ReasoningResponse(BaseModel):
    response_id: str
    chat_id: str
    reasoning: str
    status: str = "processing"

class FinalResponse(BaseModel):
    response_id: str
    response: str
    status: str = "completed"

# Function to process the response in the background
def process_response_background(response_id: str, username: str, message: str, 
                              chat_id: str, reasoning: str, show_reasoning: str,
                              language_code: str, language_name: str, enable_search: bool = False):
    """Process the final response in the background"""
    try:
        logger.info(f"Starting background processing for response {response_id}, chat {chat_id}")
        logger.info(f"Search enabled: {enable_search}")
        
        # Make sure we're dealing with a valid response_id that exists in the tracker
        if response_id not in response_tracker:
            logger.error(f"Response ID {response_id} not found in tracker")
            return
            
        # Update the global user language setting for this thread
        global user_language
        user_language = {
            "code": language_code,
            "name": language_name
        }
        
        # Set search preference before processing
        set_search_enabled(enable_search)
        logger.info(f"Set search preference to: {enable_search}")
        
        # Process the message and get final response with retry logic
        max_retries = 3
        response = None
        last_error = None
        
        for attempt in range(1, max_retries + 1):
            try:
                logger.info(f"Calling process_message_and_get_response for {username}, chat: {chat_id} (attempt {attempt})")
                response = process_message_and_get_response(
                    username,
                    message,
                    chat_id,
                    reasoning=reasoning,
                    show_reasoning=show_reasoning
                )
                
                # If we got a valid response, break the retry loop
                # REMOVED: Length validation - any non-empty response is now considered valid
                if response and response.strip():
                    logger.info(f"Valid response of length {len(response.strip())} accepted")
                    break
                    
                # If response is empty, log it and try again
                if not response or not response.strip():
                    logger.warning(f"Empty response on attempt {attempt}")
                    last_error = "Empty response"
                    # Longer pause before retry
                    time.sleep(3)
                    
            except Exception as e:
                logger.error(f"Error in attempt {attempt}: {str(e)}")
                last_error = str(e)
                # Exponential backoff
                time.sleep(attempt * 2)
        
        # Log the response length to help with debugging
        response_length = len(response) if response else 0
        logger.info(f"Got response of length {response_length} for {response_id}")
        
        # Handle case where we still don't have a valid response after all retries
        if not response or not response.strip():
            logger.warning(f"Failed to generate adequate response for {response_id} after {max_retries} attempts")
            
            # Provide a more detailed error message based on the failure type
            if last_error:
                error_msg = f"I'm sorry, I couldn't generate a complete answer to your question. Please try rephrasing or asking a different question."
            else:
                error_msg = "I was unable to generate a helpful response for your query. Please try rephrasing your question or breaking it into smaller parts."
                
            response = error_msg
        
        # Translate response if language is not English
        if language_code != "eng_Latn":
            try:
                # Use the translator to translate the response
                agent_memory = AgnoMemory(username=username, chat_id=chat_id)
                language_Nam, confidence = langid.classify(response)
                if language_Nam == 'en':
                    
                    translated_response = translator.translate_text(
                        text=response,
                        source_lang="eng_Latn",
                        target_lang=language_code
                    )
                else :
                    translated_response = response
                # Store the English response in memory first
                agent_memory.add_ai_message(response)
                
                # Also store the translation
                agent_memory.add_translation(response, translated_response, "english_to_user")
                
                logger.info(f"Translated response from English to {language_name}")
                
                
                # Use the translated response for display but keep original for processing
                display_response = translated_response
                # Keep the original response for internal purposes
                # response remains unchanged here (English version)
            except Exception as e:
                logger.error(f"Translation error for response: {e}")
                # Continue with English response if translation fails
                display_response = response
        else:
            # For English, display and response are the same
            display_response = response
        
        # Make sure response_id still exists (it might have been cleaned up)
        if response_id in response_tracker:
            # Update the response tracker with the completed response
            response_tracker[response_id]["status"] = "completed"
            response_tracker[response_id]["response"] = display_response  # Use the display_response here
            response_tracker[response_id]["original_response"] = response  # Store original for reference
            response_tracker[response_id]["completion_time"] = time.time()
            
            # Save the response to disk for tracking
            save_response_to_disk(
                response_id=response_id, 
                username=username, 
                chat_id=chat_id, 
                response_data=response_tracker[response_id]
            )
            
            logger.info(f"Response {response_id} processing completed and saved to tracker")
        else:
            logger.warning(f"Response ID {response_id} no longer in tracker, response not saved")
            
    except Exception as e:
        # Handle errors and update the tracker
        logger.error(f"Error processing response {response_id}: {e}", exc_info=True)
        if response_id in response_tracker:
            response_tracker[response_id]["status"] = "error"
            response_tracker[response_id]["error"] = str(e)
            
            # Provide a more helpful error message
            error_context = getattr(e, "__class__.__name__", "processing error")
            response_tracker[response_id]["response"] = f"I encountered a {error_context} while processing your request. This might be due to high demand or a temporary issue. Please try again in a moment."
            
            # Save the error response to disk for tracking
            save_response_to_disk(
                response_id=response_id, 
                username=username, 
                chat_id=chat_id, 
                response_data=response_tracker[response_id]
            )

# Helper function to generate reasoning and start background response processing
async def generate_reasoning_and_start_response(username: str, message: str, chat_id: str, 
                                             language_code: str, language_name: str,
                                             enable_search: bool = False):
    """
    Generates reasoning and starts background processing for final response
    Returns the reasoning and a unique response_id
    """
    # Set up the global variable for user language
    global user_language
    user_language = {
        "code": language_code,
        "name": language_name
    }
    
    # Log search preference
    logger.info(f"Web search enabled: {enable_search}")
    
    # Setup memory to access chat history
    agent_memory = AgnoMemory(username=username, chat_id=chat_id)
    
    # Log key information for debugging
    logger.info(f"Processing message for chat {chat_id} by user {username}")
    logger.info(f"Chat exists: {len(agent_memory.messages) > 0}")
    
    # Add user message to history
    agent_memory.add_user_message(message)
    
    # Translate message if needed
    if (language_code != "eng_Latn"):
        try:
            # Use asyncio.to_thread to run translation in a thread
            input_text = await asyncio.to_thread(
                translator.translate_text,
                message,
                language_code,
                "eng_Latn"
            )
            # Store translation
            agent_memory.add_translation(message, input_text, "user_to_english")
            logger.info(f"Translated user input from {language_name} to English")
        except Exception as e:
            logger.error(f"Translation error: {e}")
            input_text = message
    else:
        input_text = message
    
    # Get chat history for context
    chat_history = agent_memory.get_formatted_history()
    
    # Always generate fresh reasoning
    logger.info(f"Generating reasoning for message: {input_text[:30]}...")
    reasoning, show_reasoning = await asyncio.to_thread(
        get_enhanced_reasoning, input_text, chat_history
    )
    
    # Translate reasoning if needed
    translated_reasoning = None
    if show_reasoning and language_code != "eng_Latn":
        try:
            # Get translation
            translated_reasoning = await asyncio.to_thread(
                translator.translate_text,
                show_reasoning,
                "eng_Latn",
                language_code
            )
            
            # Store both original and translated reasoning immediately
            agent_memory.add_reasoning(
                input_text=message,
                original_reasoning=show_reasoning,
                translated_reasoning=translated_reasoning
            )
            logger.info(f"Stored original and translated reasoning for {chat_id}")
            
            # Use translated version for the response
            translated_reasoning = translated_reasoning
            
        except Exception as e:
            logger.error(f"Translation error for reasoning: {e}")
            # Store original only if translation fails
            agent_memory.add_reasoning(
                input_text=message,
                original_reasoning=show_reasoning,
                translated_reasoning=None
            )
            # Keep English reasoning if translation fails
            translated_reasoning = show_reasoning
    else:
        # For English, store original only
        agent_memory.add_reasoning(
            input_text=message,
            original_reasoning=show_reasoning,
            translated_reasoning=None
        )
        translated_reasoning = show_reasoning

    # Create a unique response ID
    response_id = str(uuid.uuid4())
    
    # Initialize entry in response tracker
    response_tracker[response_id] = {
        "chat_id": chat_id,  # Ensure the correct chat_id is stored
        "status": "processing",
        "reasoning": translated_reasoning,
        "response": None,
        "language_code": language_code,  # Store language code to prevent further translation
        "language_name": language_name,  # Store language name for logging purposes
        "start_time": time.time()
    }
    
    # Start background processing for the final response
    threading.Thread(
        target=process_response_background,
        args=(response_id, username, message, chat_id, reasoning, show_reasoning, 
              language_code, language_name, enable_search),
        daemon=True
    ).start()
    
    # Return the reasoning, response_id, and the chat_id used
    return translated_reasoning, response_id, chat_id

# Add timestamp method to AgnoMemory if not exists
def add_timestamp_method_to_memory():
    if not hasattr(AgnoMemory, '_get_timestamp'):
        from datetime import datetime
        AgnoMemory._get_timestamp = lambda self: datetime.now().isoformat()

# Ensure the timestamp method exists
add_timestamp_method_to_memory()

# Clean up old responses to prevent memory leaks
def cleanup_old_responses():
    current_time = time.time()
    to_remove = []
    
    # Clean response tracker
    for response_id, data in response_tracker.items():
        # Remove responses older than 30 minutes
        if current_time - data.get("start_time", current_time) > 1800:
            to_remove.append(response_id)
    
    for response_id in to_remove:
        response_tracker.pop(response_id, None)
    
    # Log cleanup summary if anything was removed
    if to_remove:
        logger.info(f"Cleaned up {len(to_remove)} old responses")

# Scheduled cleanup task (runs every minute)
async def scheduled_cleanup():
    while True:
        cleanup_old_responses()
        await asyncio.sleep(60)  # Sleep for 60 seconds

@router.post("/initiate", tags=["Chat"])
async def initiate_chat(request: InitiateChatRequest):
    """
    Start a new chat session with initial message.
    Returns the reasoning immediately and provides a response_id for fetching the final response.
    """
    logger.info(f"Initiating chat for user {request.username}")
    user_details = await sync_to_async(list)(ActiveInactiveUsers.objects.filter(user__username=request.username))
    if user_details:
        for user in user_details:
            # If start_time isn't set, set it now
            if user.start_time is None:
                user.start_time = datetime.now().time().replace(microsecond=0)
                await sync_to_async(user.save)()
            else:
                # If start_time exists, check if the elapsed minutes exceed the 'minute' field
                start_datetime = datetime.combine(datetime.today(), user.start_time)
                current_datetime = datetime.now()
                elapsed_minutes = (current_datetime - start_datetime).total_seconds() / 60
                if user.minute is not None and elapsed_minutes > user.minute:
                    user.end_time = datetime.now().time().replace(microsecond=0)
                    await sync_to_async(user.save)()
                    return JSONResponse({"detail": "Your Testing Time Is Finished"}, status_code=200)
    
    
    
    
    chat_id = str(uuid.uuid4())
    # Generate reasoning and start background processing
    reasoning, response_id, _ = await generate_reasoning_and_start_response(
        request.username,
        request.message,
        chat_id,
        request.language_code,
        request.language_name,
        request.enable_search  # Pass the search preference
    )
    
    # Return the reasoning and response ID immediately
    return ReasoningResponse(
        response_id=response_id,
        chat_id=chat_id,
        reasoning=reasoning,
        status="processing"
    )

@router.post("/continue", tags=["Chat"])
async def continue_chat(request: ContinueChatRequest):
    """
    Continue an existing chat with a new message.
    Returns the reasoning immediately and provides a response_id for fetching the final response.
    """

    logger.info(f"Initiating chat for user {request.username}")
    user_details = await sync_to_async(list)(ActiveInactiveUsers.objects.filter(user__username=request.username))
    if user_details:
        for user in user_details:
            # If start_time isn't set, set it now
            if user.start_time is None:
                user.start_time = datetime.now().time().replace(microsecond=0)
                await sync_to_async(user.save)()
            else:
                # If start_time exists, check if the elapsed minutes exceed the 'minute' field
                start_datetime = datetime.combine(datetime.today(), user.start_time)
                current_datetime = datetime.now()
                elapsed_minutes = (current_datetime - start_datetime).total_seconds() / 60
                if user.minute is not None and elapsed_minutes > user.minute:
                    user.end_time = datetime.now().time().replace(microsecond=0)
                    await sync_to_async(user.save)()
                    return JSONResponse({"detail": "Your Testing Time Is Finished"}, status_code=200)
    # Check if chat exists
    memory = AgnoMemory(username=request.username, chat_id=request.chat_id)
    if not memory.messages:
        logger.error(f"Chat ID {request.chat_id} not found for user {request.username}")
        raise HTTPException(status_code=404, detail="Chat not found")
    
    logger.info(f"Continuing chat {request.chat_id} for user {request.username}")
    logger.info(f"Existing messages count: {len(memory.messages)}")
    logger.info(f"Search enabled: {request.enable_search}")
    
    # Generate reasoning and start background processing
    reasoning, response_id, chat_id = await generate_reasoning_and_start_response(
        request.username,
        request.message,
        request.chat_id,  # Pass the exact chat_id from request
        request.language_code,
        request.language_name,
        request.enable_search  # Pass the search preference
    )
    
    # Verify the chat_id being returned matches what we sent
    if chat_id != request.chat_id:
        logger.error(f"Chat ID mismatch: requested {request.chat_id} but got {chat_id}")
    
    # Return the reasoning and response ID immediately
    return ReasoningResponse(
        response_id=response_id,
        chat_id=request.chat_id,  # Use the original chat_id from request
        reasoning=reasoning,
        status="processing"
    )

@router.post("/chat_continue_post", tags=["Chat"])
async def chat_continue_post(request: ContinueChatRequest):
    """
    Alternative endpoint to continue an existing chat with a new message.
    Follows the same pattern as /continue but with different endpoint name.
    Returns the reasoning immediately and provides a response_id for fetching the final response.
    """
    
    logger.info(f"Initiating chat for user {request.username}")
    user_details = await sync_to_async(list)(ActiveInactiveUsers.objects.filter(user__username=request.username))
    if user_details:
        for user in user_details:
            # If start_time isn't set, set it now
            if user.start_time is None:
                user.start_time = datetime.now().time().replace(microsecond=0)
                await sync_to_async(user.save)()
            else:
                # If start_time exists, check if the elapsed minutes exceed the 'minute' field
                start_datetime = datetime.combine(datetime.today(), user.start_time)
                current_datetime = datetime.now()
                elapsed_minutes = (current_datetime - start_datetime).total_seconds() / 60
                if user.minute is not None and elapsed_minutes > user.minute:
                    user.end_time = datetime.now().time().replace(microsecond=0)
                    await sync_to_async(user.save)()
                    return JSONResponse({"detail": "Your Testing Time Is Finished"}, status_code=200)
    # Check if chat exists
    memory = AgnoMemory(username=request.username, chat_id=request.chat_id)
    if not memory.messages:
        logger.error(f"Chat ID {request.chat_id} not found for user {request.username}")
        raise HTTPException(status_code=404, detail="Chat not found")
    
    logger.info(f"Continuing chat {request.chat_id} for user {request.username} via chat_continue_post")
    logger.info(f"Existing messages count: {len(memory.messages)}")
    logger.info(f"Search enabled: {request.enable_search}")
    
    # Generate reasoning and start background processing
    reasoning, response_id, chat_id = await generate_reasoning_and_start_response(
        request.username,
        request.message,
        request.chat_id,  # Pass the exact chat_id from request
        request.language_code,
        request.language_name,
        request.enable_search  # Pass the search preference
    )
    
    # Verify the chat_id being returned matches what we sent
    if chat_id != request.chat_id:
        logger.error(f"Chat ID mismatch: requested {request.chat_id} but got {chat_id}")
    
    # Return the reasoning and response ID immediately
    return ReasoningResponse(
        response_id=response_id,
        chat_id=request.chat_id,  # Use the original chat_id from request
        reasoning=reasoning,
        status="processing"
    )

@router.post("/response-status", tags=["Chat"])
async def get_response_status(request: ResponseStatusRequest):
    """
    Get the status of a response by its ID.
    If the response is completed, returns the final response.
    """
    # Check if response exists
    if request.response_id not in response_tracker:
        logger.warning(f"Response ID {request.response_id} not found or expired")
        return {
            "status": "expired",
            "message": "Response has been completed and is no longer available",
            "length": 0,
            "content": ""
        }
    
    # Get response data
    response_data = response_tracker[request.response_id]
    logger.info(f"Response status check for {request.response_id}: {response_data.get('status')}")
    
    # Log the content to help debug
    if response_data.get("status") == "completed":
        response_content = response_data.get("response", "")
        response_length = len(response_content) if response_content else 0
        logger.info(f"Returning completed response of length {response_length}")
    
    # If there was an error processing the response
    if response_data.get("status") == "error":
        logger.error(f"Error in response {request.response_id}: {response_data.get('error')}")
        raise HTTPException(
            status_code=500, 
            detail=f"Error generating response: {response_data.get('error', 'Unknown error')}"
        )
    
    # If the response is still processing
    if response_data.get("status") == "processing":
        return {
            "response_id": request.response_id,
            "status": "processing",
            "chat_id": response_data.get("chat_id")
        }
    
    # If the response is completed, return it
    # Important: use the display_response (which has already been translated)
    return FinalResponse(
        response_id=request.response_id,
        response=response_data.get("response", "Sorry, no response was generated."),
        status="completed"
    )

@router.post("/chat/response-status")
async def check_response_status(request: ResponseStatusRequest):
    """Check the status of a response by ID"""
    response_id = request.response_id
    logger.info(f"Response status check for {response_id}")
    
    try:
        # Check if response exists in our tracking dictionary
        if response_id not in response_tracker:
            # Instead of letting FastAPI return 422, return a proper status message
            logger.warning(f"Response ID {response_id} not found or expired")
            return {
                "status": "expired",
                "message": "Response has been completed and is no longer available",
                "length": 0,
                "content": ""
            }
        
        status_info = response_tracker[response_id]
        status = status_info["status"]
        
        # Get response content as string (ensure it's not a dictionary/object)
        # IMPORTANT: Use the already translated response, don't translate again
        response_content = status_info.get("response", "")
        if not isinstance(response_content, str):
            # Convert non-string content to string to avoid API errors
            try:
                response_content = str(response_content)
                logger.warning(f"Converted non-string response to string for {response_id}")
            except Exception as conv_error:
                logger.error(f"Failed to convert response to string: {conv_error}")
                response_content = "Error: Could not process response content"
        
        response_length = len(response_content) if response_content else 0
        
        # Create diagnostic info separately from the main response
        diagnostics = {}
        if status == "completed":
            # Check for signs that this is an error or generic response
            is_likely_error = (
                "apologize" in response_content.lower() and 
                "try again" in response_content.lower() and
                response_length < 100
            )
            
            diagnostics = {
                "response_length": response_length,
                "likely_error_response": is_likely_error
            }
            
            # Log detailed information for potential issues
            if is_likely_error:
                logger.warning(f"Detected possible error response for {response_id}: '{response_content}'")
                
                # If this is likely a generic error, add more context to help with diagnosis
                error_message = status_info.get("error", "Unknown error")
                if error_message and error_message != "Unknown error":
                    diagnostics["error_details"] = error_message
            
            logger.info(f"Response status check for {response_id}: {status}")
            logger.info(f"Returning completed response of length {response_length}")
            
            # Return the response content WITHOUT including diagnostics in the content
            return {
                "status": status,
                "length": response_length,
                "content": response_content,  # This is the translated response, don't translate again
                # Keep diagnostics separate from content
                "diagnostics": json.dumps(diagnostics)  # Convert to string
            }
        else:
            # In-progress response
            logger.info(f"Response status check for {response_id}: {status}")
            processing_time = time.time() - status_info.get("start_time", time.time())
            diagnostics = {"processing_time": f"{processing_time:.2f} seconds"}
            
            return {
                "status": status,
                "length": 0,
                "content": "",  # Empty content for in-progress
                "diagnostics": json.dumps(diagnostics)  # Convert to string
            }
    
    except Exception as e:
        # Handle any exceptions gracefully
        logger.error(f"Error checking response status: {str(e)}")
        return {
            "status": "error",
            "message": "An error occurred while checking response status",
            "length": 0,
            "content": "",
            "error_details": str(e)
        }

@router.post("/all", tags=["Chat"])
async def get_all_chats(request: AllChatsRequest):
    """
    Get a list of all chats for the user with their first messages
    """
    try:
        # Get base path for user's chats
        base_path = os.path.join("chat_histories", request.username)
        
        # Check if directory exists
        if not os.path.exists(base_path):
            return AllChatsResponse(chats=[])
        
        chat_summaries = []
        
        # List all files in the directory
        for filename in os.listdir(base_path):
            if filename.endswith('.json'):
                chat_id = filename[:-5]  # Remove .json extension
                file_path = os.path.join(base_path, filename)
                
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        messages = json.load(f)
                        
                    # Find first user message
                    first_message = ""
                    timestamp = ""
                    for msg in messages:
                        if msg.get("role") == "user":
                            first_message = msg.get("content", "")
                            timestamp = msg.get("timestamp", "")
                            break
                    
                    chat_summaries.append(
                        ChatSummary(
                            chat_id=chat_id,
                            first_message=first_message,
                            timestamp=timestamp
                        )
                    )
                except Exception as e:
                    logger.error(f"Error reading chat file {file_path}: {e}")
                    continue
        
        # Sort chats by timestamp, most recent first
        chat_summaries.sort(key=lambda x: x.timestamp, reverse=True)
        
        return AllChatsResponse(chats=chat_summaries)
    except Exception as e:
        logger.error(f"Error retrieving all chats: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve chats: {str(e)}")

@router.post("/detailed-history", tags=["Chat"])
async def get_detailed_chat_history(request: DetailedHistoryRequest):
    """
    Get detailed chat history including prompts, reasoning, and responses.
    Returns translated reasoning if available.
    """
    try:
        memory = AgnoMemory(username=request.username, chat_id=request.chat_id)
        
        if not memory.messages:
            raise HTTPException(status_code=404, detail="Chat not found")
            
        detailed_messages = []
        current_turn = {}
        
        # Keep track of reasoning entries for each prompt to handle duplicates
        reasoning_map = {}
        
        # First pass - collect all reasoning entries
        for msg in memory.messages:
            if msg.get("role") == "system" and msg.get("message_type") == "reasoning_process":
                input_text = msg.get("input_text", "")
                if input_text not in reasoning_map:
                    reasoning_map[input_text] = {
                        "original": msg.get("original_reasoning", ""),
                        "translated": msg.get("translated_reasoning")
                    }
                elif msg.get("translated_reasoning"):  # If we find a translated version later
                    reasoning_map[input_text]["translated"] = msg.get("translated_reasoning")
        
        # Second pass - process messages
        for msg in memory.messages:
            role = msg.get("role", "")
            content = msg.get("content", "")
            timestamp = msg.get("timestamp", "")
            
            if role == "user":
                if current_turn.get("prompt") and current_turn.get("prompt") != content:
                    # Before starting new turn, try to add reasoning from map
                    if current_turn.get("prompt") in reasoning_map:
                        reasoning_entry = reasoning_map[current_turn["prompt"]]
                        current_turn["reasoning"] = reasoning_entry.get("translated") or reasoning_entry.get("original", "")
                    
                    if current_turn.get("response", "").strip():
                        detailed_messages.append(
                            DetailedMessage(
                                prompt=current_turn.get("prompt", ""),
                                reasoning=current_turn.get("reasoning", ""),
                                response=current_turn.get("response", ""),
                                timestamp=current_turn.get("timestamp", "")
                            )
                        )
                    current_turn = {
                        "prompt": content,
                        "reasoning": "",
                        "response": "",
                        "timestamp": timestamp
                    }
                else:
                    current_turn = {
                        "prompt": content,
                        "reasoning": "",
                        "response": "",
                        "timestamp": timestamp
                    }
            
            elif role == "assistant":
                if current_turn.get("prompt") and content != "[Tool request]":
                    current_turn["response"] = content
            
            elif role == "translate":
                direction = msg.get("direction", "")
                if direction == "user_to_english" and current_turn.get("prompt"):
                    current_turn["prompt"] = msg.get("original_text", content)
                elif direction == "english_to_user" and current_turn.get("response"):
                    current_turn["response"] = content
        
        # Handle the last turn
        if current_turn.get("prompt"):
            # Try to add reasoning from map for last turn
            if current_turn.get("prompt") in reasoning_map:
                reasoning_entry = reasoning_map[current_turn["prompt"]]
                current_turn["reasoning"] = reasoning_entry.get("translated") or reasoning_entry.get("original", "")
            
            if current_turn.get("response", "").strip():
                detailed_messages.append(
                    DetailedMessage(
                        prompt=current_turn.get("prompt", ""),
                        reasoning=current_turn.get("reasoning", ""),
                        response=current_turn.get("response", ""),
                        timestamp=current_turn.get("timestamp", "")
                    )
                )
        
        return DetailedChatHistory(
            chat_id=request.chat_id,
            messages=detailed_messages
        )
        
    except Exception as e:
        logger.error(f"Error retrieving detailed chat history: {e}")
        raise HTTPException(
            status_code=500, 
            detail=f"Failed to retrieve detailed chat history: {str(e)}"
        )

# Set up cleanup task

@router.on_event("startup")
async def setup_cleanup_task():
    asyncio.create_task(scheduled_cleanup())

# Add a new function to save responses to disk for tracking
def save_response_to_disk(response_id: str, username: str, chat_id: str, response_data: Dict):
    """
    Save completed response to disk for tracking and analytics
    """
    try:
        # Create response_histories directory if it doesn't exist
        responses_dir = os.path.join("response_histories")
        os.makedirs(responses_dir, exist_ok=True)
        
        # Create a directory for the user if it doesn't exist
        user_dir = os.path.join(responses_dir, username)
        os.makedirs(user_dir, exist_ok=True)
        
        # Create date-based directories for better organization
        today = datetime.now().strftime("%Y-%m-%d")
        date_dir = os.path.join(user_dir, today)
        os.makedirs(date_dir, exist_ok=True)
        
        # Create the response record
        response_record = {
            "response_id": response_id,
            "chat_id": chat_id,
            "timestamp": datetime.now().isoformat(),
            "status": response_data.get("status", "unknown"),
            "response": response_data.get("response", ""),
            "reasoning": response_data.get("reasoning", "")
        }
        
        # Save to a JSON file named with the response_id
        file_path = os.path.join(date_dir, f"{response_id}.json")
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(response_record, f, indent=2, ensure_ascii=False)
            
        logger.info(f"Response {response_id} saved to disk at {file_path}")
        
        # Also append to a daily log file for easier batch processing
        daily_log_path = os.path.join(user_dir, f"responses_{today}.jsonl")
        with open(daily_log_path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(response_record) + "\n")
            
    except Exception as e:
        logger.error(f"Failed to save response to disk: {e}")

# Create an endpoint to retrieve response history for a user
@router.post("/responses/history", tags=["Chat"])
async def get_user_response_history(request: AllChatsRequest):
    """Get response history for a user"""
    try:
        username = request.username
        responses_dir = os.path.join("response_histories", username)
        
        if not os.path.exists(responses_dir):
            return {"responses": []}
            
        # Get all responses from the last 7 days
        responses = []
        today = datetime.now()
        
        for i in range(7):  # Last 7 days
            date_str = (today - timedelta(days=i)).strftime("%Y-%m-%d")
            date_dir = os.path.join(responses_dir, date_str)
            
            if os.path.exists(date_dir):
                daily_log_path = os.path.join(responses_dir, f"responses_{date_str}.jsonl")
                
                if os.path.exists(daily_log_path):
                    with open(daily_log_path, 'r', encoding='utf-8') as f:
                        for line in f:
                            try:
                                response = json.loads(line.strip())
                                responses.append(response)
                            except:
                                pass
        
        return {"responses": responses}
    except Exception as e:
        logger.error(f"Error retrieving response history: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve response history: {str(e)}")



class DeleteChatHistoryRequest(BaseModel):
    username: str
    chat_id: str

@router.post("/delete-chat-history", tags=["Chat"])
async def delete_chat_history(request: DeleteChatHistoryRequest):
    """
    Delete a specific chat history file for the given user and chat_id,
    and remove related response files and daily log entries from the
    HindAi_project/response_histories folder so that deleted chat history does not appear.
    """
    try:
        # Delete chat history file
        chat_history_path = os.path.join("chat_histories", request.username, f"{request.chat_id}.json")
        logger.info(f"Attempting to delete chat history at {chat_history_path}")
        if os.path.exists(chat_history_path):
            os.remove(chat_history_path)
            logger.info(f"Deleted chat history for chat_id {request.chat_id} and user {request.username}")
        else:
            logger.warning(f"Chat history file {chat_history_path} not found")
            raise HTTPException(status_code=404, detail="Chat history not found")
        
        # Delete individual response files and update daily logs.
        base_dir = os.path.dirname(__file__)
        # Absolute path to the response histories directory for this user
        responses_dir = os.path.join(base_dir, "HindAi_project", "response_histories", request.username)
        if os.path.exists(responses_dir):
            # Walk through subdirectories (organized by date) and delete matching response files.
            for root, _, files in os.walk(responses_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    if file.endswith(".json"):
                        try:
                            with open(file_path, 'r', encoding='utf-8') as f:
                                data = json.load(f)
                            if data.get("chat_id") == request.chat_id:
                                os.remove(file_path)
                                logger.info(f"Deleted response file {file_path} for chat_id {request.chat_id}")
                        except Exception as e:
                            logger.error(f"Error processing file {file_path}: {e}")
            
            # Update any daily log files (JSONL) by filtering out records with the deleted chat_id.
            user_logs = []
            # Look for daily log files inside the user's response_histories directory
            for f_name in os.listdir(responses_dir):
                if f_name.startswith("responses_") and f_name.endswith(".jsonl"):
                    user_logs.append(os.path.join(responses_dir, f_name))
            
            for log_file in user_logs:
                try:
                    with open(log_file, "r", encoding="utf-8") as lf:
                        lines = lf.readlines()
                    new_lines = []
                    for line in lines:
                        try:
                            record = json.loads(line.strip())
                            if record.get("chat_id") != request.chat_id:
                                new_lines.append(line)
                        except Exception as e:
                            logger.error(f"Error processing log line in {log_file}: {e}")
                            new_lines.append(line)
                    # Rewrite the log file with filtered lines
                    with open(log_file, "w", encoding="utf-8") as lf:
                        lf.writelines(new_lines)
                    logger.info(f"Updated daily log {log_file} to remove chat_id {request.chat_id}")
                except Exception as e:
                    logger.error(f"Error updating log file {log_file}: {e}")
        else:
            logger.info(f"No response histories found for user {request.username} at {responses_dir}")
        
        return JSONResponse(
            status_code=200,
            content={"detail": f"Chat history {request.chat_id} and its responses for user {request.username} have been deleted successfully"}
        )
    except Exception as e:
        logger.error(f"Error deleting chat history for user {request.username} and chat {request.chat_id}: {e}")
        raise HTTPException(status_code=500, detail="Error deleting chat history and associated responses")