"""
Recovery mechanisms for failed responses in HindAI
"""
import json
import logging
import os
import time
from datetime import datetime, timedelta
from typing import Dict, Optional, List

logger = logging.getLogger(__name__)

def scan_for_failed_responses(username: Optional[str] = None, days_back: int = 1) -> List[Dict]:
    """
    Scan for failed responses to analyze patterns and issues
    
    Args:
        username: Optional username to filter by
        days_back: How many days back to scan
        
    Returns:
        List of failed response details
    """
    failed_responses = []
    base_dir = "response_histories"
    
    try:
        # Determine which user directories to check
        if username:
            user_dirs = [os.path.join(base_dir, username)]
        else:
            if not os.path.exists(base_dir):
                return []
            user_dirs = [os.path.join(base_dir, d) for d in os.listdir(base_dir) 
                      if os.path.isdir(os.path.join(base_dir, d))]
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days_back)
        
        # Check each user directory
        for user_dir in user_dirs:
            if not os.path.exists(user_dir):
                continue
                
            # Look for date-based directories and log files
            for item in os.listdir(user_dir):
                # Check if it's a date directory within our range
                if os.path.isdir(os.path.join(user_dir, item)):
                    try:
                        dir_date = datetime.strptime(item, "%Y-%m-%d")
                        if start_date <= dir_date <= end_date:
                            # This directory is in our date range
                            date_dir = os.path.join(user_dir, item)
                            
                            # Check each response file
                            for response_file in os.listdir(date_dir):
                                if response_file.endswith('.json'):
                                    file_path = os.path.join(date_dir, response_file)
                                    
                                    try:
                                        with open(file_path, 'r', encoding='utf-8') as f:
                                            response_data = json.load(f)
                                            
                                        # Check if this is a failed response
                                        response_content = response_data.get('response', '')
                                        status = response_data.get('status', '')
                                        
                                        if ((status == "error" or status == "completed") and
                                            ("apologize" in response_content.lower() and
                                             "try again" in response_content.lower() and
                                             len(response_content) < 100)):
                                            
                                            # This looks like a failed response
                                            failed_responses.append({
                                                "response_id": response_data.get("response_id", ""),
                                                "chat_id": response_data.get("chat_id", ""),
                                                "username": os.path.basename(user_dir),
                                                "timestamp": response_data.get("timestamp", ""),
                                                "content": response_content,
                                                "error": response_data.get("error", "")
                                            })
                                    except Exception as e:
                                        logger.error(f"Error processing response file {file_path}: {e}")
                    except ValueError:
                        # Not a date directory, might be something else
                        pass
                        
                # Also check JSONL log files
                elif item.startswith("responses_") and item.endswith(".jsonl"):
                    try:
                        # Extract date from filename (format: responses_YYYY-MM-DD.jsonl)
                        date_str = item[10:-6]  # Extract YYYY-MM-DD part
                        file_date = datetime.strptime(date_str, "%Y-%m-%d")
                        
                        if start_date <= file_date <= end_date:
                            log_path = os.path.join(user_dir, item)
                            
                            with open(log_path, 'r', encoding='utf-8') as f:
                                for line in f:
                                    try:
                                        response_data = json.loads(line.strip())
                                        
                                        # Check if this is a failed response
                                        response_content = response_data.get('response', '')
                                        status = response_data.get('status', '')
                                        
                                        if ((status == "error" or status == "completed") and
                                            ("apologize" in response_content.lower() and
                                             "try again" in response_content.lower() and
                                             len(response_content) < 100)):
                                            
                                            # This looks like a failed response
                                            failed_responses.append({
                                                "response_id": response_data.get("response_id", ""),
                                                "chat_id": response_data.get("chat_id", ""),
                                                "username": os.path.basename(user_dir),
                                                "timestamp": response_data.get("timestamp", ""),
                                                "content": response_content,
                                                "error": response_data.get("error", "")
                                            })
                                    except json.JSONDecodeError:
                                        pass
                    except ValueError:
                        # Not a properly formatted date in the filename
                        pass
        
        return failed_responses
        
    except Exception as e:
        logger.error(f"Error scanning for failed responses: {e}")
        return []

def generate_error_report(days_back: int = 7) -> Dict:
    """Generate a report of response failures"""
    try:
        failed_responses = scan_for_failed_responses(days_back=days_back)
        
        # Group by day
        by_day = {}
        for resp in failed_responses:
            try:
                date_str = datetime.fromisoformat(resp["timestamp"]).strftime("%Y-%m-%d")
                by_day.setdefault(date_str, []).append(resp)
            except (ValueError, KeyError):
                by_day.setdefault("unknown", []).append(resp)
        
        # Group by error type
        by_error = {}
        for resp in failed_responses:
            error = resp.get("error", "Unknown")
            by_error.setdefault(error, []).append(resp)
        
        # Generate summary
        report = {
            "total_failures": len(failed_responses),
            "period_days": days_back,
            "generated_at": datetime.now().isoformat(),
            "failures_by_day": {day: len(items) for day, items in by_day.items()},
            "failures_by_error_type": {error: len(items) for error, items in by_error.items()},
            "recent_examples": failed_responses[:10] if failed_responses else []
        }
        
        return report
        
    except Exception as e:
        logger.error(f"Error generating error report: {e}")
        return {"error": str(e)}
