import asyncio
import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import sys
import os

# Add the parent directory to sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import your router and cleanup function
from HindAI_Apis import chat_api

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

# Include your API router
app.include_router(chat_api.router, prefix="/api")

@app.on_event("startup")
async def startup_event():
    # Start the cleanup task in the background
    asyncio.create_task(chat_api.scheduled_cleanup())
    print("Cleanup task started")

@app.get("/")
async def root():
    return {"message": "HindAI API is running"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
