import logging
import sys
import os
from fastapi import FastAPI

from fastapi.middleware.cors import CORSMiddleware
from HindAi_users.auth_api import router as auth_router
from htmlgen.api import router as html_router
# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Add parent directories to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
hindai_apis_dir = os.path.dirname(current_dir)  # HindAI_Apis directory
project_root = os.path.dirname(hindai_apis_dir)  # project root directory

# Add directories to path to ensure all imports work
sys.path.insert(0, hindai_apis_dir)  # For local modules like agno_adapter
sys.path.insert(0, project_root)     # For HindAI module import

logger.info(f"Python paths configured: {sys.path[:3]}")
logger.info(f"Current directory: {current_dir}")
logger.info(f"HindAI APIs directory: {hindai_apis_dir}")

# Create the FastAPI app instance
app = FastAPI(title="HindAI API", version="1.0.0")

# Import modules after path setup to ensure they can be found
try:
    from agno_adapter import monkey_patch_hindai
    logger.info("Successfully imported agno_adapter")
except ImportError as e:
    logger.error(f"Import error for agno_adapter: {e}")
    # Define a fallback function if the import fails
    def monkey_patch_hindai():
        logger.warning("Using mock monkey_patch_hindai function")
        return False

# Import chat API router
try:
    from chat_api import router as chat_router, scheduled_cleanup
    logger.info("Successfully imported chat_router")
    
    # Add router to app
    app.include_router(chat_router, prefix="/chat", tags=["Chat"])
    logger.info("Chat router included in app")
except Exception as e:
    logger.error(f"Failed to import or include chat_router: {e}", exc_info=True)

@app.on_event("startup")
async def startup_event():
    # Apply monkey patches to fix Agno API issues
    try:
        success = monkey_patch_hindai()
        if success:
            logger.info("Applied Agno API compatibility fixes")
        else:
            logger.warning("Monkey patching function returned False")
    except Exception as e:
        logger.error(f"Failed to apply Agno API fixes: {e}")
    
    # Start cleanup task for chat responses
    try:
        import asyncio
        if 'scheduled_cleanup' in locals() or 'scheduled_cleanup' in globals():
            asyncio.create_task(scheduled_cleanup())
            logger.info("Started scheduled cleanup task")
        else:
            logger.warning("scheduled_cleanup function not available")
    except Exception as e:
        logger.error(f"Failed to start cleanup task: {e}")

@app.get("/")
async def root():
    return {"message": "HindAI API is running"}

@app.get("/debug")
async def debug_info():
    """Return debug information about the environment"""
    return {
        "sys.path": sys.path,
        "current_directory": os.getcwd(),
        "python_version": sys.version,
        "module_locations": {
            "main_api": __file__,
            "modules_available": [
                "agno_adapter" if "agno_adapter" in sys.modules else "agno_adapter (missing)",
                "chat_api" if "chat_api" in sys.modules else "chat_api (missing)",
                "HindAI" if "HindAI" in sys.modules else "HindAI (missing)",
            ]
        }
    }

# Include the HTML generation router
app.include_router(
    html_router,
    prefix="/html",
    tags=["HTML Generation"],
    responses={404: {"description": "Not found"}},
)
# Include the auth router immediately after app creation
app.include_router(
    auth_router,
    prefix="/auth",
    tags=["Authentication"],
    responses={404: {"description": "Not found"}},
)
# Add CORS middleware to FastAPI app
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5174",
        "http://localhost:5173",
        "http://localhost:3000",
        "http://localhost:9000",
        "http://saveai.tech",
        "https://aichatbot.bettlechampion.com",
        "https://7236-148-113-5-63.ngrok-free.app",
        "https://hindai.finsocial.tech",
        "https://ved.hindai.tech",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=[
        "Content-Type",
        "Authorization",
        "Accept",
        "Origin",
        "X-Requested-With",
        "X-CSRFTOKEN"
    ],
)
