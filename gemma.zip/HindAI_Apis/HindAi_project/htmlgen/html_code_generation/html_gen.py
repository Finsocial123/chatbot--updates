import agno  # Import Agno
from openai import OpenAI  # Import OpenAI client directly for compatibility
import json
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# API configuration
api_key = "sk-27185f30930a4613b26d90666082c23b"
base_url = "https://shivering-eleen-finsocialdigitalsystem-ccf7f279.koyeb.app/v1"

# Define the model to use with Agno
model = "PetrosStav/gemma3-tools:12b"  # Keep using your preferred model

# Initialize client using the OpenAI client with Agno's base URL
agno_client = OpenAI(
    api_key=api_key,
    base_url=base_url
)

def generate_html(prompt: str) -> str:
    """
    Generate HTML code based on user's prompt
    
    Args:
        prompt: User's description of the HTML they want to generate
        
    Returns:
        String containing the generated HTML code
    """
    try:
        # Create a system message focused on HTML generation. Note that additional directives
        # have been added to include a "Download Webpage" button and branding in the footer.
        system_message = {
            "role": "system",
            "content": """You are an expert HTML code generator. Your task is to take the complete content provided by the user and create an HTML webpage that represents the content exactly as given, without adding or altering any part of it.

        Guidelines for HTML generation:
        1. Use modern HTML5 elements and best practices.
        2. Do not add any extra content, animations, or interactive elements not explicitly provided by the user.
        3. Ensure that the generated HTML faithfully represents the user's input.
        4. Use semantic HTML elements such as header, nav, main, section, article, and footer only where applicable.
        5. Apply only minimal inline CSS if necessary, strictly for layout purposes without modifying the user content.
        6. Output only the complete HTML wrapped in ```html tags, without any additional commentary.
        7. The webpage should have dark mode styling by default.
        8. Include a "Download Webpage" button positioned at the top right corner.
        9. Add the company branding: include "Hind AI" prominently and a footer note stating "Developed by the finsocial digital systems".
        """
        }
        
        # User message
        user_message = {
            "role": "user",
            "content": prompt
        }
        
        # Combine messages
        messages = [system_message, user_message]
        
        logger.info("Sending HTML generation request to model")
        
        # Call the API
        response = agno_client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=0.2,
        )
        
        # Extract the response content
        output = response.choices[0].message.content
        
        logger.info(f"Successfully generated HTML of length {len(output)}")
        return output
        
    except Exception as e:
        logger.error(f"Error generating HTML: {str(e)}", exc_info=True)
        return f"Error generating HTML: {str(e)}"

def main(prompt):
    """Simple command-line interface for HTML generation"""
    print("HTML Generator")
    print("Enter your prompt describing the HTML you want to generate")
    print("Type 'exit' to quit")
    user_input = prompt.strip()
    html_output = generate_html(user_input)
    print("\nGenerated HTML:")
    print(html_output)

