#!/usr/bin/env python3
"""
Helper script to run the HindAI API server with proper paths configured.
This ensures all imports work correctly regardless of the current working directory.

Usage:
    python run_api.py
"""

import os
import sys
import logging
import uvicorn

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def run_server():
    """Run the API server with proper configuration"""
    # Get the directory containing this script
    base_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.dirname(base_dir)
    
    # Add both directories to Python path
    sys.path.insert(0, base_dir)
    sys.path.insert(0, project_dir)
    
    logger.info(f"Starting HindAI API server")
    logger.info(f"Project directory: {project_dir}")
    logger.info(f"API directory: {base_dir}")
    
    # Check for required modules
    try:
        import fastapi
        import agno
        logger.info("Required packages found: fastapi, agno")
    except ImportError as e:
        logger.error(f"Missing required package: {e}")
        logger.error("Please install required packages: pip install fastapi uvicorn agno")
        sys.exit(1)
    
    # Run the server
    uvicorn.run(
        "HindAi_project.asgi:application",
        host="0.0.0.0",
        port=8000,
        reload=True,
        reload_dirs=[base_dir],
        log_level="info"
    )

if __name__ == "__main__":
    run_server()
