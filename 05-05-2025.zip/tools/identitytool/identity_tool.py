from .identity_database import get_identity_database

class IdentityTool:
    def __init__(self):
        self.identity_db = get_identity_database()

    def get_identity_response(self, query: str) -> str:
        """Get appropriate identity response based on the query"""
        response = self.identity_db.find_best_response(query)
        if response:
            return response
        
        # Default identity response if no match found
        return "I am HindAI, an AI assistant created by Finsocial Digital Systems in April 2025. I was designed to provide helpful and accurate information to users."

def get_identity_tool():
    """Factory function to get an instance of the IdentityTool"""
    return IdentityTool()