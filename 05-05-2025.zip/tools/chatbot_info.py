def get_chatbot_info(query: str = "") -> str:
    """Provides information about the Hind AI chatbot."""
    chatbot_info = {
        "name": "Hind AI",
        "developer": "Finsocial Digital System",
        "version": "2.0",
        "description": "A versatile AI assistant focused on general conversation and information processing",
        "capabilities": [
            "Natural conversation and knowledge sharing",
            "Document analysis (PDFs, images, audio)",
            "Web content retrieval and analysis",
            "Real-time information processing",
            "Context-aware responses",
            "Multi-format file handling"
        ]
    }
    
    return (
        f"I am {chatbot_info['name']}, version {chatbot_info['version']}, "
        f"developed by {chatbot_info['developer']}. {chatbot_info['description']}"
    )

# Tool definition for Agno API
chatbot_info_tool_definition = {
    "type": "function",
    "function": {
        "name": "get_chatbot_info",
        "description": "Get information about the chatbot",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Optional query about the chatbot"
                }
            },
            "required": []
        }
    }
}
