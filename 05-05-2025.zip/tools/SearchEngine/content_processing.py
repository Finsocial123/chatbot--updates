import requests
from bs4 import BeautifulSoup
import json

# Fetch Webpage Content
def fetch_content(url):
    try:
        headers = {"User-Agent": "Mozilla/5.0"}
        response = requests.get(url, headers=headers, timeout=5)
        
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, "html.parser")
            return soup.get_text(separator="\n", strip=True) or "No readable text found."
    except requests.RequestException as e:
        return f"Failed to retrieve content: {str(e)}"

# Generate basic summaries without using LLM
def generate_summaries(query, results):
    summaries = []
    for result in results:
        url, title = result["url"], result["title"]
        content = fetch_content(url)
        
        if content and content != "No readable text found.":
            # Create a simple summary by taking the first 500 characters
            simple_summary = content
            summaries.append({"title": title, "url": url, "summary": simple_summary})
        else:
            summaries.append({"title": title, "url": url, "summary": "Content could not be summarized."})
    return summaries
