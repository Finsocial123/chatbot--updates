import json
import logging

logger = logging.getLogger(__name__)

def format_tool_response(tool_call_id, tool_name, content):
    """
    Format a tool response in the proper format for the API
    
    Args:
        tool_call_id (str): The ID of the tool call
        tool_name (str): The name of the tool 
        content (any): The content of the response
        
    Returns:
        dict: A properly formatted tool response
    """
    # Ensure content is a string
    if not isinstance(content, str):
        try:
            content = str(content)
        except Exception as e:
            logger.warning(f"Error converting tool result to string: {e}")
            content = json.dumps(content) if isinstance(content, (dict, list)) else str(content)
    
    return {
        "tool_call_id": tool_call_id,
        "role": "tool",
        "name": tool_name,
        "content": content
    }

def prepare_tool_responses(tool_calls, tool_results):
    """
    Prepare tool responses in the proper format
    
    Args:
        tool_calls: List of tool calls from the API
        tool_results: List of tool results
        
    Returns:
        list: Properly formatted tool responses
    """
    responses = []
    for i, tool_call in enumerate(tool_calls):
        result = tool_results[i] if i < len(tool_results) else "Error: No result available"
        responses.append(format_tool_response(
            tool_call.id,
            tool_call.function.name,
            result
        ))
    return responses
