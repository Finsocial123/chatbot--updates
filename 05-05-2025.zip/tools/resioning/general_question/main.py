import json
from sentence_transformers import SentenceTransformer, util

# Initialize the model once globally for performance
model = SentenceTransformer('all-MiniLM-L6-v2')


def load_questions(json_filepath: str) -> list:
    """
    Load questions from a JSON file.

    The JSON file can either be:
      - A list of questions: ["question1", "question2", ...]
      - A dictionary where keys are questions.

    Returns a list of questions.
    """
    with open(json_filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    if isinstance(data, list):
        return data
    elif isinstance(data, dict):
        return list(data.keys())
    else:
        return []


def semantic_similarity(user_query: str, questions: list, question_embeddings, threshold: float = 0.5) -> dict:
    """
    Compute semantic similarity scores between the user_query and each question 
    using Sentence Transformers. Returns a dictionary mapping each question to its cosine score.
    """
    # Removed model initialization for performance; using global model
    query_embedding = model.encode(user_query, convert_to_tensor=True)
    cosine_scores = util.cos_sim(query_embedding, question_embeddings)[0]
    scores = {questions[i]: float(cosine_scores[i])
              for i in range(len(questions))}
    return scores



json_filepath = r"instructions.json"
questions = load_questions(json_filepath)
question_embeddings = model.encode(questions, convert_to_tensor=True)

question_embeddings = model.encode(questions, convert_to_tensor=True)

def check_gen(prompt):
    user_query = input("Enter your question: ")
    scores = semantic_similarity(
    user_query, questions, question_embeddings, threshold=0.5)

        # Determine the best match
    best_question = max(scores, key=scores.get)
    best_score = scores[best_question]
    if best_score >= 0.5:
        # Enhanced visibility with ANSI colors for output
        return "TRUE"
    else:
        return "FALSE"