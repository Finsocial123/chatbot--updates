from datetime import datetime
from zoneinfo import ZoneInfo
def get_current_time(_=""):
    """Get the current date and time"""
    current = datetime.now(ZoneInfo("Asia/Kolkata"))
    return f"Current time: {current.strftime('%I:%M %p')} on {current.strftime('%B %d, %Y')}"

# Tool definition for Agno API
time_tool_definition = {
    "type": "function",
    "function": {
        "name": "get_current_time",
        "description": "Get the exact current date and time. Use this for any time-related queries.",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": []
        }
    }
}
